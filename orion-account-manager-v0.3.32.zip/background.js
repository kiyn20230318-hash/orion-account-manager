(function () {
  'use strict';
  const engine = AccountEngine.create(AccountAPI);
  const base = AccountAPI.getURL(''), bridge = AccountAPI.getURL('quick-switch.html'), busyTabs = new Set();
  function webUrl(url) { try { const u=new URL(url);return /^https?:$/.test(u.protocol)?u:null; } catch (_) {return null;} }
  function supportedSite(state,url){const site=webUrl(url);return !!site&&state.profiles.some(p=>{const target=webUrl(p.startUrl);return target&&target.hostname.replace(/^www\./,'')===site.hostname.replace(/^www\./,'');});}
  const injecting=new Set();
  async function restoreEntry(tabId){
    if(!AccountAPI.native.tabs?.executeScript||injecting.has(tabId))return;
    injecting.add(tabId);
    try{
      const tab=await AccountAPI.call('tabs.get',tabId);
      if(tab.incognito!==false||!webUrl(tab.url))return;
      const state=await engine.handle({type:'state'});
      if(!supportedSite(state,tab.url))return;
      await AccountAPI.call('tabs.executeScript',tabId,{file:'quick-switch-content.js',allFrames:false,runAt:'document_idle'});
    }catch(_){/* Static content scripts and page-focus retry remain available. */}
    finally{injecting.delete(tabId);}
  }
  async function restoreOpenEntries(){
    if(!AccountAPI.native.tabs?.executeScript)return;
    try{const tabs=await AccountAPI.call('tabs.query',{});for(const tab of tabs)if(tab.incognito===false)await restoreEntry(tab.id);}catch(_){}
  }
  // After a switch opens its destination, count how the website changed the
  // cookies just written (read-only; the engine ignores unrelated tabs). The
  // short delay lets the page's own scripts run first.
  function observeOpened(tabId){setTimeout(()=>{engine.handle({type:'postOpenCheck',tabId}).catch(()=>{});},2000);}
  AccountAPI.native.tabs?.onUpdated?.addListener((id,change)=>{if(change.status==='complete'){restoreEntry(id);observeOpened(id);}});
  AccountAPI.native.tabs?.onActivated?.addListener(info=>restoreEntry(info.tabId));
  AccountAPI.native.runtime.onInstalled?.addListener(restoreOpenEntries);
  restoreOpenEntries();
  const sms=AccountSms.create({fetch:(...args)=>fetch(...args),get:key=>AccountAPI.call('storage.local.get',key),set:value=>AccountAPI.call('storage.local.set',value)});
  const QUICK_TOOLS={quickSmsState:()=>sms.siteState(),quickSmsNumber:()=>sms.getNumber(),quickSmsCode:()=>sms.getCode(),quickSmsAwait:()=>sms.awaitCode(),quickSmsCancel:async()=>sms.cancelWait(),quickIp:()=>sms.lookupIp()};
  const own=(object,key)=>typeof key==='string'&&Object.prototype.hasOwnProperty.call(object,key);
  const bit=AccountBit.create({fetch:(...args)=>fetch(...args),get:key=>AccountAPI.call('storage.local.get',key),set:value=>AccountAPI.call('storage.local.set',value)});
  const MANAGER_TOOLS={smsSettings:()=>sms.settings(),smsSaveSettings:m=>sms.saveSettings({apiKey:m.apiKey,projectId:m.projectId,countryCode:m.countryCode}),smsGetNumber:()=>sms.getNumber(),smsGetCode:()=>sms.getCode(),smsAwaitCode:()=>sms.awaitCode(),smsCancelWait:async()=>sms.cancelWait(),ipLookup:()=>sms.lookupIp(),
    bitSettings:()=>bit.settings(),bitSaveSettings:m=>bit.saveSettings({baseUrl:m.baseUrl}),bitList:m=>bit.listWindows({baseUrl:m.baseUrl,query:m.query,page:m.page}),bitFetch:m=>bit.fetchByNames({baseUrl:m.baseUrl,text:m.text})};
  function publicState(state) {return {profiles:state.profiles.map(p=>({id:p.id,name:p.name})),activeId:state.activeId,busy:state.operation?.busy===true,stalled:state.operation?.stalled===true};}
  // Rename from the website menu: name only. The library's own save keeps the
  // account's Cookie and address untouched and refuses a name already in use.
  async function quickRename(message,state){
    const profile=state.profiles.find(p=>p.id===message.id);
    if(!profile||typeof message.name!=='string')throw new Error();
    const name=message.name.normalize('NFC').trim();
    if(!name||name.length>100||/[\u0000-\u001f\u007f]/.test(name)){const error=new Error();error.safeMessage='請輸入 1–100 字的名稱，且不可含控制字元。';throw error;}
    if(name===profile.name)return {...publicState(state),enabled:true,renamed:false};
    const saved=await engine.handle({type:'save',profile:{id:profile.id,name,startUrl:profile.startUrl}});
    return {...publicState(saved),enabled:true,renamed:true};
  }
  async function quick(message,sender) {
    if(sender.frameId!==0 || !Number.isInteger(sender.tab?.id) || sender.tab.incognito!==false) throw new Error();
    const ownBridge=sender.url?.split('#')[0]===bridge, site=webUrl(sender.url);
    if(!ownBridge&&!site)throw new Error();
    const state=await engine.handle({type:'state'});
    const supported=ownBridge||supportedSite(state,sender.url);
    if(message.type==='quickState')return supported?{...publicState(state),enabled:true}:{enabled:false};
    // In-page tools: results only, never the API key; only on account sites.
    if(own(QUICK_TOOLS,message.type)){if(!supported||ownBridge)throw new Error();return await QUICK_TOOLS[message.type]();}
    if(!supported||!state.profiles.some(p=>p.id===message.id))throw new Error();
    if(message.type==='quickRename'){if(ownBridge)throw new Error();return await quickRename(message,state);}
    if(message.type==='quickApply'&&ownBridge) {
      const result=await engine.handle({type:'switch',id:message.id,browserReset:true,allowNativeAttributeMismatch:true,allowMissingNativeExpiry:true,replacePending:true},{tab:sender.tab,reuseDestinationTab:true});
      return {completed:true,message:result.lastAttempt?.status==='failed'?'帳號 Cookie 已套用，但網址未能開啟，請回帳號管理器重試。':'帳號 Cookie 已套用並開啟網站；是否登入以網站畫面為準。'};
    }
    if(message.type!=='quickStart'||ownBridge||state.operation?.busy||state.operation?.stalled||busyTabs.has(sender.tab.id))throw new Error();
    busyTabs.add(sender.tab.id);
    try {
      const live=await AccountAPI.call('tabs.get',sender.tab.id);
      // Same site, not the exact address: pages that change their address by
      // script (single-page sites) made the old exact match refuse every tap.
      const current=webUrl(live?.url);
      if(live?.incognito!==false||!current||current.origin!==site.origin||!supportedSite(state,live.url))throw new Error();
      await AccountAPI.call('tabs.update',sender.tab.id,{url:bridge+'#'+new URLSearchParams({id:message.id,request:crypto.randomUUID()}),active:true});
      return {started:true};
    } finally {busyTabs.delete(sender.tab.id);}
  }
  AccountAPI.native.runtime.onMessage.addListener((message,sender,sendResponse)=>{
    if(!sender||sender.id!==AccountAPI.native.runtime.id||sender.tab?.incognito){sendResponse({ok:false,error:'請在一般瀏覽模式操作。'});return false;}
    const isQuick=['quickState','quickStart','quickApply','quickRename'].includes(message?.type)||own(QUICK_TOOLS,message?.type);
    if(!isQuick&&!sender.url?.startsWith(base)){sendResponse({ok:false,error:'不支援的操作。'});return false;}
    const work=isQuick?quick(message,sender):own(MANAGER_TOOLS,message?.type)?MANAGER_TOOLS[message.type](message):engine.handle(message,{tab:sender.tab});
    work.then(data=>sendResponse({ok:true,data}),error=>sendResponse({ok:false,error:error.safeMessage||'操作未完成，請重新開啟切換選單後再試。'}));
    return true;
  });
})();
