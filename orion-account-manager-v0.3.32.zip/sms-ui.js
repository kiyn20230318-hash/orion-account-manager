(() => {
  'use strict';
  // Manager-page controls for the IP lookup and the SMS-number API. All network
  // calls happen in the background page; this page never sends the key elsewhere.
  const $ = id => document.getElementById(id);
  const ui = {ip:$('tool-ip'),number:$('tool-number'),code:$('tool-code'),ipResult:$('tool-ip-result'),smsResult:$('tool-sms-result'),phone:$('tool-phone'),codeValue:$('tool-code-value'),
    status:$('tool-sms-status'),copyPhone:$('tool-copy-phone'),copyCode:$('tool-copy-code'),settings:$('tool-settings'),key:$('sms-api-key'),keyHint:$('sms-key-hint'),
    project:$('sms-project-id'),settingsOpen:$('tool-settings-open'),dock:$('quick-dock'),country:$('sms-country-code'),save:$('sms-save'),clear:$('sms-clear-key'),settingsStatus:$('sms-settings-status')};
  const STATUS_TEXT = {waiting:'等待簡訊中',received:'已收到簡訊',timeout:'號碼已逾時，未收到簡訊',released:'號碼已釋放'};
  const WAIT_SECONDS = 40;
  let settings = {hasKey:false,current:null}, polling = null, working = false;

  async function send(type, extra = {}, limitMs = 30000) {
    let timer;
    try {
      const reply = await Promise.race([AccountAPI.call('runtime.sendMessage',{type,...extra}),new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('背景沒有回應，請稍後再試。')),limitMs);})]);
      if (!reply || !reply.ok) throw new Error(reply && reply.error ? String(reply.error).slice(0,200) : '操作未完成。');
      return reply.data;
    } finally { clearTimeout(timer); }
  }
  function showCurrent(current, extra = '') {
    ui.smsResult.hidden = !current;
    if (!current) return;
    ui.phone.textContent = current.dialNumber || current.phoneNumber;
    ui.codeValue.textContent = current.code || '—';
    ui.copyCode.disabled = !current.code;
    ui.status.textContent = (STATUS_TEXT[current.statusText] || '狀態未確認') + (extra ? '；' + extra : '');
  }
  function renderSettings() {
    ui.keyHint.textContent = settings.hasKey ? '已儲存 ' + settings.keyHint : '尚未儲存 API Key';
    if (!ui.project.matches(':focus')) ui.project.value = String(settings.projectId || 1115);
    if (!ui.country.matches(':focus')) ui.country.value = '+' + (settings.countryCode || '852');
    ui.number.textContent = '取號';
    ui.number.title = (settings.projectId || 1115) === 1115 ? '取得香港號碼（子項目 1115）' : '取得號碼（子項目 ' + settings.projectId + '）';
    if (!settings.hasKey) ui.settings.open = true;
    showCurrent(settings.current);
    lock();
  }
  function lock() {
    ui.ip.disabled = working;
    ui.number.disabled = working || Boolean(polling) || !settings.hasKey;
    ui.code.disabled = (working && !polling) || !settings.hasKey || !settings.current;
    ui.save.disabled = ui.clear.disabled = working;
  }
  async function load() {
    try { settings = await send('smsSettings'); renderSettings(); }
    catch (error) { ui.settingsStatus.textContent = error.message; }
  }
  async function run(task) {
    if (working) return;
    working = true; lock();
    try { await task(); } finally { working = false; lock(); }
  }
  ui.ip.addEventListener('click', () => run(async () => {
    ui.ipResult.hidden = false; ui.ipResult.textContent = '正在查詢目前 IP…';
    try {
      const r = await send('ipLookup');
      ui.ipResult.textContent = '目前 IP：' + r.ip + ([r.country, r.region || r.city].filter(Boolean).length ? '（' + [r.country, r.region || r.city].filter(Boolean).join(' · ') + '）' : '') + (r.org ? ' ' + r.org : '');
    } catch (error) { ui.ipResult.textContent = error.message; }
  }));
  ui.number.addEventListener('click', () => {
    const c = settings.current;
    if (c && c.statusText === 'waiting' && !c.code && !window.confirm('目前號碼 ' + (c.dialNumber || c.phoneNumber) + ' 尚未收到驗證碼。\n\n仍要再取得一個新號碼？（可能重複扣款）')) return;
    run(async () => {
      ui.smsResult.hidden = false; ui.status.textContent = '正在取得號碼…';
      try { settings.current = await send('smsGetNumber'); showCurrent(settings.current, '可在網站輸入號碼後按「取得驗證碼」'); }
      catch (error) { ui.status.textContent = error.message; }
    });
  });
  // The background waits up to 40 s, then blacklists the number and fetches
  // one new number. This page only shows a countdown and the outcome.
  function outcomeText(r) {
    if (r.outcome === 'received') return '已收到驗證碼';
    if (r.outcome === 'cancelled') return '已停止等待。';
    if (r.outcome === 'changed') return '號碼已更換，請重新按「取得驗證碼」。';
    if (r.outcome === 'replaced') return WAIT_SECONDS + ' 秒未收到：' + (r.blacklisted ? '已拉黑 ' + r.previousNumber : '拉黑 ' + r.previousNumber + ' 未成功（' + (r.blacklistError || '原因未知') + '）') + '；' +
      (r.current ? '已自動換新號碼，請在網站改填新號碼並重新發送，再按「取得驗證碼」。' : '取得新號碼失敗：' + (r.numberError || '原因未知'));
    return '';
  }
  function stopPolling(message) {
    if (polling) { clearInterval(polling.timer); polling = null; }
    ui.code.textContent = '取碼';
    if (message) ui.status.textContent = message;
    lock();
  }
  ui.code.addEventListener('click', async () => {
    if (polling) { stopPolling('正在停止等待…'); send('smsCancelWait').catch(() => {}); return; }
    if (!settings.current) return;
    const started = Date.now(), mine = polling = {timer: null};
    const tick = () => { const left = Math.max(0, WAIT_SECONDS - Math.floor((Date.now() - started) / 1000)); ui.code.textContent = '停止 ' + left; ui.status.textContent = '等待簡訊中，' + (left ? '剩 ' + left + ' 秒；未收到會自動拉黑並換號' : '正在拉黑並換號…'); };
    mine.timer = setInterval(tick, 1000); tick(); lock();
    try {
      const r = await send('smsAwaitCode', {}, (WAIT_SECONDS + 60) * 1000);
      if (r.current) { settings.current = r.current; showCurrent(r.current); }
      if (polling === mine) stopPolling(outcomeText(r)); else ui.status.textContent = outcomeText(r);
      if (r.outcome === 'received' && r.current?.code) ui.codeValue.textContent = r.current.code;
    } catch (error) { if (polling === mine) stopPolling(error.message); else ui.status.textContent = error.message; }
  });  async function copy(text, button) {
    if (!text || text === '—') return;
    try { await navigator.clipboard.writeText(text); button.textContent = '已複製'; }
    catch (_) { button.textContent = '請長按'; }
    setTimeout(() => { button.textContent = '複製'; }, 1500);
  }
  ui.copyPhone.addEventListener('click', () => copy(ui.phone.textContent, ui.copyPhone));
  ui.copyCode.addEventListener('click', () => copy(ui.codeValue.textContent, ui.copyCode));
  // Tapping the number or code itself copies it too (bigger target on a phone).
  ui.phone.addEventListener('click', () => copy(ui.phone.textContent, ui.copyPhone));
  ui.codeValue.addEventListener('click', () => copy(ui.codeValue.textContent, ui.copyCode));
  ui.save.addEventListener('click', () => run(async () => {
    const input = {projectId: ui.project.value, countryCode: ui.country.value};
    if (ui.key.value.trim()) input.apiKey = ui.key.value;
    try { settings = await send('smsSaveSettings', input); ui.key.value = ''; ui.settingsStatus.textContent = '已儲存。'; renderSettings(); }
    catch (error) { ui.settingsStatus.textContent = error.message; }
  }));
  ui.clear.addEventListener('click', () => {
    if (!settings.hasKey || !window.confirm('清除已儲存的 API Key？')) return;
    run(async () => {
      try { settings = await send('smsSaveSettings', {apiKey:''}); ui.settingsStatus.textContent = '已清除 API Key。'; renderSettings(); }
      catch (error) { ui.settingsStatus.textContent = error.message; }
    });
  });
  addEventListener('pagehide', () => stopPolling());
  ui.settingsOpen.addEventListener('click', () => {
    ui.settings.open = true;
    ui.settings.scrollIntoView({block:'center', behavior:'smooth'});
    setTimeout(() => ui.key.focus({preventScroll:true}), 250);
  });
  // Keep page content and toasts clear of the fixed dock, whatever its height.
  const dockHeight = () => document.documentElement.style.setProperty('--dock-h', Math.ceil(ui.dock.getBoundingClientRect().height) + 'px');
  if (typeof ResizeObserver === 'function') new ResizeObserver(dockHeight).observe(ui.dock);
  dockHeight();
  load();
})();
