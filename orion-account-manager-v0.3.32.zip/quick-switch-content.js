(function () {
  'use strict';
  if(window.top!==window)return;
  if(globalThis.__orionQuickRefresh){globalThis.__orionQuickRefresh();return;}
  const native=globalThis.browser||globalThis.chrome;
  function send(message) {
    if(globalThis.browser)return native.runtime.sendMessage(message);
    return new Promise((resolve,reject)=>native.runtime.sendMessage(message,result=>native.runtime.lastError?reject(new Error('連線中斷')):resolve(result)));
  }
  // Positions live in extension storage, never in the website's own storage.
  function loadPosition(key){
    try{
      const area=native.storage?.local;if(!area)return Promise.resolve(null);
      if(globalThis.browser)return Promise.resolve(area.get(key)).then(r=>r?.[key]||null,()=>null);
      return new Promise(resolve=>area.get(key,r=>resolve(native.runtime.lastError?null:r?.[key]||null)));
    }catch(_){return Promise.resolve(null);}
  }
  function savePosition(key,value){try{const area=native.storage?.local;if(!area)return;const r=globalThis.browser?area.set({[key]:value}):area.set({[key]:value},()=>void native.runtime.lastError);if(r?.catch)r.catch(()=>{});}catch(_){}}
  let checking=false,timer=null,attempt=0,mounted=[],enabled=false,repairs=0,updateSwitcher=null;
  async function refresh(){
    if(checking)return;
    checking=true;
    try {
      const first=await Promise.race([send({type:'quickState'}),new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error()),4000);})]);
      clearTimeout(timer);
      if(!first?.ok)throw new Error();
      attempt=0;
      repairs=0;
      enabled=first.data.enabled===true;
      if(!enabled){mounted.forEach(node=>node.remove());return;}
      if(mounted.length){mounted.forEach(node=>{if(!node.isConnected)document.documentElement.append(node);});updateSwitcher?.(first.data);return;}
      if(!document.querySelector('orion-account-switcher'))mounted=[mountSwitcher(first),mountTools()];
    }catch(_){if(attempt++<3)setTimeout(refresh,1000*attempt);}
    finally{clearTimeout(timer);checking=false;}
  }
  globalThis.__orionQuickRefresh=refresh;
  window.addEventListener('pageshow',refresh);
  window.addEventListener('focus',refresh);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh();});
  // A site replacing its document children must not permanently remove the entries.
  new MutationObserver(()=>{if(enabled&&mounted.some(node=>!node.isConnected)&&repairs++<3)mounted.forEach(node=>{if(!node.isConnected)document.documentElement.append(node);});}).observe(document.documentElement,{childList:true});
  refresh();

  // The switch menu is a temporary overlay: it must always cover the tool bar.
  function createHost(tag,place,z=2147483647){
    const host=document.createElement(tag);
    host.style.cssText='all:initial!important;position:fixed!important;'+place+'z-index:'+z+'!important;display:block!important;';
    return host;
  }
  // Drag by any of `handles` (8 px threshold, so a tap still taps). The click
  // that ends a drag is swallowed. Position is clamped to the screen and kept
  // as a screen ratio so rotation and other pages reuse it.
  function draggable(host,shadow,handles,key,onMove){
    let drag=null,suppress=false,ratio=null;
    function place(left,top){
      const w=innerWidth,h=innerHeight,r=host.getBoundingClientRect(),bw=r.width||96,bh=r.height||44;
      left=Math.min(Math.max(4,left),Math.max(4,w-bw-4));top=Math.min(Math.max(4,top),Math.max(4,h-bh-4));
      host.style.setProperty('left',left+'px','important');host.style.setProperty('top',top+'px','important');
      host.style.setProperty('right','auto','important');host.style.setProperty('bottom','auto','important');
      ratio={x:w?left/w:0,y:h?top/h:0};onMove?.();
    }
    const reclamp=()=>{const r=host.getBoundingClientRect();if(ratio)place(ratio.x*innerWidth,ratio.y*innerHeight);else if(r.right>innerWidth||r.bottom>innerHeight)place(r.left,r.top);onMove?.();};
    loadPosition(key).then(saved=>{if(saved&&Number.isFinite(saved.x)&&Number.isFinite(saved.y)&&!drag)place(saved.x*innerWidth,saved.y*innerHeight);else onMove?.();});
    addEventListener('resize',reclamp);
    // Content can grow after placement (numbers, messages): keep it on screen.
    if(typeof ResizeObserver==='function')new ResizeObserver(()=>{if(!drag)reclamp();}).observe(host);
    // Movement is followed on the window from the press on, so a fast drag that
    // leaves the button before the threshold is not lost. Pointer capture is
    // taken only once really dragging: capturing on press would retarget a plain
    // tap's click away from the tapped button.
    function move(event){
      if(!drag||event.pointerId!==drag.id)return;
      const dx=event.clientX-drag.x,dy=event.clientY-drag.y;
      if(!drag.moved&&Math.hypot(dx,dy)<8)return;
      if(!drag.moved){try{drag.handle.setPointerCapture(event.pointerId);}catch(_){}}
      drag.moved=true;host.classList.add('dragging');if(event.cancelable)event.preventDefault();
      place(drag.left+dx,drag.top+dy);
    }
    function end(event){
      if(!drag||event.pointerId!==drag.id)return;
      // Swallow only the click this drag itself produces (cleared by the next press).
      if(drag.moved){suppress=true;if(ratio)savePosition(key,ratio);}
      host.classList.remove('dragging');drag=null;
      removeEventListener('pointermove',move,true);removeEventListener('pointerup',end,true);removeEventListener('pointercancel',end,true);
    }
    for(const handle of handles){
      handle.addEventListener('pointerdown',event=>{
        if(!event.isTrusted||(event.button!==undefined&&event.button>0))return;
        suppress=false;
        const r=host.getBoundingClientRect();
        drag={id:event.pointerId,x:event.clientX,y:event.clientY,left:r.left,top:r.top,moved:false,handle};
        addEventListener('pointermove',move,true);addEventListener('pointerup',end,true);addEventListener('pointercancel',end,true);
      });
    }    shadow.addEventListener('click',event=>{if(suppress){suppress=false;event.stopPropagation();event.preventDefault();}},true);
    return {reclamp};
  }
  // Avatar text: a trailing number/code (帳號 05 → 05, HK-03 → 03) tells numbered
  // accounts apart better than their shared first character.
  function avatarText(name){const s=String(name||'').trim(),m=s.match(/(?:^|[^A-Za-z0-9])([A-Za-z0-9]{1,4})$/);return (m?m[1]:[...s][0]||'#').toUpperCase();}
  const BASE_CSS=':host{color-scheme:light}*{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:focus-visible,input:focus-visible{outline:3px solid #8fc2b8;outline-offset:2px}';

  function mountSwitcher(first){
  // Same layer as the tool bar while closed; raised above it only while its menu is open.
  const host=createHost('orion-account-switcher','right:8px!important;top:38%!important;',2147483646);
  const raise=up=>host.style.setProperty('z-index',up?'2147483647':'2147483646','important');
  const shadow=host.attachShadow({mode:'closed'}),style=document.createElement('style');
  style.textContent=BASE_CSS+`.wrap{font:15px/1.5 system-ui,sans-serif;color:#1c2c36;position:relative}.toggle{display:block;max-width:150px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;border:1px solid #ffffff90;border-radius:22px;padding:8px 14px;min-height:44px;font-weight:600;background:#0f6b5fed;color:white;box-shadow:0 2px 10px #0002;touch-action:none;user-select:none;-webkit-user-select:none;-webkit-touch-callout:none}:host(.dragging) .toggle{opacity:.85;box-shadow:0 6px 18px #0004}.panel{position:absolute;right:0;top:50px;width:min(300px,calc(100vw - 24px));max-height:60vh;overflow:auto;border-radius:18px;background:#f8f8f2;box-shadow:0 6px 30px #0003;padding:14px;border:1px solid #dce1db}.panel.up{top:auto;bottom:50px}.panel[hidden]{display:none}.top{display:flex;align-items:center;justify-content:space-between;gap:8px}.title{font-weight:700}.close{border:0;background:none;font-size:22px;min-width:44px;min-height:44px;color:#53656a}input{width:100%;border:1px solid #d8ded8;border-radius:12px;background:white;padding:10px 12px;margin:8px 0;font-size:16px}input[hidden]{display:none}.row{display:flex;align-items:center;gap:10px;width:100%;min-height:52px;text-align:left;border:1px solid #e3e7e0;border-radius:12px;padding:6px 10px;margin:6px 0;background:white;color:#1c2c36}.row:active:enabled{transform:scale(.98)}.row:disabled{opacity:.55}.row.active{border-color:#0f6b5f;box-shadow:0 0 0 1px #0f6b5f inset}.initial{flex:none;display:grid;place-items:center;width:36px;height:34px;border-radius:10px;background:#eef1ea;color:#5d6c73;font-weight:700;font-size:13px;letter-spacing:-.02em}.row.active .initial{background:#0f6b5f;color:white}.name{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:600}.current{flex:none;font-size:11px;color:#0f6b5f;background:#e3efe8;border-radius:999px;padding:1px 8px}.count{font-size:12px;color:#65736e;font-weight:500;margin-left:6px}.note{margin:8px 0 0;font-size:12px;color:#65736e}.status{font-size:13px;color:#874337;overflow-wrap:anywhere}.status.ok{color:#1f6b4f}.item{display:flex;gap:6px;align-items:stretch;margin:6px 0}.item .row{margin:0;flex:1;min-width:0}.edit{flex:none;width:44px;min-height:52px;border:1px solid #e3e7e0;border-radius:12px;background:white;color:#53656a;font-size:17px;padding:0}.edit:disabled{opacity:.45}.renamer{display:flex;gap:6px;align-items:center;margin:6px 0;padding:6px;border:1px solid #0f6b5f;border-radius:12px;background:white}.renamer input{margin:0;flex:1;min-width:0;padding:9px 10px}.mini{flex:none;min-height:44px;min-width:52px;border:1px solid #d8ded8;border-radius:10px;background:#eef1ea;color:#1c2c36;padding:4px 10px;font-weight:600}.mini.primary{background:#0f6b5f;border-color:#0f6b5f;color:white}.mini:disabled,.renamer input:disabled{opacity:.55}`;
  const wrap=document.createElement('div');wrap.className='wrap';
  wrap.innerHTML='<button class="toggle" aria-label="快速切換帳號（可拖曳移動）" aria-expanded="false">⇄ 切換</button><section class="panel" aria-label="切換帳號" hidden><div class="top"><span class="title">切換帳號<span class="count"></span></span><button class="close" aria-label="關閉切換選單">×</button></div><input type="search" placeholder="搜尋帳號" aria-label="搜尋帳號"><div class="status" role="status"></div><div class="list"></div><p class="note">切換會先清除一般網站的登入與資料；帳號庫保留。按 ✎ 可改名。</p></section>';
  shadow.append(style,wrap);document.documentElement.append(host);
  const toggle=shadow.querySelector('.toggle'),panel=shadow.querySelector('.panel'),search=shadow.querySelector('input'),list=shadow.querySelector('.list'),status=shadow.querySelector('.status');
  let state=first.data,working=false,opening=0,editingId=null,renaming=false;
  // Show which account is active without opening the menu.
  function label(data){
    const active=data?.profiles?.find(p=>p.id===data.activeId)?.name||'';
    const short=active.length>7?active.slice(0,6)+'…':active;
    toggle.textContent='⇄ '+(short||'切換');
    toggle.setAttribute('aria-label',(active?'目前帳號：'+active+'。':'')+'快速切換帳號（可拖曳移動）');
  }
  label(state);updateSwitcher=data=>{state=data;label(data);};
  // Keep the open panel fully on screen wherever the entry was dragged.
  function orientPanel(){
    const r=host.getBoundingClientRect(),pw=Math.min(300,innerWidth-24);
    let x=r.left+r.width/2<innerWidth/2?r.left:r.right-pw;
    x=Math.min(Math.max(8,x),Math.max(8,innerWidth-pw-8));
    panel.style.left=(x-r.left)+'px';panel.style.right='auto';
    const up=r.top>innerHeight/2;panel.classList.toggle('up',up);
    panel.style.maxHeight=Math.max(160,up?r.top-16:innerHeight-r.bottom-16)+'px';
  }
  draggable(host,shadow,[toggle],'quickSwitchPosition',orientPanel);
  function say(text,ok){status.textContent=text||'';status.classList.toggle('ok',Boolean(ok&&text));}
  // Inline rename: only the name changes (the manager's own save keeps the
  // Cookie and address, and refuses a name another account already uses).
  function renameForm(p){
    const form=document.createElement('form');form.className='renamer';
    const input=document.createElement('input');input.type='text';input.maxLength=100;input.value=p.name;input.autocomplete='off';input.setAttribute('aria-label','新名稱（原為 '+p.name+'）');
    const save=document.createElement('button');save.type='submit';save.className='mini primary';save.textContent='儲存';
    const cancel=document.createElement('button');cancel.type='button';cancel.className='mini';cancel.textContent='取消';
    form.append(input,save,cancel);
    const stop=()=>{editingId=null;render();};
    cancel.addEventListener('click',event=>{if(event.isTrusted&&!renaming){say('');stop();}});
    input.addEventListener('keydown',event=>{if(event.key==='Escape'){event.stopPropagation();if(!renaming){say('');stop();}}});
    form.addEventListener('submit',async event=>{
      event.preventDefault();
      if(!event.isTrusted||renaming)return;
      const name=input.value.trim();
      if(!name){say('名稱不可空白。');input.focus();return;}
      if(name===p.name){say('');stop();return;}
      renaming=true;input.disabled=save.disabled=cancel.disabled=true;say('正在儲存名稱…');
      // No switch or other edit while the library save is in flight.
      list.querySelectorAll('.row,.edit').forEach(button=>{button.disabled=true;});
      try{
        const r=await send({type:'quickRename',id:p.id,name});
        if(!r?.ok)throw new Error(r?.error||'');
        state=r.data;label(state);editingId=null;say('已改名為「'+name+'」。',true);
      }catch(error){say(error?.message&&error.message!=='連線中斷'?error.message:'改名未完成，請再試一次。');}
      finally{renaming=false;render();}
    });
    setTimeout(()=>{if(input.isConnected){input.focus();try{input.select();}catch(_){}}},0);
    return form;
  }
  function render() {
    list.replaceChildren();
    // Current account first; the rest keep their saved order. Search only when the list is long.
    search.hidden=state.profiles.length<=6;shadow.querySelector('.count').textContent=state.profiles.length?String(state.profiles.length):'';
    const rows=state.profiles.filter(p=>p.id===editingId||p.name.toLocaleLowerCase().includes(search.value.trim().toLocaleLowerCase())).sort((a,b)=>(b.id===state.activeId)-(a.id===state.activeId));
    if(editingId&&!state.profiles.some(p=>p.id===editingId))editingId=null;
    for(const p of rows) {
      if(p.id===editingId){list.append(renameForm(p));continue;}
      const item=document.createElement('div');item.className='item';
      const edit=document.createElement('button');edit.className='edit';edit.textContent='✎';edit.setAttribute('aria-label','改名：'+p.name);edit.disabled=working||renaming||Boolean(editingId);
      edit.addEventListener('click',event=>{if(!event.isTrusted||edit.disabled)return;editingId=p.id;say('');render();});
      const b=document.createElement('button');b.className='row'+(p.id===state.activeId?' active':'');b.disabled=working||renaming||state.busy||state.stalled;
      const initial=document.createElement('span');initial.className='initial';initial.textContent=avatarText(p.name);
      const name=document.createElement('span');name.className='name';name.textContent=p.name;b.append(initial,name);b.setAttribute('aria-label',p.name+(p.id===state.activeId?'（目前帳號）':''));
      if(p.id===state.activeId){const tag=document.createElement('span');tag.className='current';tag.textContent='目前';b.append(tag);}
      b.addEventListener('click',async event=>{
        if(!event.isTrusted||working||b.disabled)return;
        working=true;render();status.textContent='正在切換…';
        try {const r=await send({type:'quickStart',id:p.id});if(!r?.ok)throw new Error();}
        catch(_){status.textContent='切換未開始，請關閉選單後重試。';working=false;render();}
      });item.append(b,edit);list.append(item);
    }
    if(!rows.length){const empty=document.createElement('p');empty.textContent='沒有符合的帳號';list.append(empty);}
  }
  function close(){if(renaming)return;opening++;editingId=null;panel.hidden=true;raise(false);toggle.setAttribute('aria-expanded','false');toggle.focus();}
  toggle.addEventListener('click',async event=>{
    if(!event.isTrusted)return;
    if(!panel.hidden){close();return;}
    orientPanel();
    panel.hidden=false;raise(true);toggle.setAttribute('aria-expanded','true');editingId=null;say('讀取帳號…');list.replaceChildren();search.value='';
    const request=++opening;
    try {const r=await send({type:'quickState'});if(request!==opening)return;if(!r?.ok||!r.data.enabled)throw new Error();state=r.data;label(state);working=false;status.textContent=state.stalled?'上次操作仍在等待瀏覽器回覆，請稍後再試。':state.busy?'正在切換，請稍候。':'';render();
      // Phones: do not pop the keyboard over the list on every open.
      if(!search.hidden&&!matchMedia('(pointer:coarse)').matches)search.focus();}
    catch(_){status.textContent='無法取得帳號，請重新整理網頁。';}
  });
  shadow.querySelector('.close').addEventListener('click',close);
  search.addEventListener('input',render);
  shadow.addEventListener('keydown',event=>{if(event.key==='Escape')close();});
  return host;
  }

  // Separate draggable bar: number / code / IP. Results only; the API key stays
  // in the extension. 40 s without a code: the extension blacklists the number
  // and fetches one new number (see sms-tools.js). Tapping the 6-dot button
  // folds the bar to just that button; tapping again unfolds it.
  // The website field the user last tapped, so 填入 can put the value there.
  let lastField=null;
  const FIELD_SKIP=['hidden','checkbox','radio','button','submit','reset','file','image','range','color'];
  document.addEventListener('focusin',event=>{
    const el=event.composedPath?.()[0]||event.target;
    if((el instanceof HTMLInputElement&&!FIELD_SKIP.includes(el.type))||el instanceof HTMLTextAreaElement)lastField=el;
  },true);
  function fillField(text){
    const el=lastField;
    if(!el||!el.isConnected||el.disabled||el.readOnly)return false;
    // Use the native setter and fire input/change so script-driven forms see it.
    const proto=el instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
    try{el.focus({preventScroll:true});}catch(_){el.focus();}
    Object.getOwnPropertyDescriptor(proto,'value').set.call(el,text);
    el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));
    return true;
  }
  function mountTools(){
  const host=createHost('orion-account-tools','left:8px!important;top:62%!important;',2147483646);
  const shadow=host.attachShadow({mode:'closed'}),style=document.createElement('style');
  style.textContent=BASE_CSS+`.bar{font:14px/1.4 system-ui,sans-serif;color:#1c2c36;background:#f8f8f2f2;border:1px solid #dce1db;border-radius:14px;box-shadow:0 2px 12px #0002;padding:6px;width:max-content;max-width:calc(100vw - 16px);touch-action:none;user-select:none;-webkit-user-select:none;-webkit-touch-callout:none}.bar.folded{padding:3px;border-radius:14px}:host(.dragging) .bar{opacity:.85;box-shadow:0 6px 18px #0004}.buttons{display:flex;gap:6px;align-items:center}.folded .tool,.folded .out{display:none!important}.grip{width:44px;height:44px;min-width:44px;border:0;border-radius:10px;background:transparent;color:#7d8a83;display:grid;place-items:center;padding:0;position:relative}.grip svg{width:18px;height:26px;fill:currentColor}.grip.waiting{background:#fff4d6;color:#a06a00}.grip.ready{background:#e1f2ea;color:#1f6b4f}.grip.ready::after,.grip.waiting::after{content:'';position:absolute;top:6px;right:6px;width:8px;height:8px;border-radius:50%;background:currentColor}.tool{min-height:44px;min-width:52px;border:1px solid #d8ded8;border-radius:10px;background:white;color:#1c2c36;padding:6px 10px;font-variant-numeric:tabular-nums}.tool.primary{background:#326b62;color:white;border-color:#326b62}.tool:disabled{opacity:.5}.out{margin-top:6px;padding:4px 6px;border-radius:10px;background:white;font-size:13px;max-width:300px;overflow-wrap:anywhere}.out[hidden],.line[hidden]{display:none}.line{display:flex;align-items:center;gap:6px;margin:2px 0}.line span{font-size:12px;color:#65736e;min-width:38px}.value{flex:1;border:0;background:none;text-align:left;font-size:17px;letter-spacing:.03em;font-weight:700;color:#1c2c36;padding:6px 2px;min-height:40px;font-variant-numeric:tabular-nums;user-select:text;-webkit-user-select:text}.value.fresh{color:#1f6b4f;animation:flash 1.2s ease-out 2}@keyframes flash{50%{background:#e1f2ea}}.act{border:0;background:#e8eee9;border-radius:8px;min-height:38px;padding:4px 9px;color:#1c2c36}.act.fill{background:#326b62;color:white}.act:disabled{opacity:.4}.hint{font-size:12px;color:#65736e;margin:2px 4px 2px}`;
  const bar=document.createElement('div');bar.className='bar';bar.setAttribute('role','group');bar.setAttribute('aria-label','號碼與 IP 工具（可拖曳移動）');
  bar.innerHTML='<div class="buttons"><button class="grip" aria-label="收合號碼工具（可拖曳）" aria-expanded="true"><svg viewBox="0 0 12 18" aria-hidden="true"><circle cx="3" cy="3" r="1.8"/><circle cx="9" cy="3" r="1.8"/><circle cx="3" cy="9" r="1.8"/><circle cx="9" cy="9" r="1.8"/><circle cx="3" cy="15" r="1.8"/><circle cx="9" cy="15" r="1.8"/></svg></button><button class="tool" data-tool="number">取號</button><button class="tool primary" data-tool="code">取碼</button><button class="tool" data-tool="ip">IP</button></div>'
    +'<div class="out sms-out" role="status" hidden><div class="line"><span>號碼</span><button class="value phone" data-copy="phone" aria-label="複製號碼">—</button><button class="act fill" data-fill="phone">填入</button><button class="act" data-copy="phone">複製</button></div><div class="line"><span>驗證碼</span><button class="value code" data-copy="code" aria-label="複製驗證碼">—</button><button class="act fill" data-fill="code">填入</button><button class="act" data-copy="code">複製</button></div><p class="hint sms-status"></p></div><p class="out ip-out" role="status" hidden></p>';
  shadow.append(style,bar);document.documentElement.append(host);
  const drag=draggable(host,shadow,[bar],'quickToolsPosition');
  const grip=shadow.querySelector('.grip');
  const tool=name=>shadow.querySelector('[data-tool="'+name+'"]'),ipOut=shadow.querySelector('.ip-out'),smsOut=shadow.querySelector('.sms-out');
  const phoneOut=shadow.querySelector('.value.phone'),codeOut=shadow.querySelector('.value.code'),smsStatus=shadow.querySelector('.sms-status');
  const STATUS_TEXT={waiting:'等待簡訊中',received:'已收到簡訊',timeout:'號碼已逾時',released:'號碼已釋放'};
  const WAIT_SECONDS=40;
  let tools={hasKey:false,current:null},toolBusy=false,waiting=null,folded=false,unseen=false;
  // Fold / unfold. Remembered in extension storage like the position.
  function setFolded(value,save){
    folded=value;bar.classList.toggle('folded',folded);
    grip.setAttribute('aria-expanded',String(!folded));grip.setAttribute('aria-label',folded?'展開號碼工具（可拖曳）':'收合號碼工具（可拖曳）');
    unseen=false; // Only results that arrive while folded light the dot.
    markGrip();if(save)savePosition('quickToolsFolded',folded);drag.reclamp();
  }
  function markGrip(){grip.classList.toggle('waiting',Boolean(waiting));grip.classList.toggle('ready',!waiting&&folded&&unseen);}
  loadPosition('quickToolsFolded').then(value=>{if(value===true)setFolded(true,false);});
  grip.addEventListener('click',event=>{if(event.isTrusted)setFolded(!folded,true);});
  async function ask(type){const r=await send({type});if(!r?.ok)throw new Error(r?.error||'操作未完成。');return r.data;}
  const shown=current=>current?.dialNumber||current?.phoneNumber||'';
  function showSms(current,extra){
    smsOut.hidden=!current&&!extra;
    for(const line of shadow.querySelectorAll('.line'))line.hidden=!current;
    phoneOut.textContent=shown(current)||'—';codeOut.textContent=current?.code||'—';
    for(const el of shadow.querySelectorAll('[data-copy="code"],[data-fill="code"]'))el.disabled=!current?.code;
    for(const el of shadow.querySelectorAll('[data-copy="phone"],[data-fill="phone"]'))el.disabled=!shown(current);
    smsStatus.textContent=extra||(current?STATUS_TEXT[current.statusText]||'':'');
    drag.reclamp();
  }
  function lockTools(){
    tool('ip').disabled=toolBusy&&!waiting;
    tool('number').disabled=toolBusy||Boolean(waiting)||!tools.hasKey;
    tool('code').disabled=(toolBusy&&!waiting)||!tools.hasKey||!tools.current;
    if(!waiting)tool('code').textContent='取碼';
    markGrip();
  }
  async function loadTools(){
    try{tools=await ask('quickSmsState');showSms(tools.current,tools.hasKey?'':'請先在帳號管理器儲存 API Key。');}
    catch(_){/* Tools stay disabled; switching is unaffected. */}
    lockTools();
  }
  async function runTool(task){if(toolBusy)return;toolBusy=true;lockTools();try{await task();}finally{toolBusy=false;lockTools();}}
  tool('ip').addEventListener('click',event=>{if(!event.isTrusted)return;runTool(async()=>{
    ipOut.hidden=false;ipOut.textContent='正在查詢 IP…';drag.reclamp();
    try{const r=await ask('quickIp');ipOut.textContent='目前 IP：'+r.ip+(r.country?'（'+r.country+'）':'');}
    catch(error){ipOut.textContent=error.message||'無法取得 IP。';}
    drag.reclamp();
  });});
  tool('number').addEventListener('click',event=>{
    if(!event.isTrusted)return;
    const c=tools.current;
    if(c&&c.statusText==='waiting'&&!c.code&&!window.confirm('目前號碼 '+shown(c)+' 尚未收到驗證碼，仍要取得新號碼？（可能重複扣款）'))return;
    runTool(async()=>{
      showSms(tools.current,'正在取得號碼…');
      try{tools.current=await ask('quickSmsNumber');showSms(tools.current,'已取得號碼：點網站的電話欄位後按「填入」，或按號碼複製。');if(folded){unseen=true;markGrip();}}
      catch(error){showSms(tools.current,error.message||'取得號碼失敗。');}
    });
  });
  function outcomeText(r){
    if(r.outcome==='received')return '已收到驗證碼：點網站的驗證碼欄位後按「填入」，或按驗證碼複製。';
    if(r.outcome==='cancelled')return '已停止等待。';
    if(r.outcome==='changed')return '號碼已更換，請重新按「取碼」。';
    if(r.outcome==='replaced')return WAIT_SECONDS+' 秒未收到：'+(r.blacklisted?'已拉黑舊號':'舊號拉黑未成功')+'；'+(r.current?'已換新號碼，請改填新號碼並重新發送，再按「取碼」。':'取得新號碼失敗：'+(r.numberError||'原因未知'));
    return '';
  }
  function stopWaiting(message){if(waiting){clearInterval(waiting.timer);waiting=null;}if(message)smsStatus.textContent=message;lockTools();}
  tool('code').addEventListener('click',async event=>{
    if(!event.isTrusted)return;
    if(waiting){stopWaiting('正在停止等待…');ask('quickSmsCancel').catch(()=>{});return;}
    if(!tools.current)return;
    const started=Date.now(),mine=waiting={timer:null};
    const tick=()=>{const left=Math.max(0,WAIT_SECONDS-Math.floor((Date.now()-started)/1000));tool('code').textContent='停止 '+left;smsStatus.textContent=left?'等待簡訊中（未收到 '+WAIT_SECONDS+' 秒會自動拉黑並換號）':'正在拉黑並換號…';};
    mine.timer=setInterval(tick,1000);smsOut.hidden=false;tick();lockTools();drag.reclamp();
    try{
      const r=await ask('quickSmsAwait');
      if(r.current)tools.current=r.current;
      showSms(tools.current);
      if(waiting===mine)stopWaiting(outcomeText(r));else smsStatus.textContent=outcomeText(r);
      if(r.outcome==='received'){codeOut.classList.add('fresh');setTimeout(()=>codeOut.classList.remove('fresh'),2600);}
      if((r.outcome==='received'||r.outcome==='replaced')&&folded){unseen=true;markGrip();}
    }catch(error){if(waiting===mine)stopWaiting(error.message||'取得驗證碼失敗。');else smsStatus.textContent=error.message||'取得驗證碼失敗。';}
    drag.reclamp();
  });
  for(const button of shadow.querySelectorAll('[data-copy]'))button.addEventListener('click',async event=>{
    if(!event.isTrusted)return;
    const text=(button.dataset.copy==='phone'?phoneOut:codeOut).textContent;if(!text||text==='—')return;
    const plain=button.classList.contains('act');
    try{await navigator.clipboard.writeText(text);if(plain)button.textContent='已複製';else smsStatus.textContent='已複製 '+text;}
    catch(_){if(plain)button.textContent='請長按';else smsStatus.textContent='無法自動複製，請長按號碼選取。';}
    if(plain)setTimeout(()=>{button.textContent='複製';},1500);
  });
  for(const button of shadow.querySelectorAll('[data-fill]'))button.addEventListener('click',event=>{
    if(!event.isTrusted)return;
    const text=(button.dataset.fill==='phone'?phoneOut:codeOut).textContent;if(!text||text==='—')return;
    if(fillField(text)){button.textContent='已填入';setTimeout(()=>{button.textContent='填入';},1500);}
    else smsStatus.textContent='請先點一下網站上要填的欄位，再按「填入」。';
  });
  lockTools();loadTools();
  // Refresh tool state when returning to the page (number may have changed elsewhere).
  document.addEventListener('visibilitychange',()=>{if(!document.hidden&&!waiting&&!toolBusy)loadTools();});
  return host;
  }
})();