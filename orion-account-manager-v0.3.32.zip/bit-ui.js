(() => {
  'use strict';
  // BitBrowser reader inside the batch-import dialog. The background page does
  // the network calls; each matched window becomes one source for the normal
  // batch preview, so names, duplicates and Cookie checks work as for files.
  const $ = id => document.getElementById(id);
  const ui = {box:$('bit-import'),base:$('bit-base'),names:$('bit-names'),browse:$('bit-browse'),fetch:$('bit-fetch'),browser:$('bit-browser'),query:$('bit-query'),
    queryGo:$('bit-query-go'),listSummary:$('bit-list-summary'),list:$('bit-list'),prev:$('bit-prev'),next:$('bit-next'),add:$('bit-add'),status:$('bit-status'),problems:$('bit-problems'),
    bulkEditor:$('bulk-editor')};
  if (!ui.box) return;
  const DEFAULT_BASE = 'http://127.0.0.1:54345';
  let working = false, page = 0, total = 0, items = [];
  const picked = new Map();

  async function send(type, extra = {}, limitMs = 30000) {
    let timer;
    try {
      const reply = await Promise.race([AccountAPI.call('runtime.sendMessage',{type,...extra}),new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('背景沒有回應，請稍後再試。')),limitMs);})]);
      if (!reply || !reply.ok) throw new Error(reply && reply.error ? String(reply.error).slice(0,400) : '操作未完成。');
      return reply.data;
    } finally { clearTimeout(timer); }
  }
  function status(text, kind = '') {
    ui.status.textContent = text || '';
    ui.status.hidden = !text;
    ui.status.className = 'bit-status' + (kind ? ' is-' + kind : '');
  }
  function lock() {
    const busy = Boolean(working);
    for (const el of [ui.browse, ui.fetch, ui.queryGo, ui.base, ui.names, ui.query]) el.disabled = busy;
    ui.prev.disabled = busy || page <= 0;
    ui.next.disabled = busy || (page + 1) * 100 >= total;
    ui.add.disabled = busy || !picked.size;
    ui.fetch.textContent = working === 'fetch' ? '正在讀取…' : '讀取並預覽';
  }
  async function run(kind, task) {
    if (working) return;
    working = kind; lock();
    try { await task(); } finally { working = false; lock(); }
  }
  // Re-read on every open: the batch form reset clears the field. An empty field
  // means "use the saved address" in the background as well.
  async function loadSettings() {
    try {
      const s = await send('bitSettings');
      // The loopback default only works on the computer itself: leave the field
      // empty there so the phone hint is visible.
      if (!ui.base.value.trim() && !s.isDefault) ui.base.value = s.baseUrl;
    } catch (_) { /* The first action reports its own error. */ }
  }
  const baseValue = () => ui.base.value.trim();
  // After a successful connection: keep the address.
  async function remember(baseUrl) {
    try {
      await send('bitSaveSettings', {baseUrl});
      if (baseUrl !== DEFAULT_BASE || baseValue()) ui.base.value = baseUrl;
    } catch (_) { /* Not fatal. */ }
  }
  function showProblems(results) {
    ui.problems.replaceChildren();
    for (const r of results) {
      if (r.status === 'found') continue;
      const li = document.createElement('li');
      li.textContent = r.input + '：' + (r.error || '未能讀取。');
      ui.problems.append(li);
    }
    ui.problems.hidden = !ui.problems.children.length;
  }
  // One window → one account source. The wrapper only adds the window name;
  // the Cookie array is passed on exactly as BitBrowser stored it.
  function toSources(results) {
    return results.filter(r => r.status === 'found').map(r => {
      const name = r.window.name || ('比特窗口 #' + (r.window.seq ?? r.window.id));
      return {name: '比特瀏覽器 · ' + name + (r.window.seq !== null && r.window.seq !== undefined ? ' #' + r.window.seq : ''), text: JSON.stringify({name, cookies: r.cookies})};
    });
  }
  ui.fetch.addEventListener('click', () => run('fetch', async () => {
    showProblems([]);
    const text = ui.names.value;
    if (!text.trim()) { status('請先輸入窗口名稱，或按「瀏覽窗口」勾選。', 'error'); ui.names.focus(); return; }
    status('正在連線比特瀏覽器並讀取 Cookie…');
    let data;
    try { data = await send('bitFetch', {baseUrl: baseValue(), text}, 300000); }
    catch (error) { status(error.message, 'error'); return; }
    await remember(data.baseUrl);
    showProblems(data.results);
    const failed = data.results.length - data.found;
    if (!data.found) { status('沒有讀到任何窗口的 Cookie，原因如下。', 'error'); return; }
    const detail = {sources: toSources(data.results), help: '來自比特瀏覽器 ' + data.found + ' 個窗口' + (failed ? '；另有 ' + failed + ' 個未讀取，原因列在上方「從比特瀏覽器讀取」。' : '。')};
    window.dispatchEvent(new CustomEvent('orion-bulk-sources', {detail}));
    if (detail.result === false) { status('已讀取 Cookie，但預覽未完成，請看下方錯誤訊息。', 'error'); return; }
    status('已讀取 ' + data.found + ' 個窗口的 Cookie' + (failed ? '，' + failed + ' 個未讀取（見下方）' : '') + '。請在預覽確認名稱後匯入。', failed ? 'warn' : 'ok');
  }));

  function renderList() {
    ui.list.replaceChildren();
    const nameCount = new Map();
    for (const item of items) { const key = item.name.trim().toLocaleLowerCase(); nameCount.set(key, (nameCount.get(key) || 0) + 1); }
    for (const item of items) {
      const label = document.createElement('label'); label.className = 'bit-item';
      const box = document.createElement('input'); box.type = 'checkbox'; box.checked = picked.has(item.id);
      // Blank or repeated names on this page are added as #序號 so they stay exact.
      const entry = !item.name || nameCount.get(item.name.trim().toLocaleLowerCase()) > 1 ? (item.seq !== null ? '#' + item.seq : '') : item.name;
      box.disabled = !entry;
      box.addEventListener('change', () => { if (box.checked) picked.set(item.id, entry); else picked.delete(item.id); lock(); });
      const text = document.createElement('span'); text.className = 'bit-item-text';
      const name = document.createElement('strong'); name.textContent = item.name || '（未命名）';
      const meta = document.createElement('small'); meta.textContent = [item.seq !== null ? '#' + item.seq : '', item.group, item.remark].filter(Boolean).join(' · ');
      text.append(name, meta); label.append(box, text); ui.list.append(label);
    }
    if (!items.length) { const p = document.createElement('p'); p.className = 'field-help'; p.textContent = '沒有符合的窗口。'; ui.list.append(p); }
    ui.listSummary.textContent = total ? '共 ' + total + ' 個窗口 · 第 ' + (page + 1) + ' 頁（每頁 100 個）' : '';
    ui.prev.hidden = ui.next.hidden = total <= 100;
    lock();
  }
  async function loadPage(next) {
    status('正在讀取窗口清單…');
    let data;
    try { data = await send('bitList', {baseUrl: baseValue(), query: ui.query.value.trim(), page: next}); }
    catch (error) { status(error.message, 'error'); return; }
    await remember(data.baseUrl);
    page = data.page; total = data.total; items = data.items;
    ui.browser.hidden = false; status(''); renderList();
  }
  ui.browse.addEventListener('click', () => run('list', () => loadPage(0)));
  ui.queryGo.addEventListener('click', () => run('list', () => loadPage(0)));
  ui.query.addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); run('list', () => loadPage(0)); } });
  ui.prev.addEventListener('click', () => run('list', () => loadPage(Math.max(0, page - 1))));
  ui.next.addEventListener('click', () => run('list', () => loadPage(page + 1)));
  ui.add.addEventListener('click', () => {
    const lines = ui.names.value.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
    const have = new Set(lines.map(s => s.toLocaleLowerCase()));
    let added = 0;
    for (const entry of picked.values()) if (entry && !have.has(entry.toLocaleLowerCase())) { lines.push(entry); have.add(entry.toLocaleLowerCase()); added++; }
    ui.names.value = lines.join('\n');
    picked.clear(); renderList();
    status(added ? '已加入 ' + added + ' 個窗口，按「讀取並預覽」即可讀取 Cookie。' : '所選窗口已在清單中。', 'ok');
  });
  ui.box.addEventListener('toggle', () => { if (ui.box.open) loadSettings(); });
  // Opening the batch dialog fresh: forget the previous list, keep the address.
  new MutationObserver(() => {
    if (!ui.bulkEditor) return;
    if (ui.bulkEditor.hidden) { picked.clear(); items = []; total = 0; ui.browser.hidden = true; ui.list.replaceChildren(); status(''); showProblems([]); }
    else if (ui.box.open) loadSettings();
  })
    .observe(ui.bulkEditor || ui.box, {attributes: true, attributeFilter: ['hidden']});
  lock();
})();
