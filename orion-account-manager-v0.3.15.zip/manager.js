(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const ui = Object.fromEntries(['main','notice','operation-status','operation-message','active-name','active-detail','profile-count','account-list','empty-state','empty-title','empty-description','search','add-button','refresh-button','recovery','recover-button','editor','editor-title','editor-fields','profile-form','profile-name','profile-url','cookie-file','cookie-text','file-label','preview-button','import-preview','preview-count','preview-domains','preview-warnings','form-error','save-button','cancel-editor','close-editor','edit-cookie-note','diagnostics-button','diagnostics-result','bulk-button','bulk-editor','bulk-form','bulk-fields','bulk-url','bulk-files','bulk-file-label','bulk-text','bulk-preview-button','bulk-preview','bulk-select-all','bulk-summary','bulk-rows','bulk-error','bulk-save-button','cancel-bulk','close-bulk'].map((id) => [id, $(id)]));
  let state = { profiles: [], activeId: null, pending: false };
  let loaded = false;
  let busy = false;
  let editingId = null;
  let saveRequestId = null;
  let saveRequestProfile = null;
  let preview = null;
  let duplicatePolicy = 'reject';
  let returnFocus = null;
  let bulkRows = [];
  let bulkRevision = 0;
  let bulkRequestId = null;
  let bulkRequestProfiles = null;
  let bulkValidationTimer = null;
  let bulkValidationPending = false;
  const bulkRowNodes = new Map();
  let inspectedProfile = null;
  let switchReport = null;
  let inspectorReturnFocus = null;
  let inspectorNativeFailure = false;
  const siteCopyRequests = new Map();
  let cookieProbeNotice = '';
  const MAX_IMPORT_BYTES = 4 * 1024 * 1024;
  const MAX_BATCH_BYTES = 12 * 1024 * 1024;
  const MAX_BATCH_ACCOUNTS = 100;
  const READ_TIMEOUT_MS = 15000;
  const WRITE_TIMEOUT_MS = 120000;
  const FILE_TIMEOUT_MS = 20000;
  const friendlyChecks = {
    'storage.local.get': '讀取帳號資料', 'storage.local.set': '儲存帳號資料',
    'cookies.getAll': '讀取 Cookie', 'cookies.set': '寫入 Cookie', 'cookies.remove': '移除 Cookie',
    'tabs.query': '讀取分頁清單', 'tabs.remove': '關閉相關分頁', 'tabs.create': '建立新分頁', 'tabs.update': '開啟目標網頁',
    operationState:'目前作業狀態', storageReadTest:'本機儲存讀取測試', profileHealth:'帳號資料完整性', recoveryState:'切換恢復狀態',
    activeAccountState:'目前套用帳號', storageBudget:'本機儲存用量', cookieReadTest:'Cookie 讀取測試', tabsReadTest:'分頁讀取測試', bulkParserTest:'批量解析自我測試', identitySupport:'新增與重試支援'
  };
  for (const id of ['invalid-records','invalid-records-message','discard-invalid-button','abandon-recovery-button','editor-refresh','bulk-refresh']) ui[id] = $(id);
  for (const id of ['switch-inspector','switch-inspector-account','switch-inspector-error','switch-inspector-result','close-switch-inspector','retry-switch-inspector','switch-inspector-refresh','done-switch-inspector','site-copy-panel','site-copy-detail','site-copy-button','site-copy-status']) ui[id] = $(id);
  for (const id of ['expiry-compatibility-panel','expiry-compatibility-detail','expiry-compatibility-consent','expiry-compatibility-button','expiry-other-differences']) ui[id] = $(id);
  for (const id of ['last-attempt-panel','last-attempt-result','inspector-attempt-panel','inspector-attempt-result']) ui[id] = $(id);
  for (const prefix of ['','inspector-']) for (const suffix of ['button','guidance','result']) ui[prefix+'cookie-probe-'+suffix] = $(prefix+'cookie-probe-'+suffix);
  for (const prefix of ['','inspector-']) for (const suffix of ['','-detail']) ui[prefix+'switch-blocker'+suffix] = $(prefix+'switch-blocker'+suffix);
  for (const id of ['native-compatibility-panel','native-compatibility-title','native-compatibility-detail','native-compatibility-button']) ui[id] = $(id);
  for (const id of ['native-recovery-button','native-recovery-detail']) ui[id] = $(id);
  const developerTools = $('developer-tools');
  let inspectorFromDeveloper = false;
  for (const id of ['active-status-details','operation-status','recovery','invalid-records']) $('developer-status').append($(id));
  function openDeveloper() {
    developerTools.hidden = false;
    document.querySelector('.app-shell').inert = true;
    document.body.classList.add('modal-open');
    developerTools.querySelector('[role="dialog"]').focus();
  }
  function closeDeveloper() {
    developerTools.hidden = true;
    document.querySelector('.app-shell').inert = false;
    document.body.classList.remove('modal-open');
    $('developer-toggle').focus();
  }
  $('developer-toggle').addEventListener('click', openDeveloper);
  $('developer-close').addEventListener('click', closeDeveloper);
  $('open-updates').addEventListener('click', () => { openDeveloper(); $('updates-panel').open = true; $('updates-panel').scrollIntoView({block:'start'}); $('update-check').focus(); });
  $('developer-inspect').addEventListener('click', () => { const profile = state.profiles.find(p => p.id === $('developer-profile').value); if(profile) openSwitchInspector(profile); });
  $('developer-strict').addEventListener('click', () => { const profile = state.profiles.find(p => p.id === $('developer-profile').value); if(profile) switchProfile(profile); });
  const NATIVE_COMPATIBILITY_NOTICE = '會清理相關舊 Cookie，再套用所選帳號並開啟網站。舊 Cookie 即使重複也可繼續；若寫入失敗，只復原可辨識項目，衝突資料留在本機備份。安全屬性與期限無法完整保證，登入以網站為準。';

  function element(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = String(text);
    return node;
  }
  function duplicateControl(id, label) {
    const container = element('div', 'duplicate-resolution');
    container.hidden = true;
    const field = element('label', 'field');
    const select = element('select');
    select.id = id;
    select.setAttribute('aria-label', label);
    for (const [value, text] of [['reject', '請選擇處理方式'], ['first', '同一 Cookie 保留檔案第一筆'], ['last', '同一 Cookie 保留檔案最後一筆']]) {
      const option = element('option', '', text);
      option.value = value;
      select.append(option);
    }
    field.append(element('span', '', '重複 Cookie 處理方式'), select);
    const help = element('p', 'hint', '一個帳號可包含多筆 Cookie；這是同一帳號資料內的 Cookie 重複，不是帳號數量。請確認來源只含同一帳號。第一筆／最後一筆是檔案順序，不代表新舊；請依匯出來源選擇。若無法判斷，請重新匯出單一帳號，勿合併不同帳號。');
    help.id = id + '-help';
    select.setAttribute('aria-describedby', help.id);
    container.append(field, help);
    return { container, select };
  }
  const singleDuplicates = duplicateControl('duplicate-policy', '重複 Cookie 處理方式');
  ui['form-error'].before(singleDuplicates.container);
  const bulkSelectionHelp = element('p', 'hint');
  bulkSelectionHelp.id = 'bulk-selection-help';
  bulkSelectionHelp.setAttribute('role', 'status');
  ui['bulk-summary'].after(bulkSelectionHelp);
  function resetDuplicateChoice() {
    duplicatePolicy = 'reject';
    singleDuplicates.select.value = duplicatePolicy;
    singleDuplicates.container.hidden = true;
  }
  function reveal(node) {
    if (node && !node.hidden) node.scrollIntoView({ block:'start' });
  }
  function errorMessage(error) {
    return String(error && error.message ? error.message : error || '發生未知錯誤，請稍後再試。').slice(0, 400);
  }
  function bounded(promise, delay, message) {
    let timer;
    return Promise.race([promise, new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error(message)), delay);
    })]).finally(() => clearTimeout(timer));
  }
  function operationBlocked() { return Boolean(state.operation && (state.operation.busy || state.operation.stalled)); }
  function writeBlocked() { return Boolean(state.pending) || operationBlocked(); }
  function switchBlocked() { return state.switchBlocker != null; }
  function nativeCompatibilityAvailable(profile = inspectedProfile) {
    if (!profile || !state.profiles.some(item => item.id === profile.id)) return false;
    const summary = profile?.id === inspectedProfile?.id ? switchReport?.summary : null;
    const allowed = summary && Object.prototype.hasOwnProperty.call(summary,'canUseNativeAttributeCompatibility') ? summary.canUseNativeAttributeCompatibility === true : true;
    return state.pending ? !operationBlocked() : allowed;
  }
  function nativeRecoveryAvailable() { return Boolean(state.pending) && (state.canUseNativeAttributeRecovery === true || switchReport?.summary?.canUseNativeAttributeRecovery === true); }
  async function syncOperationStatus() {
    try {
      const result = await bounded(globalThis.AccountAPI.call('runtime.sendMessage', { type:'operationStatus' }), READ_TIMEOUT_MS, '背景狀態查詢逾時。');
      if (result && result.ok && result.data && typeof result.data.busy === 'boolean') {
        state.operation = result.data;
        renderState();
      }
    } catch (_) { /* Keep the operation error; a read retry remains available. */ }
  }
  async function send(message) {
    if (!globalThis.AccountAPI) throw new Error('擴充套件通訊尚未就緒。請確認已安裝於 Orion，並重新開啟管理器。');
    const readOnly = ['state', 'diagnostics', 'operationStatus', 'inspectSwitch'].includes(message.type);
    let receivedReply = false;
    try {
      const result = await bounded(globalThis.AccountAPI.call('runtime.sendMessage', message), readOnly ? READ_TIMEOUT_MS : WRITE_TIMEOUT_MS,
        readOnly ? '讀取逾時。可按「重新整理」重試；若持續無回應，請完全關閉 Orion 再開啟。' : '操作回覆逾時，結果尚未確認；請先按「重新讀取狀態」或「重新整理」，不要重複送出。若仍無回應，請完全關閉 Orion 再開啟，依畫面提示恢復。');
      receivedReply = Boolean(result);
      if (!result || !result.ok) throw new Error(result && result.error ? result.error : '未收到擴充套件回應。請先重新整理確認結果，再決定是否重試。');
      return result.data;
    } catch (error) {
      if (!readOnly && !receivedReply) {
        state.operation = {busy:false, stalled:true, message:'尚未確認背景是否完成，已暫停資料變更。請重新讀取狀態；若持續無回應，請完全關閉 Orion 再開啟。'};
        renderState();
      }
      if (message.type !== 'operationStatus') await syncOperationStatus();
      throw error;
    }
  }
  function notify(message, type = '') {
    const text = String(message || '');
    ui.notice.replaceChildren();
    $('developer-message').textContent = text || '尚無提示';
    const firstSentence = text.split(/[。\n]/)[0];
    ui.notice.textContent = firstSentence.length > 72 ? firstSentence.slice(0,72) + '…' : firstSentence;
    if (type === 'error' && text) ui.notice.append(element('span','notice-help',' 完整原因可由右上角小點查看。'));
    ui.notice.className = 'notice' + (type ? ' is-' + type : '');
    ui.notice.hidden = !message;
    ui.notice.setAttribute('role', type === 'error' ? 'alert' : 'status');
  }
  function showFormError(message) {
    ui['form-error'].textContent = message;
    ui['form-error'].hidden = !message;
    ui['editor-refresh'].hidden = !message || !saveRequestId;
  }
  function updateLocks() {
    document.querySelectorAll('[data-lock]').forEach((button) => { button.disabled = busy || !loaded || writeBlocked(); });
    document.querySelectorAll('[data-switch]').forEach((button) => { button.disabled = busy || !loaded || writeBlocked() || switchBlocked(); });
    document.querySelectorAll('[data-native-switch]').forEach((button) => { button.disabled = busy || !loaded || operationBlocked() || !nativeCompatibilityAvailable({id:button.dataset.nativeSwitch}); });
    $('developer-inspect').disabled = busy || !loaded || !state.profiles.length;
    $('developer-strict').disabled = busy || !loaded || !state.profiles.length || writeBlocked() || switchBlocked();
    ui['refresh-button'].disabled = busy;
    ui['diagnostics-button'].disabled = busy;
    ui['recover-button'].disabled = busy || !loaded || operationBlocked();
    ui['abandon-recovery-button'].disabled = busy || !loaded || operationBlocked();
    ui['editor-refresh'].disabled = busy;
    ui['bulk-refresh'].disabled = busy;
    ui['editor-fields'].disabled = busy || writeBlocked();
    ui['save-button'].disabled = busy || !loaded || writeBlocked();
    ui['close-editor'].disabled = busy;
    ui['cancel-editor'].disabled = busy;
    ui['bulk-fields'].disabled = busy || !loaded || writeBlocked();
    ui['bulk-save-button'].disabled = busy || bulkValidationPending || !loaded || writeBlocked() || !bulkRows.some((row) => row.selected && !row.error);
    ui['close-bulk'].disabled = busy;
    ui['cancel-bulk'].disabled = busy;
    document.querySelectorAll('[data-inspect]').forEach((button) => { button.disabled = busy || !loaded; });
    ui['retry-switch-inspector'].disabled = busy;
    ui['switch-inspector-refresh'].disabled = busy;
    ui['close-switch-inspector'].disabled = busy;
    ui['done-switch-inspector'].disabled = busy;
    const copyRequest = inspectedProfile && siteCopyRequests.get(inspectedProfile.id);
    ui['site-copy-button'].disabled = busy || !loaded || writeBlocked() || !switchReport || !switchReport.summary.canCreateSiteCopy || Boolean(copyRequest && copyRequest.completed);
    ui['switch-inspector-refresh'].hidden = !copyRequest || !copyRequest.requestId || Boolean(copyRequest.completed && !copyRequest.needsRefresh);
    const compatibility = switchReport && switchReport.summary;
    const compatibilityAllowed = compatibility && compatibility.canUseMissingExpiryCompatibility === true;
    const compatibilityActionAllowed = compatibility && (compatibility.compatibilityAction === 'recover' ? Boolean(state.pending) && !operationBlocked() : compatibility.compatibilityAction === 'switch' && !writeBlocked() && !switchBlocked());
    ui['expiry-compatibility-consent'].disabled = busy || !loaded || !compatibilityAllowed || !compatibilityActionAllowed;
    ui['expiry-compatibility-button'].disabled = busy || !loaded || !compatibilityAllowed || !compatibilityActionAllowed || !ui['expiry-compatibility-consent'].checked;
    for (const prefix of ['','inspector-']) ui[prefix+'cookie-probe-button'].disabled = busy || !loaded || writeBlocked();
    ui['native-compatibility-button'].disabled = busy || !loaded || operationBlocked() || !(nativeRecoveryAvailable() || (!writeBlocked() && nativeCompatibilityAvailable()));
    ui['native-recovery-button'].disabled = busy || !loaded || operationBlocked() || !nativeRecoveryAvailable();
    ui.main.setAttribute('aria-busy', String(busy));
    ui['bulk-editor'].setAttribute('aria-busy', String(busy));
  }
  function setBusy(value) { busy = value; updateLocks(); }
  function displayDate(value) {
    const date = new Date(value);
    if (!value || Number.isNaN(date.getTime())) return '尚無更新時間';
    return '更新於 ' + date.toLocaleString('zh-TW', { month:'numeric', day:'numeric', hour:'2-digit', minute:'2-digit' });
  }
  function renderCards() {
    const expandedMenus = new Set([...ui['account-list'].querySelectorAll('.compact-account')].filter(card => card.querySelector('.account-menu')?.open).map(card => card.dataset.profileId));
    const query = ui.search.value.trim().toLocaleLowerCase();
    const profiles = state.profiles.filter(profile => [profile.name,profile.startUrl,...(profile.domains || [])].join(' ').toLocaleLowerCase().includes(query));
    ui['account-list'].replaceChildren();
    ui['profile-count'].textContent = String(state.profiles.length);
    ui['empty-state'].hidden = !loaded || profiles.length > 0;
    ui['empty-title'].textContent = query ? '沒有找到符合的帳號' : '尚未新增帳號';
    ui['empty-description'].textContent = query ? '試試其他名稱或網域。' : '按「新增」或「批量匯入」加入 Cookie 資料。';
    for (const profile of profiles) {
      const active = profile.id === state.activeId;
      const openCurrent = active && !profile.needsApply;
      const card = element('article','account-card compact-account' + (active ? ' is-active' : ''));
      card.dataset.profileId = profile.id;
      const heading = element('div','card-heading');
      heading.append(element('h3','',profile.name));
      let hostname = '';
      try { hostname = new URL(profile.startUrl).hostname; } catch (_) {}
      heading.append(element('p','cookie-meta',hostname || '已儲存帳號'));
      if (active) heading.append(element('p','card-active',profile.needsApply ? '目前帳號 · 有更新未套用' : '目前帳號'));
      const primary = element('button','button button-primary compact-open',state.pending ? '重新套用並開啟' : openCurrent ? '開啟' : '套用並開啟');
      primary.type = 'button'; primary.dataset.nativeSwitch = profile.id;
      primary.setAttribute('aria-label','相容套用 ' + profile.name + ' 並開啟');
      primary.setAttribute('aria-describedby','shared-compatibility-notice');
      primary.addEventListener('click',()=>runNativeCompatibility(profile));
      const menu = element('details','account-menu');
      menu.open = expandedMenus.has(profile.id);
      const summary = element('summary','','更多'); summary.setAttribute('aria-label','管理 ' + profile.name);
      const tools = element('div','card-tools');
      const edit = element('button','button button-quiet','編輯');edit.type='button';edit.dataset.lock='';edit.setAttribute('aria-label','編輯 ' + profile.name);edit.addEventListener('click',()=>openEditor(profile));
      const remove = element('button','button button-quiet button-danger','刪除');remove.type='button';remove.dataset.lock='';remove.setAttribute('aria-label','刪除 ' + profile.name);remove.addEventListener('click',()=>deleteProfile(profile));
      tools.append(edit,remove);
      menu.append(summary,tools,element('p','card-url',profile.startUrl || ''),element('p','card-updated',displayDate(profile.updatedAt)));
      card.append(heading,primary,menu);ui['account-list'].append(card);
    }
    updateLocks();
  }
  function renderState() {
    const active = state.profiles.find((profile) => profile.id === state.activeId);
    ui['operation-status'].hidden = !operationBlocked();
    ui['operation-message'].textContent = state.operation && state.operation.message || '背景仍在處理操作，已暫停資料變更。請稍候按「重新整理」；若持續無回應，請完全關閉 Orion 再開啟，並依提示恢復。';
    ui['active-name'].textContent = state.pending ? '上次套用未完成' : active ? active.name : '尚未套用帳號';
    ui['active-detail'].textContent = state.pending ? '請先完成恢復，再繼續切換。' : active ? active.needsApply ? '此帳號有尚未套用的更新。選擇「套用並開啟」後，請至網站確認實際帳號。' : '已選用此帳號的 Cookie，可按「開啟」進入網站。實際登入身分請至網站確認。' : state.lastResult && state.lastResult.status === 'abandoned' ? state.lastResult.message : state.profiles.length ? '帳號已儲存在下方清單，按「套用並開啟」即可使用。檢查功能放在右上角的小點內。' : '按「新增」加入帳號，再選擇「套用並開啟」。';
    const warnings = persistentWarnings();
    if (warnings.length) ui['active-detail'].textContent += ' 注意：' + warnings.join(' ');
    if (state.activeAttributeLimited) ui['active-detail'].textContent += ' 目前為相容套用，部分屬性未確認；請在網站確認實際登入狀態。';
    if (switchBlocked()) ui['active-detail'].textContent += ' 一般模式已停用；「套用並開啟」使用本次相容模式。';
    ui.recovery.hidden = !state.pending;
    if(state.pending)ui['active-detail'].textContent='可按帳號旁的「重新套用並開啟」，停止舊復原後重新清理並套用。舊備份會保留在本機。';
    ui['invalid-records'].hidden = !state.invalidProfileCount;
    ui['invalid-records-message'].textContent = '有 ' + (state.invalidProfileCount || 0) + ' 筆損壞或識別重複的紀錄無法列出。其餘可用帳號仍可管理；移除損壞紀錄不會修改網站 Cookie。';
    const select = $('developer-profile'), selected = select.value;
    select.replaceChildren(...state.profiles.map(p => { const o = element('option','',p.name); o.value=p.id; return o; }));
    if(state.profiles.some(p => p.id === selected)) select.value = selected;
    $('user-status').hidden = !(operationBlocked() || state.pending || state.invalidProfileCount);
    $('user-status').textContent = operationBlocked() ? '操作尚未完成，請稍候重新整理。' : state.pending ? '上次套用未完成，可重新選擇帳號開啟。' : '部分帳號資料無法讀取，可從右上角小點查看。';
    renderAttempts();
    renderSwitchBlocker();
    renderCookieProbe();
    renderCards();
  }
  function applyState(next) {
    if (!next || !Array.isArray(next.profiles)) throw new Error('帳號資料回應不完整，請重新整理。');
    state = next;
    loaded = true;
    renderState();
  }
  async function refreshState() { applyState(await send({ type:'state' })); }
  async function runOperation(message, task, success) {
    if (busy) return;
    setBusy(true);
    notify(message, 'busy');
    let taskFinished = false;
    try {
      const result = await task();
      taskFinished = true;
      if (result && Array.isArray(result.profiles)) applyState(result);
      else await refreshState();
      notify(typeof success === 'function' ? success(result) : success);
      return { ok:true, result };
    } catch (error) {
      if (!taskFinished) { try { await refreshState(); } catch (_) { /* Retain the previous view and the original error. */ } }
      notify(errorMessage(error), 'error');
      return { ok:false, error:errorMessage(error) };
    } finally { setBusy(false); }
  }
  async function switchProfile(profile) {
    if (!loaded || writeBlocked() || switchBlocked()) return;
    const openCurrent = profile.id === state.activeId && !profile.needsApply;
    const outcome = await runOperation(openCurrent ? '正在開啟「' + profile.name + '」的指定網址…' : '正在套用「' + profile.name + '」的 Cookie，請保持管理器開啟…', () => send({ type:'switch', id:profile.id }), (result) => result && result.lastResult && result.lastResult.message ? result.lastResult.message : '操作已完成。請在網站確認實際登入的帳號。');
    if (outcome && !outcome.ok && !ui['switch-inspector'].hidden) await openSwitchInspector(profile, outcome.error);
  }
  function closeSwitchInspector() {
    if (busy) return;
    ui['switch-inspector'].hidden = true;
    document.body.classList.remove('modal-open');
    ui.main.inert = false;
    if (inspectorFromDeveloper) { inspectorFromDeveloper = false; openDeveloper(); }
    if (inspectorReturnFocus && inspectorReturnFocus.isConnected) inspectorReturnFocus.focus();
  }
  function safeCount(value) { return Number.isSafeInteger(value) && value >= 0 ? value : 0; }
  function renderSwitchBlocker() {
    const blocker = state.switchBlocker;
    const fields = Array.isArray(blocker?.fields) ? blocker.fields.filter(field => ['httpOnly','hostOnly'].includes(field)) : [];
    const names = [...new Set(fields)].map(field => field === 'httpOnly' ? 'HttpOnly（網站腳本存取限制）' : 'hostOnly（僅限主機）');
    for (const prefix of ['','inspector-']) {
      ui[prefix+'switch-blocker'].hidden = !switchBlocked();
      ui[prefix+'switch-blocker-detail'].textContent = '裝置測試發現' + (names.length ? names.join('、') : '關鍵 Cookie 屬性') + '的寫入要求與讀回結果不一致。';
    }
    if ((switchBlocked() && switchReport?.summary?.compatibilityAction !== 'recover') || nativeRecoveryAvailable()) {
      ui['expiry-compatibility-consent'].checked = false;
      ui['expiry-compatibility-panel'].hidden = true;
    }
    const recovering = nativeRecoveryAvailable();
    ui['native-compatibility-panel'].hidden = !(nativeCompatibilityAvailable() || recovering);
    ui['native-compatibility-title'].textContent = recovering ? '本次相容復原' : '本次相容套用';
    ui['native-compatibility-detail'].textContent = recovering ? '相容復原無法保證原本防止網站程式讀取 Cookie 的保護、子網域範圍與保存期限；按下即同意本次有限復原。仍會核對 Cookie 的名稱、內容、網域與路徑。' : NATIVE_COMPATIBILITY_NOTICE;
    ui['native-compatibility-button'].textContent = recovering ? '相容復原' : '相容套用並開啟';
    ui['native-recovery-button'].hidden = !recovering;
    ui['native-recovery-detail'].hidden = !recovering;
  }
  const attemptStages = {preflight:'套用前檢查',closing_tabs:'關閉相關分頁',clearing:'清除舊 Cookie',installing:'寫入新 Cookie',verification:'寫入後核對',commit:'儲存切換結果',open:'開啟指定網頁'};
  const attemptFields = {nameKey:'識別資訊',name:'名稱',value:'內容',domain:'網域',secure:'安全連線限制',httpOnly:'網站腳本存取限制',hostOnly:'主機範圍',path:'路徑',sameSite:'跨站使用設定',session:'工作階段狀態',expirationDate:'到期時間'};
  function attributeValue(field,value) {
    if (['secure','httpOnly','hostOnly','session'].includes(field) && typeof value === 'boolean') return value ? '是（true）' : '否（false）';
    if (field === 'sameSite' && ['unspecified','no_restriction','lax','strict'].includes(value)) return {unspecified:'未指定',no_restriction:'不限（None）',lax:'寬鬆（Lax）',strict:'嚴格（Strict）'}[value];
    return '無法辨識';
  }
  function transitionStats(transitions) {
    if (!Array.isArray(transitions)) return [];
    return transitions.slice(0,30).filter(item => item && ['secure','httpOnly','hostOnly','session','sameSite'].includes(item.field) && safeCount(item.count)).map(item => attemptFields[item.field] + '（' + item.field + '）：' + attributeValue(item.field,item.from) + ' → ' + attributeValue(item.field,item.to) + '，' + safeCount(item.count) + ' 個');
  }
  function attemptCard(attempt) {
    const card = element('article','attempt-card');
    const profile = state.profiles.find(item => item.id === attempt.profileId);
    const status = {failed:'未完成',applied:'已套用',opened:'已開啟'}[attempt.status] || '待確認';
    card.append(element('p','attempt-meta',(profile ? profile.name + ' · ' : '') + status + ' · ' + (attemptStages[attempt.stage] || '階段尚未確認') + (typeof attempt.version === 'string' && /^\d+\.\d+\.\d+$/.test(attempt.version) ? ' · v' + attempt.version : '')));
    if (typeof attempt.message === 'string') card.append(element('p','attempt-message',attempt.message.slice(0,1500)));
    const stats = [];
    for(const [key,label] of [['clearingSummary','切換清除'],['restoreClearingSummary','復原清除']]) {
      const c=attempt[key];if(!c||typeof c!=='object')continue;
      card.append(element('p','hint',label+'：原有 '+safeCount(c.initialCount)+' 筆，剩餘 '+safeCount(c.remainingCount)+' 筆；刪除要求 '+safeCount(c.removeCalls)+' 次，空回覆 '+safeCount(c.removeEmptyReplies)+' 次，拒絕 '+safeCount(c.removeErrors)+' 次；到期移除 '+safeCount(c.expiryCalls)+' 次，拒絕 '+safeCount(c.expiryErrors)+' 次；等待讀回 '+safeCount(c.polls)+' 次，新出現識別 '+safeCount(c.reappearedCount)+' 次。'));
    }
    const verification = attempt.verification;
    if (verification && typeof verification === 'object') {
      const content = verification.contentVerification;
      if (content && typeof content === 'object') {
        card.append(element('p','attempt-message','登入內容核對：預期 ' + safeCount(content.expectedCount) + ' 個，讀回 ' + safeCount(content.actualCount) + ' 個，名稱、內容、網域與路徑相符 ' + safeCount(content.matchedCount) + ' 個。'));
        const failed = [];
        for (const [field,label] of [['missingCount','缺少'],['unexpectedCount','多出'],['duplicateCount','重複'],['valueMismatchCount','內容不同']]) if (safeCount(content[field])) failed.push(label + ' ' + safeCount(content[field]) + ' 個');
        if (failed.length) card.append(element('p','form-error',failed.join('；')));
        if (attempt.attributeCompatibilityUsed) card.append(element('p','hint','本次使用相容套用。以下保留完整屬性核對的差異，不能視為所有屬性都已確認。'));
      }
      if (Number.isSafeInteger(verification.expectedCount) && Number.isSafeInteger(verification.actualCount)) stats.push('預期 ' + safeCount(verification.expectedCount) + ' 個，讀回 ' + safeCount(verification.actualCount) + ' 個');
      for (const [field,label] of [['missingCount','缺少'],['unexpectedCount','多出'],['duplicateCount','重複']]) if (safeCount(verification[field])) stats.push(label + ' ' + safeCount(verification[field]) + ' 個');
      if (safeCount(verification.temporarySessionCount)) stats.push('僅回報暫存狀態：' + safeCount(verification.temporarySessionCount) + ' 個，原期限未確認');
      if (Array.isArray(verification.differences)) for (const difference of verification.differences.slice(0,15)) {
        if (!difference || !safeCount(difference.count)) continue;
        const field = Object.prototype.hasOwnProperty.call(attemptFields,difference.field) ? attemptFields[difference.field] + '（' + difference.field + '）' : '其他屬性';
        stats.push(field + '不同：' + safeCount(difference.count) + ' 個');
      }
      stats.push(...transitionStats(verification.fieldTransitions));
      const identity = verification.identityMismatches;
      if (identity && typeof identity === 'object') for (const [field,label] of [['hostOnlyCount','主機範圍改變，可能造成識別不一致'],['domainCount','網域範圍改變，可能造成識別不一致'],['ambiguousExpectedCount','缺少項目有多個可能對應，無法確認'],['ambiguousActualCount','多出項目有多個可能對應，無法確認'],['unpairedExpectedCount','缺少項目找不到可比較對應'],['unpairedActualCount','多出項目找不到可比較對應']]) if (safeCount(identity[field])) stats.push(label + '：' + safeCount(identity[field]) + ' 個');
    }
    const write = attempt.cookieWrite;
    if (write && typeof write === 'object') {
      if (safeCount(write.ordinal) && safeCount(write.total)) stats.push('寫入帳號內第 ' + safeCount(write.ordinal) + '／' + safeCount(write.total) + ' 個 Cookie 時停止');
      const reason = {native_rejected:'瀏覽器拒絕寫入',native_timeout:'瀏覽器寫入回覆逾時',unconfirmed_result:'瀏覽器未確認寫入結果',store_mismatch:'寫入儲存區不一致'}[write.category];
      if (reason) stats.push(reason);
    }
    if (stats.length) { const list = element('ul','attempt-statistics'); for (const text of stats) list.append(element('li','',text)); card.append(list); }
    const writeSummary = attempt.writeReadbackSummary;
    if (writeSummary && typeof writeSummary === 'object') {
      const details = element('details','attempt-history');
      details.append(element('summary','','寫入 API 回覆，並非實際儲存證明'));
      const list = element('ul','attempt-statistics');
      list.append(element('li','','要求寫入 ' + safeCount(writeSummary.requestedCount) + ' 個，收到回覆 ' + safeCount(writeSummary.receivedCount) + ' 個'));
      for (const [key,label] of [['differences','不同'],['missingFieldCounts','未提供'],['invalidFieldCounts','格式無法辨識']]) if (Array.isArray(writeSummary[key])) for (const item of writeSummary[key].slice(0,15)) {
        if (item && safeCount(item.count)) list.append(element('li','',(Object.prototype.hasOwnProperty.call(attemptFields,item.field) ? attemptFields[item.field] + '（' + item.field + '）' : '其他屬性') + label + '：' + safeCount(item.count) + ' 個'));
      }
      for (const text of transitionStats(writeSummary.fieldTransitions)) list.append(element('li','',text));
      details.append(list); card.append(details);
    }
    if (attempt.recovery && typeof attempt.recovery === 'object') {
      const label = {not_needed:'未進行復原',restored:'已復原',restored_limited:'已有限復原',pending:'復原尚未完成'}[attempt.recovery.status] || '復原狀態待確認';
      card.append(element('p','attempt-recovery',label + (typeof attempt.recovery.message === 'string' && attempt.recovery.message ? '：' + attempt.recovery.message.slice(0,1000) : '')));
    }
    if (attempt.status === 'failed') card.append(element('p','hint',operationBlocked() ? '操作結果仍待確認，已暫停再次切換；請先重新讀取狀態。' : state.pending ? '請先處理待復原狀態，再決定是否重試。' : '先查看原始原因及差異項目；目前狀態檢查不會重新執行切換。'));
    return card;
  }
  function renderAttempts() {
    function fill(panel,result,profileId) {
      const latest = state.lastAttempt && typeof state.lastAttempt === 'object' && (!profileId || state.lastAttempt.profileId === profileId) ? state.lastAttempt : null;
      const previous = state.lastMutatedAttempt && typeof state.lastMutatedAttempt === 'object' && state.lastMutatedAttempt.status === 'failed' && (!profileId || state.lastMutatedAttempt.profileId === profileId) && (!latest || state.lastMutatedAttempt.attemptId !== latest.attemptId) ? state.lastMutatedAttempt : null;
      ui[result].replaceChildren();
      ui[panel].hidden = !latest && !previous;
      if (latest) ui[result].append(attemptCard(latest));
      if (previous) {
        if (!latest) ui[result].append(attemptCard(previous));
        else { const details = element('details','attempt-history'); details.append(element('summary','','先前曾套用的失敗紀錄'),attemptCard(previous)); ui[result].append(details); }
      }
    }
    fill('last-attempt-panel','last-attempt-result');
    fill('inspector-attempt-panel','inspector-attempt-result',inspectedProfile && inspectedProfile.id);
    renderProbeGuidance();
  }
  function nonLifetimeFailure(profileId) {
    const attempt = state.lastMutatedAttempt || (state.lastAttempt?.mutated ? state.lastAttempt : null);
    if (!attempt || attempt.status !== 'failed' || attempt.stage !== 'verification' || (profileId && attempt.profileId !== profileId)) return false;
    const verification = attempt.verification;
    return Boolean(verification && (['missingCount','unexpectedCount','duplicateCount'].some(field => safeCount(verification[field])) || (Array.isArray(verification.differences) && verification.differences.some(item => item && safeCount(item.count) && !['session','expirationDate'].includes(item.field)))));
  }
  function renderProbeGuidance() {
    ui['expiry-other-differences'].hidden = !nonLifetimeFailure(inspectedProfile?.id);
    for (const prefix of ['','inspector-']) {
      const node = ui[prefix+'cookie-probe-guidance'];
      node.hidden = !nonLifetimeFailure(prefix ? inspectedProfile?.id : null);
      node.textContent = switchBlocked() ? '已知此裝置有屬性讀回限制。可選本次相容套用，或更新 Orion 後重測；裝置測試本身不會登入帳號。' : '上次寫入後仍有 Cookie 缺少、多出或其他屬性不同。同意期限相容處理不能修正這些差異；請先測試此裝置的 Cookie 寫入能力，再決定是否重試。';
    }
  }
  function probeValue(field,value) {
    if (typeof value === 'boolean') return value ? '是（true）' : '否（false）';
    const labels = {unspecified:'未指定',no_restriction:'不限（None）',lax:'寬鬆（Lax）',strict:'嚴格（Strict）',matches:'一致',changed:'不同',missing:'未提供',invalid:'格式無法辨識',persistent:'有到期時間',session:'工作階段',unknown:'無法確認'};
    return typeof value === 'string' && Object.prototype.hasOwnProperty.call(labels,value) ? labels[value] : '無法辨識';
  }
  function probeCheckText(check) {
    const label = check.field === 'subdomainVisible' ? '子網域查詢可讀取（僅測試瀏覽器查詢）' : Object.prototype.hasOwnProperty.call(attemptFields,check.field) ? attemptFields[check.field] + '（' + check.field + '）' : '其他屬性';
    const stateLabel = ['passed','failed','observed'].includes(check.status) ? {passed:'一致',failed:'不同',observed:'僅記錄瀏覽器行為'}[check.status] : '未確認';
    return label + '：預期 ' + probeValue(check.field,check.expected) + '，讀回 ' + probeValue(check.field,check.actual) + ' · ' + stateLabel;
  }
  function probeSummaryText(report) {
    let version = '未確認';
    try { const value = globalThis.AccountAPI?.native?.runtime?.getManifest?.().version; if (typeof value === 'string' && /^\d+\.\d+\.\d+$/.test(value)) version = value; } catch (_) {}
    const summary = report.summary;
    const cleanup = {cleared:'已清理',not_needed:'不需清理',failed:'清理未完成',uncertain:'清理未確認'};
    const testedVersion = typeof report.extensionVersion === 'string' && /^\d+\.\d+\.\d+$/.test(report.extensionVersion) ? report.extensionVersion : '這份報告未記錄';
    const lines = ['裝置 Cookie 寫入檢測','擴充版本：' + version,'測試時擴充版本：' + testedVersion,'報告格式：' + safeCount(report.version),'通過 ' + safeCount(summary.passed) + ' 項；未通過 ' + safeCount(summary.failed) + ' 項；不支援 ' + safeCount(summary.unsupported) + ' 項。','測試資料：' + (Object.prototype.hasOwnProperty.call(cleanup,summary.cleanup) ? cleanup[summary.cleanup] : '未確認')];
    const labels = {host_only:'僅限目前主機',domain:'共用網域',secure_false:'Secure 關閉',http_only_false:'HttpOnly 關閉',explicit_false:'明確傳入兩個 false',strict:'SameSite Strict',none:'SameSite None',default:'未指定 SameSite',session:'工作階段 Cookie',path:'指定路徑'};
    for (const item of report.cases.slice(0,30)) {
      if (!item || typeof item !== 'object') continue;
      const checks = Array.isArray(item.checks) ? item.checks.slice(0,24).filter(check => check && ['failed','observed'].includes(check.status)) : [];
      if (!['failed','unsupported'].includes(item.status) && !checks.length) continue;
      const label = typeof item.id === 'string' && Object.prototype.hasOwnProperty.call(labels,item.id) ? labels[item.id] : '其他測試項目';
      lines.push('',label + '：' + (item.status === 'failed' ? '未通過' : item.status === 'unsupported' ? '不支援' : '有觀察結果'));
      for (const check of checks) lines.push('- ' + probeCheckText(check));
    }
    lines.push('','讀回差異不等於已證實 HttpOnly 實際移除；子網域查詢只測試 API，不證明 Cookie 網路外洩。','僅記錄的項目不代表完整支援；這份摘要不含真實帳號、網址或 Cookie 內容。');
    return lines.join('\n');
  }
  function probeCopyControls(report,prefix) {
    const panel = element('div','probe-copy-controls');
    const button = element('button','button button-outline','複製檢測摘要'); button.type = 'button'; button.id = prefix+'cookie-probe-copy';
    const status = element('p','hint'); status.setAttribute('role','status');
    const fallback = element('div','probe-copy-fallback'); fallback.hidden = true;
    const text = element('textarea'); text.id = prefix+'cookie-probe-summary-text'; text.readOnly = true; text.rows = 8; text.setAttribute('aria-label','可複製的安全檢測摘要'); text.value = probeSummaryText(report);
    const select = element('button','button button-outline','全選摘要'); select.type = 'button'; select.addEventListener('click',()=>{text.focus();text.select();text.setSelectionRange(0,text.value.length);});
    fallback.append(text,select,element('p','hint','摘要已選取；若無法自動複製，請長按文字後選擇「複製」。'));
    button.addEventListener('click',async()=>{
      button.disabled = true;
      try {
        if (typeof navigator.clipboard?.writeText !== 'function') throw new Error('unavailable');
        await bounded(navigator.clipboard.writeText(text.value),2000,'copy timeout');
        status.textContent = '檢測摘要已複製，不含帳號名稱、網址或 Cookie 內容。';
      } catch (_) {
        status.textContent = '此瀏覽器未完成自動複製，可使用下方文字。';
        fallback.hidden = false; text.focus();text.select();text.setSelectionRange(0,text.value.length);
      } finally {button.disabled = false;}
    });
    panel.append(button,status,fallback);return panel;
  }
  function probeCaseCard(item) {
    const card = element('article','probe-case');
    const status = ['passed','failed','unsupported'].includes(item.status) ? item.status : 'unsupported';
    const heading = element('div','diagnostic-heading');
    heading.append(element('strong','',typeof item.label === 'string' ? item.label.slice(0,120) : '測試項目'),element('span',status === 'passed' ? 'diagnostic-ok' : status === 'failed' ? 'diagnostic-no' : 'diagnostic-warning',{passed:'通過',failed:'未通過',unsupported:'不支援'}[status]));
    card.append(heading);
    const checks = element('ul','probe-checks');
    const passedChecks = element('ul','probe-checks');
    if (Array.isArray(item.checks)) for (const check of item.checks.slice(0,24)) {
      if (!check || typeof check !== 'object') continue;
      (check.status === 'passed' && status !== 'passed' ? passedChecks : checks).append(element('li','',probeCheckText(check)));
    }
    if (checks.childElementCount) card.append(checks);
    if (passedChecks.childElementCount) {const details = element('details','probe-passed-fields');details.append(element('summary','','查看此項通過欄位'),passedChecks);card.append(details);}
    if (item.errorCode) card.append(element('p','hint','此項測試未能完整確認，未顯示瀏覽器原始錯誤或 Cookie 內容。'));
    return card;
  }
  function renderCookieProbe() {
    const report = state.lastCookieProbe;
    for (const prefix of ['','inspector-']) {
      const container = ui[prefix+'cookie-probe-result'];
      container.replaceChildren();
      if (cookieProbeNotice) container.append(element('p','notice is-warning',cookieProbeNotice));
      if (!report || !report.summary || !Array.isArray(report.cases)) continue;
      const summary = report.summary;
      container.append(element('p','probe-summary','上次測試：通過 ' + safeCount(summary.passed) + ' 項、未通過 ' + safeCount(summary.failed) + ' 項、不支援 ' + safeCount(summary.unsupported) + ' 項。'));
      if (Number.isFinite(report.checkedAt)) container.append(element('p','hint',displayDate(report.checkedAt)));
      container.append(element('p','hint','測試時擴充版本：' + (typeof report.extensionVersion === 'string' && /^\d+\.\d+\.\d+$/.test(report.extensionVersion) ? report.extensionVersion : '這份報告未記錄')));
      const cleanup = {cleared:'測試 Cookie 已清理。',not_needed:'未留下需要清理的測試 Cookie。',failed:'測試資料清理未完成，請先重新讀取狀態；不要連續重複測試。',uncertain:'測試資料清理結果尚未確認，請先重新讀取狀態；不要再次送出測試。'};
      container.append(element('p',summary.cleanup === 'cleared' || summary.cleanup === 'not_needed' ? 'hint' : 'notice is-warning',Object.prototype.hasOwnProperty.call(cleanup,summary.cleanup) ? cleanup[summary.cleanup] : '尚未確認測試資料清理結果，請先重新讀取狀態。'));
      container.append(probeCopyControls(report,prefix));
      const passed = element('details','probe-passed');
      passed.append(element('summary','','查看其餘測試項目'));
      for (const item of report.cases.slice(0,30)) if (item && typeof item === 'object') {
        if (item.status === 'passed' && !(Array.isArray(item.checks) && item.checks.some(check => check?.status === 'observed'))) passed.append(probeCaseCard(item));
        else container.append(probeCaseCard(item));
      }
      if (passed.childElementCount > 1) container.append(passed);
      if (report.errorCode) container.append(element('p','notice is-warning','本次測試有步驟未能完成，請先查看各項結果與清理狀態，再重新讀取狀態。'));
      container.append(element('p','hint','測試結果只表示擴充功能的寫入與讀回行為，不代表真實帳號已登入，也不能斷定 HttpOnly 實際遭移除。子網域查詢僅測試 API，不是網路傳送或外洩測試；標示「僅記錄」的項目不視為完整支援。'));
    }
  }
  async function runCookieProbe() {
    if (busy || !loaded || writeBlocked()) return;
    cookieProbeNotice = '正在測試假 Cookie 的寫入與讀回，完成後清理；請保持管理器開啟。';
    switchReport = null;
    ui['expiry-compatibility-consent'].checked = false;
    ui['expiry-compatibility-panel'].hidden = true;
    ui['site-copy-panel'].hidden = true;
    renderCookieProbe();
    const outcome = await runOperation(cookieProbeNotice, () => send({type:'runCookieProbe'}), '裝置 Cookie 寫入測試已回覆，請查看各項結果與清理狀態。');
    cookieProbeNotice = outcome && outcome.ok ? '' : '本次測試未能確認完成，請先重新讀取狀態。下方若有報告，仍是上次已取得的結果。';
    renderCookieProbe();
    updateLocks();
  }
  function persistentWarnings() {
    return [...new Set([...(Array.isArray(state.activeWarnings) ? state.activeWarnings : []), ...(Array.isArray(state.lastResult?.warnings) ? state.lastResult.warnings : [])].filter(value => typeof value === 'string' && value.trim()).map(value => value.slice(0, 1000)))].slice(0, 8);
  }
  function renderSwitchReport(report) {
    if (!report || !report.summary || !Array.isArray(report.checks)) throw new Error('切換檢查回應不完整，請按「重新檢查」重試。');
    for (const key of ['lastAttempt','lastMutatedAttempt','lastCookieProbe','switchBlocker']) if (Object.prototype.hasOwnProperty.call(report,key)) state[key] = report[key];
    if (report.operation && typeof report.operation.busy === 'boolean' && typeof report.operation.stalled === 'boolean') {
      state.operation = {busy:report.operation.busy,stalled:report.operation.stalled,message:typeof report.operation.message === 'string' ? report.operation.message.slice(0,400) : null};
      renderState(); // Refresh operation locks only; inspection does not resolve a pending recovery.
    }
    switchReport = report;
    renderAttempts();
    renderSwitchBlocker();
    renderCookieProbe();
    const summary = report.summary;
    const overview = element('p', 'switch-inspector-summary', '已儲存 ' + safeCount(summary.profileCookieCount) + ' 個 Cookie，涵蓋 ' + safeCount(summary.profileDomainCount) + ' 個網域。');
    const list = element('ul', 'diagnostic-list');
    const fieldShapes = element('details','diagnostic-shapes');
    const shapeList = element('ul','diagnostic-list');
    fieldShapes.append(element('summary','','查看瀏覽器欄位資訊'),shapeList);
    for (const check of report.checks) {
      const status = ['passed','warning','failed'].includes(check.status) ? check.status : 'warning';
      const item = element('li');
      const heading = element('div', 'diagnostic-heading');
      heading.append(element('span', '', String(check.label || '相容性檢查').slice(0, 100)), element('span', status === 'failed' ? 'diagnostic-no' : status === 'warning' ? 'diagnostic-warning' : 'diagnostic-ok', { passed:'檢查通過', warning:'需要留意', failed:'檢查未通過' }[status]));
      item.append(heading);
      if (check.detail) item.append(element('p', 'diagnostic-detail', String(check.detail).slice(0, 2000)));
      if (typeof check.label === 'string' && check.label.endsWith('欄位形狀')) shapeList.append(item);
      else list.append(item);
    }
    ui['switch-inspector-result'].replaceChildren(overview, list, element('p', 'diagnostic-note', String(report.note || '檢查不會修改帳號、網站 Cookie 或分頁。').slice(0, 1000)));
    if (shapeList.childElementCount) ui['switch-inspector-result'].append(fieldShapes);
    const savedWarnings = persistentWarnings();
    if (savedWarnings.length) ui['switch-inspector-result'].append(element('p', 'notice is-warning', savedWarnings.join(' ')));
    ui['expiry-compatibility-consent'].checked = false;
    const compatibility = summary.canUseMissingExpiryCompatibility === true && ['switch','recover'].includes(summary.compatibilityAction) && !inspectorNativeFailure && !nativeRecoveryAvailable() && (summary.compatibilityAction === 'recover' || !switchBlocked());
    ui['expiry-compatibility-panel'].hidden = !compatibility;
    const recovering = summary.compatibilityAction === 'recover';
    ui['expiry-compatibility-detail'].textContent = (safeCount(summary.missingNativeExpiryCount) ? '本次' + (recovering ? '復原' : '切換') + '範圍內有 ' + safeCount(summary.missingNativeExpiryCount) + ' 個 Cookie 未提供到期時間。' : '本次操作包含到期時間無法確認的 Cookie 或復原備份。') + '範圍可能包含先前帳號的網站；相容處理不會延長已儲存帳號的期限，也不會用期限不明的資料覆蓋原帳號。';
    ui['expiry-compatibility-button'].textContent = recovering ? '同意相容復原' : '同意本次相容切換並開啟';
    if (state.lastResult && state.lastResult.status === 'abandoned' && !state.pending) ui['switch-inspector-result'].append(element('p', 'diagnostic-note abandoned-recovery-note', '先前已停止復原，目前沒有待復原作業。停止復原沒有清除網站 Cookie，因此本次仍需處理瀏覽器未提供的屬性。'));
    const hostname = String(summary.targetHost || '').slice(0, 253);
    ui['site-copy-panel'].hidden = !(safeCount(summary.targetCookieCount) > 0 && safeCount(summary.otherCookieCount) > 0);
    ui['site-copy-detail'].textContent = '指定網站：' + hostname + '。副本將包含 ' + safeCount(summary.targetCookieCount) + ' 個適用 Cookie，排除其他網站的 ' + safeCount(summary.otherCookieCount) + ' 個 Cookie。';
    const request = siteCopyRequests.get(inspectedProfile.id);
    ui['site-copy-status'].textContent = request && request.completed ? '副本已建立，原帳號完整保留。請返回清單，先檢查副本再切換。' : !summary.canCreateSiteCopy ? '目前資料尚不符合建立副本的條件，請先查看上方檢查結果。' : '';
  }
  async function inspectProfile() {
    if (busy || !inspectedProfile) return;
    setBusy(true);
    switchReport = null;
    ui['expiry-compatibility-consent'].checked = false;
    ui['expiry-compatibility-panel'].hidden = true;
    ui['site-copy-panel'].hidden = true;
    ui['switch-inspector-result'].replaceChildren(element('p', 'diagnostic-note', '正在檢查這個帳號與裝置的切換相容性…'));
    try { renderSwitchReport(await send({ type:'inspectSwitch', id:inspectedProfile.id })); }
    catch (_) {
      // Native exceptions can contain arbitrary browser data; never echo them into this report.
      ui['switch-inspector-result'].replaceChildren(element('p', 'form-error', '未能完成切換檢查。沒有套用 Cookie；請按「重新檢查」重試。若持續無回應，請完全關閉 Orion 再開啟。'));
    } finally { setBusy(false); }
  }
  async function openSwitchInspector(profile, failure = '', nativeFailure = false) {
    if (busy || !loaded) return;
    inspectedProfile = profile;
    inspectorNativeFailure = nativeFailure;
    renderAttempts();
    const previous = siteCopyRequests.get(profile.id);
    if (previous && previous.completed && (previous.sourceUpdatedAt !== profile.updatedAt ||
        (previous.savedProfileId && !previous.needsRefresh && !state.profiles.some(item => item.id === previous.savedProfileId)))) siteCopyRequests.delete(profile.id);
    inspectorReturnFocus = document.activeElement;
    if (!developerTools.hidden) { inspectorFromDeveloper = true; developerTools.hidden = true; }
    ui['switch-inspector-account'].textContent = '「' + profile.name + '」已儲存在帳號清單。' + (profile.id === state.activeId ? '目前套用狀態請以主畫面與網站為準。' : '目前尚未套用此帳號。');
    ui['switch-inspector-error'].textContent = failure ? '這次切換未完成，原帳號資料仍在清單中。原始原因：' + String(failure).slice(0,1000) : '';
    ui['switch-inspector-error'].hidden = !failure;
    ui['switch-inspector'].hidden = false;
    document.body.classList.add('modal-open');
    ui.main.inert = true;
    ui['switch-inspector'].scrollTop = 0;
    ui['switch-inspector'].querySelector('[role="dialog"]').focus();
    await inspectProfile();
  }
  async function runNativeCompatibility(profile) {
    if (busy || !loaded || operationBlocked() || !profile || !nativeCompatibilityAvailable(profile)) return;
    const replacePending=Boolean(state.pending);
    const outcome = await runOperation('正在相容套用「' + profile.name + '」並開啟網站，請保持管理器開啟…',()=>send({type:'switch',id:profile.id,allowNativeAttributeMismatch:true,allowMissingNativeExpiry:true,...(replacePending?{replacePending:true}:{})}),result=>result?.lastResult?.message || '相容操作已回覆，部分屬性未確認；請在網站確認登入狀態。');
    if (outcome && !outcome.ok) { if(!ui['switch-inspector'].hidden) await openSwitchInspector(profile,outcome.error,true); return; }
    if (outcome?.ok && !ui['switch-inspector'].hidden && inspectedProfile?.id === profile.id) {
      switchReport = null;
      for (const id of ['expiry-compatibility-panel','native-compatibility-panel','site-copy-panel','switch-inspector-error']) ui[id].hidden = true;
      const result = outcome.result;
      const openFailed = result?.lastAttempt?.profileId === profile.id && result.lastAttempt.status === 'failed' && result.lastAttempt.stage === 'open';
      ui['switch-inspector-account'].textContent = openFailed ? '已相容套用；開啟網頁未完成，部分屬性未確認。' : '已相容套用並開啟，部分屬性未確認。';
      ui['switch-inspector-result'].replaceChildren(element('p','notice is-warning',result?.lastResult?.message || '部分屬性未確認，請在網站確認實際登入狀態。'));
      updateLocks();
    }
  }
  async function runNativeRecovery() {
    if (busy || !loaded || operationBlocked() || !nativeRecoveryAvailable()) return;
    const outcome = await runOperation('正在相容復原，請保持管理器開啟…',()=>send({type:'recover',allowNativeAttributeMismatch:true,allowMissingNativeExpiry:true}),result=>result?.lastResult?.message || '相容復原已回覆，部分屬性未確認，請查看狀態。');
    if (ui['switch-inspector'].hidden || !inspectedProfile) return;
    if (outcome && !outcome.ok) {await openSwitchInspector(inspectedProfile,outcome.error,true);return;}
    if (outcome?.ok) {
      switchReport = null;
      for (const id of ['expiry-compatibility-panel','native-compatibility-panel','site-copy-panel','switch-inspector-error']) ui[id].hidden = true;
      ui['switch-inspector-account'].textContent = '已相容復原；部分屬性未確認。';
      ui['switch-inspector-result'].replaceChildren(element('p','notice is-warning',outcome.result?.lastResult?.message || 'Cookie 內容已核對，部分屬性未確認。'));
      updateLocks();
    }
  }
  async function runExpiryCompatibility() {
    const summary = switchReport && switchReport.summary;
    if (busy || !loaded || !inspectedProfile || !summary || summary.canUseMissingExpiryCompatibility !== true ||
        !ui['expiry-compatibility-consent'].checked || operationBlocked()) return;
    const recovering = summary.compatibilityAction === 'recover';
    if (recovering ? !state.pending : summary.compatibilityAction !== 'switch' || writeBlocked() || switchBlocked()) return;
    const profile = inspectedProfile;
    // Consent applies only to this submission, including when its reply is lost.
    ui['expiry-compatibility-consent'].checked = false;
    const message = recovering ? {type:'recover',allowMissingNativeExpiry:true} : {type:'switch',id:profile.id,allowMissingNativeExpiry:true};
    const outcome = await runOperation(recovering ? '正在以已同意的相容方式復原，請保持管理器開啟…' : '正在以已同意的相容方式切換「' + profile.name + '」，請保持管理器開啟…', () => send(message), result => result && result.lastResult && result.lastResult.message || '操作已完成；瀏覽器未提供的到期時間仍無法核對，請在網站確認登入狀態。');
    if (outcome && outcome.ok) {
      switchReport = null;
      ui['expiry-compatibility-panel'].hidden = true;
      ui['site-copy-panel'].hidden = true;
      ui['switch-inspector-error'].hidden = true;
      const result = outcome.result;
      const openFailed = !recovering && result?.lastAttempt?.profileId === profile.id && result.lastAttempt.status === 'failed' && result.lastAttempt.stage === 'open';
      ui['switch-inspector-account'].textContent = recovering ? '相容復原已完成。' : openFailed ? 'Cookie 已套用；開啟網頁未完成。' : '「' + profile.name + '」的相容切換已完成。';
      ui['switch-inspector-result'].replaceChildren(element('p', 'notice is-warning', result && result.lastResult && result.lastResult.message || '瀏覽器未提供的到期時間無法核對。請在網站確認實際登入狀態。'));
      updateLocks();
    } else if (outcome) {
      ui['switch-inspector-error'].textContent = (recovering ? '本次相容復原未完成。請查看最新檢查結果；再次操作需重新勾選同意。' : '本次相容切換未完成。請查看最新檢查結果；再次操作需重新勾選同意。') + ' 原始原因：' + String(outcome.error || '未取得可確認的錯誤原因，請先重新讀取狀態。').slice(0,1000);
      ui['switch-inspector-error'].hidden = false;
      await inspectProfile();
    }
  }
  async function createSiteCopy() {
    if (busy || writeBlocked() || !inspectedProfile || !switchReport || !switchReport.summary.canCreateSiteCopy) return;
    const profile = inspectedProfile;
    const summary = switchReport.summary;
    let request = siteCopyRequests.get(profile.id);
    if (request && request.completed) return;
    if (!request) {
      if (!window.confirm('建立「' + String(summary.targetHost || '') + '」的指定網站副本？\n\n保留 ' + safeCount(summary.targetCookieCount) + ' 個適用 Cookie，排除其他網站的 ' + safeCount(summary.otherCookieCount) + ' 個 Cookie。\n\n原帳號完整保留，不會自動切換。副本可能缺少其他網域的跨站登入狀態。')) return;
      if (!globalThis.crypto || typeof globalThis.crypto.randomUUID !== 'function') {
        ui['site-copy-status'].textContent = '此裝置無法產生儲存識別碼，請更新 Orion 後重試。';
        return;
      }
      request = { requestId:globalThis.crypto.randomUUID(), sourceUpdatedAt:profile.updatedAt, completed:false };
      siteCopyRequests.set(profile.id, request);
    }
    setBusy(true);
    ui['site-copy-status'].textContent = '正在建立副本，請保持此畫面開啟…';
    try {
      const result = await send({ type:'siteCopy', id:profile.id, confirm:true, requestId:request.requestId });
      request.completed = true;
      request.savedProfileId = typeof result?.savedProfileId === 'string' ? result.savedProfileId : null;
      if (result && Array.isArray(result.profiles)) applyState(result);
      else if (result && result.metadata && Array.isArray(result.metadata.profiles)) applyState(result.metadata);
      else await refreshState();
      request.needsRefresh = false;
      ui['site-copy-status'].textContent = '副本已建立，原帳號完整保留。尚未切換；請返回清單，先檢查副本再切換。';
      notify('指定網站副本已儲存，原帳號完整保留。尚未套用 Cookie。');
    } catch (_) {
      request.needsRefresh = true;
      ui['site-copy-status'].textContent = request.completed ? '副本已建立，但清單尚未更新。請按「重新讀取狀態」確認。' : '尚未確認副本是否建立。請先按「重新讀取狀態」，再以同一要求重試，不會重複新增。';
    } finally { setBusy(false); }
  }
  async function deleteProfile(profile) {
    if (busy || writeBlocked() || !window.confirm('刪除「' + profile.name + '」的已儲存資料？此操作不等於登出網站。')) return;
    await runOperation('正在刪除帳號資料…', () => send({ type:'delete', id:profile.id }), '已刪除「' + profile.name + '」的已儲存資料。');
  }
  function invalidatePreview() {
    saveRequestId = null;
    saveRequestProfile = null;
    preview = null;
    ui['import-preview'].hidden = true;
    ui['preview-count'].textContent = '';
    ui['preview-domains'].replaceChildren();
    ui['preview-warnings'].replaceChildren();
    showFormError('');
  }
  function openEditor(profile = null) {
    if (busy || !loaded || writeBlocked()) return;
    returnFocus = document.activeElement;
    editingId = profile ? profile.id : null;
    ui['profile-form'].reset();
    ui['profile-name'].value = profile ? profile.name : '';
    ui['profile-url'].value = profile ? profile.startUrl : '';
    ui['editor-title'].textContent = profile ? '編輯帳號' : '新增帳號';
    ui['save-button'].textContent = profile ? '儲存變更' : '儲存帳號';
    ui['edit-cookie-note'].hidden = !profile;
    ui['file-label'].textContent = 'JSON 或文字檔';
    resetDuplicateChoice();
    invalidatePreview();
    ui.editor.hidden = false;
    document.body.classList.add('modal-open');
    document.querySelector('.app-shell').setAttribute('aria-hidden', 'true');
    ui['profile-name'].focus();
  }
  function closeEditor() {
    if (busy) return;
    ui.editor.hidden = true;
    document.body.classList.remove('modal-open');
    document.querySelector('.app-shell').removeAttribute('aria-hidden');
    ui['profile-form'].reset();
    editingId = null;
    resetDuplicateChoice();
    invalidatePreview();
    if (returnFocus && returnFocus.isConnected) returnFocus.focus();
    else ui['add-button'].focus();
  }
  function validatedUrl() {
    if (!globalThis.AccountCore) throw new Error('網址檢查功能尚未載入，請重新開啟管理器。');
    return globalThis.AccountCore.validateUrl(ui['profile-url'].value);
  }
  function parsePreview() {
    const startUrl = validatedUrl();
    const text = ui['cookie-text'].value;
    if (!text.trim()) throw new Error('請先選取檔案或貼上 Cookie 資料。');
    if (new Blob([text]).size > MAX_IMPORT_BYTES) throw new Error('匯入資料超過 4 MB，請改用較小的單一帳號匯出檔。');
    if (!globalThis.AccountCore) throw new Error('Cookie 解析功能尚未載入，請重新開啟管理器。');
    const parsed = globalThis.AccountCore.parseImport(text, { fallbackUrl:startUrl, duplicatePolicy });
    if (!parsed || !Array.isArray(parsed.cookies) || !parsed.cookies.length) throw new Error('此資料沒有可匯入的 Cookie。');
    preview = { ...parsed, source:text, startUrl, duplicatePolicy };
    singleDuplicates.container.hidden = !(parsed.conflicts && parsed.conflicts.groupCount) && duplicatePolicy === 'reject';
    const domains = parsed.domains || [...new Set(parsed.cookies.map((cookie) => cookie.domain).filter(Boolean))];
    ui['preview-count'].textContent = parsed.cookies.length + ' 個 Cookie · ' + domains.length + ' 個網域';
    ui['preview-domains'].replaceChildren();
    domains.forEach((domain) => ui['preview-domains'].append(element('span', 'domain-tag', domain)));
    ui['preview-warnings'].replaceChildren();
    (parsed.warnings || []).forEach((warning) => ui['preview-warnings'].append(element('li', '', typeof warning === 'string' ? warning : warning.message || '此匯入資料有注意事項。')));
    ui['import-preview'].hidden = false;
    showFormError('');
  }
  function previewAndReveal() {
    if (busy || !loaded || writeBlocked()) return;
    invalidatePreview();
    try { parsePreview(); reveal(ui['import-preview']); }
    catch (error) {
      if (error && error.code === 'CONFLICTING_DUPLICATE') singleDuplicates.container.hidden = false;
      showFormError(errorMessage(error));
      reveal(singleDuplicates.container.hidden ? ui['form-error'] : singleDuplicates.container);
    }
  }
  singleDuplicates.select.addEventListener('change', () => {
    if (busy || writeBlocked()) return;
    duplicatePolicy = singleDuplicates.select.value;
    previewAndReveal();
  });
  async function readFile(file, binary=false) {
    const timeoutMessage = '檔案讀取逾時。請先在「檔案」App 將檔案下載到此裝置，再重新選取；也可以直接貼上內容。';
    if (binary && typeof file.arrayBuffer === 'function') return bounded(Promise.resolve().then(() => file.arrayBuffer()), FILE_TIMEOUT_MS, timeoutMessage);
    if (!binary && typeof file.text === 'function') return bounded(Promise.resolve().then(() => file.text()), FILE_TIMEOUT_MS, timeoutMessage);
    const reader = new FileReader();
    return bounded(new Promise((resolve, reject) => {
      reader.onload = () => resolve(binary ? reader.result : String(reader.result || ''));
      reader.onerror = () => reject(new Error('無法讀取此檔案，請重新選取或直接貼上內容。'));
      reader.onabort = () => reject(new Error('檔案讀取已中止，請重新選取。'));
      if(binary)reader.readAsArrayBuffer(file);else reader.readAsText(file);
    }), FILE_TIMEOUT_MS, timeoutMessage).finally(() => { if (reader.readyState === 1) reader.abort(); });
  }
  function showBulkError(message) {
    ui['bulk-error'].textContent = message;
    ui['bulk-error'].hidden = !message;
    ui['bulk-refresh'].hidden = !message || !bulkRequestId;
  }
  function invalidateBulkPreview() {
    bulkRevision += 1;
    bulkRequestId = null;
    bulkRequestProfiles = null;
    clearTimeout(bulkValidationTimer);
    bulkValidationTimer = null;
    bulkValidationPending = false;
    bulkRows = [];
    bulkRowNodes.clear();
    ui['bulk-preview'].hidden = true;
    ui['bulk-rows'].replaceChildren();
    ui['bulk-summary'].textContent = '';
    bulkSelectionHelp.textContent = '';
    ui['bulk-select-all'].checked = false;
    ui['bulk-select-all'].indeterminate = false;
    ui['bulk-save-button'].textContent = '匯入已選帳號';
    showBulkError('');
    updateLocks();
  }
  function openBulkEditor() {
    if (busy || !loaded || writeBlocked()) return;
    returnFocus = document.activeElement;
    ui['bulk-form'].reset();
    ui['bulk-file-label'].textContent = 'Excel、JSON 或文字檔；Excel 只取第一欄名稱與 Cookie 欄';
    invalidateBulkPreview();
    ui['bulk-editor'].hidden = false;
    document.body.classList.add('modal-open');
    document.querySelector('.app-shell').setAttribute('aria-hidden', 'true');
    ui['bulk-url'].focus();
  }
  function closeBulkEditor() {
    if (busy) return;
    ui['bulk-editor'].hidden = true;
    ui['bulk-form'].reset();
    invalidateBulkPreview();
    document.body.classList.remove('modal-open');
    document.querySelector('.app-shell').removeAttribute('aria-hidden');
    if (returnFocus && returnFocus.isConnected) returnFocus.focus();
    else ui['bulk-button'].focus();
  }
  function updateBulkRows() {
    let valid = 0;
    let selected = 0;
    let invalid = 0;
    bulkRows.forEach((row) => {
      const nodes = bulkRowNodes.get(row.key);
      if (row.error) invalid += 1;
      else valid += 1;
      if (row.selected && !row.error) selected += 1;
      if (!nodes) return;
      nodes.card.classList.toggle('has-error', Boolean(row.error));
      nodes.checkbox.checked = Boolean(row.selected && !row.error);
      nodes.checkbox.disabled = Boolean(row.error);
      nodes.checkbox.setAttribute('aria-label', '匯入 ' + (row.name || '未命名帳號'));
      nodes.status.textContent = row.error ? '需修正' : row.selected ? '已選取' : '可匯入';
      nodes.status.className = 'bulk-row-status ' + (row.error ? 'diagnostic-no' : 'diagnostic-ok');
      const cookieCount = (row.cookies || []).length;
      nodes.meta.textContent = '來源：' + row.source + ' · ' + (row.error && !cookieCount ? '尚未完成解析' : cookieCount + ' 個 Cookie');
      nodes.domains.replaceChildren();
      (row.domains || []).forEach((domain) => nodes.domains.append(element('span', 'domain-tag', domain)));
      nodes.warnings.replaceChildren();
      (row.warnings || []).forEach((warning) => nodes.warnings.append(element('li', '', typeof warning === 'string' ? warning : warning.message || '此資料有注意事項。')));
      nodes.error.textContent = row.error || '';
      nodes.error.hidden = !row.error;
      nodes.duplicates.container.hidden = row.errorCode !== 'CONFLICTING_DUPLICATE' && !(row.conflicts && row.conflicts.groupCount) && (!row.duplicatePolicy || row.duplicatePolicy === 'reject');
      nodes.duplicates.select.value = row.duplicatePolicy || 'reject';
    });
    ui['bulk-summary'].textContent = '共 ' + bulkRows.length + ' 個項目 · 已選 ' + selected + ' 個 · 可匯入 ' + valid + ' 個 · 需修正 ' + invalid + ' 個';
    ui['bulk-select-all'].disabled = !valid;
    ui['bulk-select-all'].checked = valid > 0 && selected === valid;
    ui['bulk-select-all'].indeterminate = selected > 0 && selected < valid;
    ui['bulk-save-button'].textContent = selected ? '匯入 ' + selected + ' 個帳號' : '匯入已選帳號';
    bulkSelectionHelp.textContent = selected ? '已選帳號只會儲存到管理器；匯入後再選擇「套用並開啟」。' : valid ? '請勾選要匯入的帳號。剛修正的項目需重新勾選，才會開放匯入。' : '目前沒有可匯入的項目。請依下方提示修正；若有重複 Cookie，可在該帳號內選擇處理方式。';
    updateLocks();
  }
  function revalidateBulkRows() {
    clearTimeout(bulkValidationTimer);
    bulkValidationTimer = null;
    bulkValidationPending = false;
    const result = globalThis.AccountBulk.validateRows(bulkRows, { existingNames:state.profiles.map((profile) => profile.name) });
    bulkRows = result.rows;
    updateBulkRows();
  }
  function renderBulkRows() {
    ui['bulk-rows'].replaceChildren();
    bulkRowNodes.clear();
    bulkRows.forEach((row, index) => {
      const card = element('article', 'bulk-row');
      const heading = element('div', 'bulk-row-heading');
      const selectLabel = element('label', 'bulk-row-select');
      const checkbox = element('input');
      checkbox.type = 'checkbox';
      selectLabel.append(checkbox, element('span', '', '帳號 ' + (index + 1)));
      const status = element('span', 'bulk-row-status');
      heading.append(selectLabel, status);
      const meta = element('p', 'bulk-source');
      const nameLabel = element('label', 'field');
      const nameInput = element('input');
      nameInput.type = 'text'; nameInput.maxLength = 100; nameInput.autocomplete = 'off';
      nameInput.value = row.name || ''; nameInput.setAttribute('aria-label', '第 ' + (index + 1) + ' 個帳號名稱');
      nameLabel.append(element('span', '', '帳號名稱'), nameInput);
      const urlLabel = element('label', 'field');
      const urlInput = element('input');
      urlInput.type = 'url'; urlInput.inputMode = 'url'; urlInput.autocomplete = 'off'; urlInput.spellcheck = false;
      urlInput.value = row.startUrl || ''; urlInput.placeholder = 'https://example.com/account';
      urlInput.setAttribute('aria-label', '第 ' + (index + 1) + ' 個帳號的起始網址');
      urlLabel.append(element('span', '', '切換後開啟的網址'), urlInput);
      const fields = element('div', 'bulk-row-fields');
      fields.append(nameLabel, urlLabel);
      const domains = element('div', 'domain-tags');
      const warnings = element('ul', 'preview-warnings');
      const error = element('p', 'form-error');
      error.id = 'bulk-row-error-' + index;
      const duplicates = duplicateControl('bulk-duplicate-policy-' + index, '第 ' + (index + 1) + ' 個帳號的重複 Cookie 處理方式');
      nameInput.setAttribute('aria-describedby', error.id);
      urlInput.setAttribute('aria-describedby', error.id);
      card.append(heading, meta, fields, domains, warnings, error, duplicates.container);
      bulkRowNodes.set(row.key, { card, checkbox, status, meta, domains, warnings, error, duplicates });
      duplicates.select.addEventListener('change', () => {
        if (busy || writeBlocked()) return;
        const current = bulkRows.find((item) => item.key === row.key);
        if (!current) return;
        current.duplicatePolicy = duplicates.select.value;
        current.selected = false;
        bulkRequestId = null;
        bulkRequestProfiles = null;
        showBulkError('');
        revalidateBulkRows();
      });
      checkbox.addEventListener('change', () => {
        if (busy || writeBlocked()) return;
        const current = bulkRows.find((item) => item.key === row.key);
        if (!current || current.error) return;
        current.selected = checkbox.checked;
        bulkRequestId = null;
        bulkRequestProfiles = null;
        showBulkError('');
        updateBulkRows();
      });
      function editRow(field, value) {
        if (busy || writeBlocked()) return;
        const current = bulkRows.find((item) => item.key === row.key);
        if (!current) return;
        current[field] = value;
        bulkRequestId = null;
        bulkRequestProfiles = null;
        showBulkError('');
        clearTimeout(bulkValidationTimer);
        bulkValidationPending = true;
        updateLocks();
        bulkValidationTimer = setTimeout(revalidateBulkRows, 250);
      }
      nameInput.addEventListener('input', () => editRow('name', nameInput.value));
      urlInput.addEventListener('input', () => editRow('startUrl', urlInput.value));
      nameInput.addEventListener('change', () => { if (bulkValidationPending) revalidateBulkRows(); });
      urlInput.addEventListener('change', () => { if (bulkValidationPending) revalidateBulkRows(); });
      ui['bulk-rows'].append(card);
    });
    updateBulkRows();
  }
  async function prepareBulkPreview() {
    if (busy || !loaded || writeBlocked()) return;
    invalidateBulkPreview();
    const revision = bulkRevision;
    const files = Array.from(ui['bulk-files'].files || []);
    const pasted = ui['bulk-text'].value;
    const defaultUrl = ui['bulk-url'].value;
    const pasteBytes = new Blob([pasted]).size;
    setBusy(true);
    ui['bulk-preview-button'].textContent = '正在讀取與解析…';
    try {
      if (!globalThis.AccountBulk) throw new Error('批量解析功能尚未載入，請重新開啟管理器。');
      if (!files.length && !pasted.trim()) throw new Error('請先選取檔案或貼上批量帳號資料。');
      if (files.length + Number(Boolean(pasted.trim())) > MAX_BATCH_ACCOUNTS) throw new Error('每批最多 100 個來源，請分批匯入。');
      if (pasteBytes > MAX_IMPORT_BYTES) throw new Error('貼上資料超過 4 MB，請拆成較小的批次。');
      if (files.reduce((sum, file) => sum + file.size, pasteBytes) > MAX_BATCH_BYTES) throw new Error('本批資料超過 12 MB，請分批匯入。');
      if (defaultUrl.trim()) globalThis.AccountCore.validateUrl(defaultUrl);
      let unreadableFiles = 0, skippedWorkbookRows = 0, archiveFiles = 0, ignoredArchiveFiles = 0, expandedBytes = pasteBytes;
      const sources = [];
      for (const file of files) {
        if (revision !== bulkRevision) return;
        let group;
        if (file.size > MAX_IMPORT_BYTES) {
          group=[{ name:file.name, text:'', error:'檔案超過 4 MB，請拆成較小的檔案。' }];
        } else try {
          if(/\.zip$/i.test(file.name)){
            const archive=globalThis.AccountArchive.read(await readFile(file,true));
            skippedWorkbookRows+=archive.blankRows;ignoredArchiveFiles+=archive.ignored;archiveFiles+=archive.sources.length;
            group=archive.sources;
          } else if(/\.xlsx$/i.test(file.name)){
            if(!globalThis.AccountWorkbook)throw new Error('Excel 讀取功能尚未載入，請重新開啟管理器。');
            const workbook=globalThis.AccountWorkbook.read(await readFile(file,true));
            skippedWorkbookRows+=workbook.blankRows;
            group=[{name:file.name,text:workbook.text}];
          } else group=[{ name:file.name, text:await readFile(file) }];
        }
        catch (_) { unreadableFiles += 1; group=[{ name:file.name, text:'', error:'無法讀取此檔案，請重新選取或貼上內容。' }]; }
        expandedBytes+=group.reduce((sum,source)=>sum+new Blob([source.text]).size,0);
        if(expandedBytes>MAX_BATCH_BYTES)throw new Error('解壓後本批資料超過 12 MB，請分批匯入。');
        if(sources.length+group.length+Number(Boolean(pasted.trim()))>MAX_BATCH_ACCOUNTS)throw new Error('解壓後每批最多 100 個資料檔，請分批匯入。');
        sources.push(...group);
      }
      if (pasted.trim()) sources.push({ name:'貼上資料', text:pasted });
      if (revision !== bulkRevision) return;
      const result = globalThis.AccountBulk.parseSources(sources, { defaultUrl, existingNames:state.profiles.map((profile) => profile.name) });
      bulkRows = result.rows;
      if (bulkRows.length > MAX_BATCH_ACCOUNTS) throw new Error('每批最多 100 個帳號，請分批匯入。');
      renderBulkRows();
      if(skippedWorkbookRows)bulkSelectionHelp.textContent+=' 已略過 '+skippedWorkbookRows+' 列空白 Cookie；其他 Excel 欄位不匯入。';
      if(archiveFiles)bulkSelectionHelp.textContent+=' ZIP 已讀取 '+archiveFiles+' 個資料檔，每個 Cookie 檔各自建立帳號。';
      if(ignoredArchiveFiles)bulkSelectionHelp.textContent+=' 已略過 '+ignoredArchiveFiles+' 個非支援資料檔。';
      ui['bulk-preview'].hidden = false;
      if (unreadableFiles) showBulkError(unreadableFiles + ' 個檔案未能讀取。請確認已下載至裝置；ZIP 須未加密、每檔不超過 4 MB，解壓合計不超過 12 MB。其餘有效項目仍可匯入。');
      reveal(ui['bulk-preview']);
    } catch (error) {
      invalidateBulkPreview();
      showBulkError(errorMessage(error));
      reveal(ui['bulk-error']);
    } finally {
      ui['bulk-preview-button'].textContent = '解析並預覽帳號';
      setBusy(false);
    }
  }
  ui['cookie-file'].addEventListener('change', async () => {
    const file = ui['cookie-file'].files && ui['cookie-file'].files[0];
    resetDuplicateChoice();
    invalidatePreview();
    ui['cookie-text'].value = '';
    if (!file) { ui['file-label'].textContent = 'JSON 或文字檔'; return; }
    ui['file-label'].textContent = file.name;
    if (file.size > MAX_IMPORT_BYTES) { showFormError('檔案超過 4 MB，請改用較小的單一帳號匯出檔。'); reveal(ui['form-error']); return; }
    setBusy(true);
    try { ui['cookie-text'].value = await readFile(file); }
    catch (error) { showFormError(errorMessage(error)); reveal(ui['form-error']); }
    finally { setBusy(false); }
  });
  ui['preview-button'].addEventListener('click', previewAndReveal);
  ui['cookie-text'].addEventListener('input', () => { resetDuplicateChoice(); invalidatePreview(); });
  ui['profile-url'].addEventListener('input', invalidatePreview);
  ui['profile-name'].addEventListener('input', () => { saveRequestId = null; saveRequestProfile = null; showFormError(''); });
  ui['profile-form'].addEventListener('submit', async (event) => {
    event.preventDefault();
    if (busy || !loaded || writeBlocked()) return;
    try {
      if (!saveRequestId) {
        const name = ui['profile-name'].value.trim();
        if (!name) throw new Error('請填寫帳號名稱。');
        const startUrl = validatedUrl();
        const raw = ui['cookie-text'].value;
        const hasImport = Boolean(raw.trim());
        if (!editingId && !hasImport) throw new Error('新增帳號需要匯入 Cookie。');
        if (hasImport && (!preview || preview.source !== raw || preview.startUrl !== startUrl || preview.duplicatePolicy !== duplicatePolicy)) throw new Error('請先點選「預覽匯入內容」，確認本次資料後再儲存。');
        const profile = { name, startUrl };
        if (editingId) profile.id = editingId;
        if (hasImport) profile.cookies = preview.cookies;
        if (!globalThis.crypto || typeof globalThis.crypto.randomUUID !== 'function') throw new Error('此裝置無法產生儲存識別碼，請更新 Orion 後重試。');
        saveRequestProfile = JSON.parse(JSON.stringify(profile));
        saveRequestId = globalThis.crypto.randomUUID();
      }
      const name = saveRequestProfile.name;
      setBusy(true);
      showFormError('');
      applyState(await send({ type:'save', requestId:saveRequestId, profile:saveRequestProfile }));
      setBusy(false);
      closeEditor();
      notify('已儲存「' + name + '」。選擇「套用並開啟」即可套用 Cookie。');
    } catch (error) { showFormError(errorMessage(error) + (saveRequestId ? ' 可先按「重新讀取狀態」確認進度；保持內容不變重試，不會重複新增。' : '')); }
    finally { setBusy(false); }
  });
  ui['add-button'].addEventListener('click', () => openEditor());
  ui['bulk-button'].addEventListener('click', openBulkEditor);
  ui['close-bulk'].addEventListener('click', closeBulkEditor);
  ui['cancel-bulk'].addEventListener('click', closeBulkEditor);
  ui['bulk-preview-button'].addEventListener('click', prepareBulkPreview);
  ui['bulk-files'].addEventListener('change', () => {
    invalidateBulkPreview();
    const files = Array.from(ui['bulk-files'].files || []);
    ui['bulk-file-label'].textContent = files.length ? '已選取 ' + files.length + ' 個檔案 · ' + (files.reduce((sum, file) => sum + file.size, 0) / 1024 / 1024).toFixed(2) + ' MB' : 'JSON 或文字檔，可同時選取多個檔案';
  });
  ui['bulk-url'].addEventListener('input', invalidateBulkPreview);
  ui['bulk-text'].addEventListener('input', invalidateBulkPreview);
  ui['bulk-select-all'].addEventListener('change', () => {
    if (busy || writeBlocked()) return;
    bulkRows.forEach((row) => { row.selected = !row.error && ui['bulk-select-all'].checked; });
    bulkRequestId = null;
    bulkRequestProfiles = null;
    showBulkError('');
    updateBulkRows();
  });
  ui['bulk-form'].addEventListener('submit', async (event) => {
    event.preventDefault();
    if (busy || !loaded || writeBlocked()) return;
    try {
      if (!bulkRequestId) {
        revalidateBulkRows();
        const selected = bulkRows.filter((row) => row.selected && !row.error).map((row) => ({ name:row.name, startUrl:row.startUrl, cookies:row.cookies }));
        if (!selected.length) throw new Error('請先預覽並勾選至少一個可匯入的帳號。');
        if (selected.length > MAX_BATCH_ACCOUNTS) throw new Error('每批最多 100 個帳號，請分批匯入。');
        if (!globalThis.crypto || typeof globalThis.crypto.randomUUID !== 'function') throw new Error('此裝置無法產生批次識別碼，請更新 Orion 後重試。');
        bulkRequestProfiles = JSON.parse(JSON.stringify(selected));
        bulkRequestId = globalThis.crypto.randomUUID();
      }
      // A lost acknowledgement must retry the exact request, even if a Cookie expires meanwhile.
      const profiles = bulkRequestProfiles;
      setBusy(true);
      showBulkError('');
      ui['bulk-save-button'].textContent = '正在匯入…';
      const result = await send({ type:'bulkSave', requestId:bulkRequestId, profiles });
      if (result && Array.isArray(result.profiles)) applyState(result);
      else await refreshState();
      const count = Number.isInteger(result && result.importedCount) ? result.importedCount : profiles.length;
      setBusy(false);
      closeBulkEditor();
      notify('已匯入 ' + count + ' 個帳號。選擇「套用並開啟」後才會套用 Cookie。');
    } catch (error) {
      showBulkError(errorMessage(error) + (bulkRequestId ? operationBlocked() ? ' 本次選取內容已保留；請按「重新讀取狀態」，等待背景操作解除後再繼續。' : ' 可先按「重新讀取狀態」確認結果；保持選取內容不變重試，不會重複建立帳號。' : ''));
      updateBulkRows();
    } finally { setBusy(false); }
  });
  ui['close-editor'].addEventListener('click', closeEditor);
  ui['cancel-editor'].addEventListener('click', closeEditor);
  function trapDialogFocus(dialog, close) {
    dialog.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') { event.preventDefault(); close(); return; }
      if (event.key !== 'Tab') return;
      const focusable = [...dialog.querySelectorAll('button:not(:disabled),input:not(:disabled),textarea:not(:disabled),select:not(:disabled),a[href],summary,[tabindex="0"]')].filter((node) => node.getClientRects().length > 0);
      if (!focusable.length) { event.preventDefault(); return; }
      const first = focusable[0]; const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    });
  }
  trapDialogFocus(developerTools, closeDeveloper);
  trapDialogFocus(ui.editor, closeEditor);
  trapDialogFocus(ui['bulk-editor'], closeBulkEditor);
  trapDialogFocus(ui['switch-inspector'], closeSwitchInspector);
  ui['close-switch-inspector'].addEventListener('click', closeSwitchInspector);
  ui['done-switch-inspector'].addEventListener('click', closeSwitchInspector);
  ui['retry-switch-inspector'].addEventListener('click', inspectProfile);
  ui['site-copy-button'].addEventListener('click', createSiteCopy);
  ui['expiry-compatibility-consent'].addEventListener('change', updateLocks);
  ui['expiry-compatibility-button'].addEventListener('click', runExpiryCompatibility);
  ui['native-compatibility-button'].addEventListener('click',()=>nativeRecoveryAvailable() ? runNativeRecovery() : runNativeCompatibility(inspectedProfile));
  ui['native-recovery-button'].addEventListener('click',runNativeRecovery);
  for (const prefix of ['','inspector-']) ui[prefix+'cookie-probe-button'].addEventListener('click', runCookieProbe);
  ui['switch-inspector-refresh'].addEventListener('click', async () => {
    if (busy) return;
    setBusy(true);
    try {
      await refreshState();
      const request = inspectedProfile && siteCopyRequests.get(inspectedProfile.id);
      if (request) request.needsRefresh = false;
      ui['site-copy-status'].textContent = operationBlocked() ? '背景操作尚未確認完成，請稍候再讀取。原要求已保留。' : '帳號清單已更新。可返回查看，或保持此畫面重試建立副本；相同要求不會重複新增。';
    } catch (_) { ui['site-copy-status'].textContent = '未能讀取最新狀態。請稍後重試，原要求仍保留。'; }
    finally { setBusy(false); }
  });
  ui.search.addEventListener('input', renderCards);
  ui['refresh-button'].addEventListener('click', () => runOperation('正在重新讀取帳號…', async () => {}, '帳號清單已更新。'));
  ui['recover-button'].addEventListener('click', () => runOperation('正在恢復切換前的 Cookie，請保持管理器開啟…', () => send({ type:'recover' }), '恢復完成。請在網站確認狀態後再繼續切換。'));
  ui['abandon-recovery-button'].addEventListener('click', () => {
    if (busy || !state.pending || operationBlocked() || !window.confirm('停止復原並保留現有 Cookie？\n\n不會還原或登出；可繼續整理帳號，下次切換仍須清理相關網站 Cookie。若有不相容資料，需在 Orion 手動清除該網站資料。')) return;
    runOperation('正在解除待恢復狀態…', () => send({ type:'abandonRecovery', confirm:true }), '已停止復原並保留現有 Cookie。下次切換會重新清理相關網站的 Cookie。');
  });
  ui['discard-invalid-button'].addEventListener('click', () => {
    if (busy || writeBlocked() || !state.invalidProfileCount || !window.confirm('移除 ' + state.invalidProfileCount + ' 筆損壞或識別重複的帳號紀錄？\n\n只移除無法使用的本機紀錄，不會修改目前網站 Cookie。需要的帳號請從原始匯出檔重新匯入。')) return;
    runOperation('正在整理損壞的帳號紀錄…', () => send({ type:'discardInvalid', confirm:true }), '已移除損壞紀錄，其餘帳號及目前網站 Cookie 保持原狀。');
  });
  async function refreshFromEditor(kind) {
    if (busy) return;
    const display = kind === 'bulk' ? showBulkError : showFormError;
    setBusy(true);
    try {
      await refreshState();
      display(state.pending ? '已讀取最新狀態：有待恢復的切換。請關閉此對話框，依主畫面提示恢復或停止復原。' : operationBlocked() ? '背景尚未完成，請稍候再次讀取。草稿已保留；若持續無回應，請完全關閉 Orion 再開啟。' : '已讀取最新狀態。可保持內容不變按儲存重試，已完成的同一筆要求不會重複建立帳號。');
    } catch (error) { display(errorMessage(error)); }
    finally { setBusy(false); }
  }
  ui['editor-refresh'].addEventListener('click', () => refreshFromEditor('single'));
  ui['bulk-refresh'].addEventListener('click', () => refreshFromEditor('bulk'));
  ui['diagnostics-button'].addEventListener('click', async () => {
    if (busy) return;
    setBusy(true);
    ui['diagnostics-result'].replaceChildren(element('p', 'diagnostic-note', '正在檢查此裝置…'));
    try {
      const result = await send({ type:'diagnostics' });
      const list = element('ul', 'diagnostic-list');
      (result.checks || []).forEach((check) => {
        const item = element('li');
        const status = check.status || (check.available ? 'present' : 'failed');
        const statusLabels = { passed:'檢查通過', warning:'需要留意', failed:'檢查未通過', present:'功能存在' };
        const title = element('div', 'diagnostic-heading');
        title.append(element('span', '', friendlyChecks[check.name] || check.label || check.name), element('span', status === 'warning' ? 'diagnostic-warning' : status === 'failed' ? 'diagnostic-no' : 'diagnostic-ok', statusLabels[status] || '待確認'));
        item.append(title);
        if (check.detail) item.append(element('p', 'diagnostic-detail', check.detail));
        list.append(item);
      });
      ui['diagnostics-result'].replaceChildren(list, element('p', 'diagnostic-note', result.note || '功能存在不代表網站接受匯入的登入狀態，仍須實際確認。'));
      if (Number.isInteger(result.profileErrorCount)) ui['diagnostics-result'].append(element('p', result.profileErrorCount ? 'diagnostic-warning' : 'diagnostic-note', '帳號資料問題：' + result.profileErrorCount + ' 個'));
    } catch (error) { ui['diagnostics-result'].replaceChildren(element('p', 'form-error', errorMessage(error))); }
    finally { setBusy(false); }
  });
  window.addEventListener('pageshow', (event) => {
    if (event.persisted && !busy && ui.editor.hidden && ui['bulk-editor'].hidden && ui['switch-inspector'].hidden) runOperation('正在更新帳號狀態…', async () => {}, '帳號清單已更新。');
  });
  setBusy(true);
  refreshState().then(() => {
    if (state.lastResult && state.lastResult.message) notify('上次操作：' + state.lastResult.message,state.pending?'warning':undefined);
  }).catch((error) => {
    ui['active-name'].textContent = '尚未連線';
    ui['active-detail'].textContent = '請確認擴充套件已啟用，再重新整理。';
    notify(errorMessage(error), 'error');
  }).finally(() => setBusy(false));
})();

