(function () {
  'use strict';
  if(window.top!==window)return;
  if(globalThis.__orionQuickRefresh){globalThis.__orionQuickRefresh();return;}
  const native=globalThis.browser||globalThis.chrome;
  function send(message) {
    if(globalThis.browser)return native.runtime.sendMessage(message);
    return new Promise((resolve,reject)=>native.runtime.sendMessage(message,result=>native.runtime.lastError?reject(new Error('連線中斷')):resolve(result)));
  }
  let checking=false,timer=null,attempt=0,mounted=null,enabled=false,repairs=0;
  async function refresh(){
    if(checking)return;
    checking=true;
    try {
      const first=await Promise.race([send({type:'quickState'}),new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error()),4000);})]);
      clearTimeout(timer);
      if(!first?.ok)throw new Error();
      attempt=0;
      repairs=0;
      enabled=first.data.enabled===true;
      if(!enabled){mounted?.remove();return;}
      if(mounted){if(!mounted.isConnected)document.documentElement.append(mounted);return;}
      if(!document.querySelector('orion-account-switcher'))mounted=mount(first);
    }catch(_){if(attempt++<3)setTimeout(refresh,1000*attempt);}
    finally{clearTimeout(timer);checking=false;}
  }
  globalThis.__orionQuickRefresh=refresh;
  window.addEventListener('pageshow',refresh);
  window.addEventListener('focus',refresh);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh();});
  // A site replacing its document children must not permanently remove the entry.
  new MutationObserver(()=>{if(enabled&&mounted&&!mounted.isConnected&&repairs++<3)document.documentElement.append(mounted);}).observe(document.documentElement,{childList:true});
  refresh();
  function mount(first){
  const host=document.createElement('orion-account-switcher');
  host.style.cssText='all:initial!important;position:fixed!important;right:8px!important;top:38%!important;z-index:2147483647!important;display:block!important;';
  const shadow=host.attachShadow({mode:'closed'}),style=document.createElement('style');
  style.textContent=`:host{color-scheme:light}*{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:focus-visible,input:focus-visible{outline:3px solid #8fc2b8;outline-offset:2px}.wrap{font:15px/1.5 system-ui,sans-serif;color:#1c2c36}.toggle{display:block;margin-left:auto;border:1px solid #ffffff90;border-radius:20px;padding:8px 12px;min-height:44px;background:#326b62ed;color:white;box-shadow:0 2px 10px #0002}.panel{position:absolute;right:0;top:50px;width:min(300px,calc(100vw - 24px));max-height:52vh;overflow:auto;border-radius:18px;background:#f8f8f2;box-shadow:0 6px 30px #0003;padding:14px;border:1px solid #dce1db}.panel[hidden]{display:none}.top{display:flex;align-items:center;justify-content:space-between;gap:8px}.title{font-weight:700}.close{border:0;background:none;font-size:22px;min-width:44px;min-height:44px;color:#53656a}input{width:100%;border:1px solid #d8ded8;border-radius:10px;background:white;padding:10px;margin:8px 0}.row{display:block;width:100%;text-align:left;border:0;border-radius:10px;padding:12px;margin:4px 0;background:white;color:#1c2c36;overflow-wrap:anywhere}.row:disabled{opacity:.55}.current{font-size:12px;color:#326b62;margin-left:8px}.note{margin:8px 0 0;font-size:12px;color:#65736e}.status{font-size:13px;color:#874337;overflow-wrap:anywhere}`;
  const wrap=document.createElement('div');wrap.className='wrap';
  wrap.innerHTML='<button class="toggle" aria-label="快速切換帳號" aria-expanded="false">⇄ 切換</button><section class="panel" aria-label="切換帳號" hidden><div class="top"><span class="title">切換帳號</span><button class="close" aria-label="關閉切換選單">×</button></div><input type="search" placeholder="搜尋帳號" aria-label="搜尋帳號"><div class="status" role="status"></div><div class="list"></div><p class="note">切換會關閉一般網頁並清除一般網站登入與儲存資料；匯入帳號庫保留。</p></section>';
  shadow.append(style,wrap);document.documentElement.append(host);
  const toggle=shadow.querySelector('.toggle'),panel=shadow.querySelector('.panel'),search=shadow.querySelector('input'),list=shadow.querySelector('.list'),status=shadow.querySelector('.status');
  let state=first.data,working=false,opening=0;
  function render() {
    list.replaceChildren();
    const rows=state.profiles.filter(p=>p.name.toLocaleLowerCase().includes(search.value.trim().toLocaleLowerCase()));
    for(const p of rows) {
      const b=document.createElement('button');b.className='row';b.textContent=p.name;b.disabled=working||state.busy||state.stalled;
      if(p.id===state.activeId){const tag=document.createElement('span');tag.className='current';tag.textContent='目前';b.append(tag);}
      b.addEventListener('click',async event=>{
        if(!event.isTrusted||working||b.disabled)return;
        working=true;render();status.textContent='正在切換…';
        try {const r=await send({type:'quickStart',id:p.id});if(!r?.ok)throw new Error();}
        catch(_){status.textContent='切換未開始，請關閉選單後重試。';working=false;render();}
      });list.append(b);
    }
    if(!rows.length){const empty=document.createElement('p');empty.textContent='沒有符合的帳號';list.append(empty);}
  }
  function close(){opening++;panel.hidden=true;toggle.setAttribute('aria-expanded','false');toggle.focus();}
  toggle.addEventListener('click',async event=>{
    if(!event.isTrusted)return;
    if(!panel.hidden){close();return;}
    panel.hidden=false;toggle.setAttribute('aria-expanded','true');status.textContent='讀取帳號…';list.replaceChildren();search.value='';
    const request=++opening;
    try {const r=await send({type:'quickState'});if(request!==opening)return;if(!r?.ok||!r.data.enabled)throw new Error();state=r.data;working=false;status.textContent=state.stalled?'上次操作仍在等待瀏覽器回覆，請稍後再試。':state.busy?'正在切換，請稍候。':'';render();search.focus();}
    catch(_){status.textContent='無法取得帳號，請重新整理網頁。';}
  });
  shadow.querySelector('.close').addEventListener('click',close);
  search.addEventListener('input',render);
  shadow.addEventListener('keydown',event=>{if(event.key==='Escape')close();});
  return host;
  }
})();
