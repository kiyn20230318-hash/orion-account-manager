(function(root){
  'use strict';
  const stages=['preflight','closing_tabs','clearing','installing','verification','repairing','commit','open'];
  const apis=['storage.local.get','storage.local.set','cookies.getAll','cookies.set','cookies.remove','tabs.query','tabs.get','tabs.remove','tabs.update','tabs.create'];
  const fields=['name','value','domain','path','hostOnly','secure','httpOnly','session','sameSite','expirationDate'];
  const number=v=>typeof v==='number'&&Number.isFinite(v)&&v>=0?Math.min(v,Number.MAX_SAFE_INTEGER):undefined;
  const pick=(v,values)=>values.includes(v)?v:'unknown';
  const version=v=>typeof v==='string'&&/^\d+(\.\d+){1,3}$/.test(v)?v:null;
  function nums(source,keys){const out={};for(const key of keys){const n=number(source?.[key]);if(n!==undefined)out[key]=n;}return out;}
  const counts=['expectedCount','actualCount','matchedCount','missingCount','unexpectedCount','duplicateCount','valueMismatchCount','temporarySessionCount'];
  function verification(v){return {...nums(v,counts),attributeLimited:v?.attributeLimited===true,contentVerification:nums(v?.contentVerification,counts),differences:(Array.isArray(v?.differences)?v.differences:[]).slice(0,20).filter(x=>fields.includes(x?.field)).map(x=>({field:x.field,count:number(x.count)||0}))};}
  // Deliberately reconstruct every exported object. Never spread storage, errors,
  // native arguments/results, account names, identifiers, URLs or Cookie data.
  function attempt(a={}){
    if(!a||typeof a!=='object')a={};
    const out={version:version(a.version),...nums(a,['startedAt','at']),status:pick(a.status,['running','failed','applied','opened']),stage:pick(a.stage,stages),mutated:a.mutated===true,compatibilityUsed:a.compatibilityUsed===true,attributeCompatibilityUsed:a.attributeCompatibilityUsed===true,recovery:{status:pick(a.recovery?.status,['not_needed','pending','restored','restored_limited','abandoned'])}};
    out.durationMs=Math.max(0,(out.at||out.startedAt||0)-(out.startedAt||0));
    out.failureCategory=out.status!=='failed'?'none':pick(a.failureCategory,['native_timeout','native_rejected','validation_or_mismatch']);
    for(const key of ['clearingSummary','restoreClearingSummary','repairClearingSummary'])out[key]=nums(a[key],['initialCount','remainingCount','removeCalls','removeEmptyReplies','removeErrors','expiryCalls','expiryErrors','expiryHostOnlyCalls','expiryDottedDomainCalls','expiryBareDomainCalls','postExpiryRemoveCalls','polls','reappearedCount','residualIdentityCount','replaceableCount','overwriteDeferredCount','unmatchedTargetSiteCount','unmatchedOtherSiteCount']);
    out.verification=verification(a.verification);
    out.verificationSettlement=nums(a.verificationSettlement,['reads','mismatchedReads','consecutiveMatches']);
    out.tabPreparation={status:pick(a.tabPreparation?.status,['confirmed','unconfirmed'])};
    out.writeReadbackSummary=nums(a.writeReadbackSummary,['requestedCount','receivedCount']);
    for(const key of ['missingFieldCounts','invalidFieldCounts','differences'])out.writeReadbackSummary[key]=(Array.isArray(a.writeReadbackSummary?.[key])?a.writeReadbackSummary[key]:[]).slice(0,20).filter(x=>fields.includes(x?.field)).map(x=>({field:x.field,count:number(x.count)||0}));
    out.cookieWrite={...nums(a.cookieWrite,['ordinal','total']),category:pick(a.cookieWrite?.category,['native_rejected','unconfirmed_result'])};
    out.repair={status:pick(a.repair?.status,['started','cleared','verified','failed']),initialVerification:nums(a.repair?.initialVerification,counts)};
    out.apiSummary=(Array.isArray(a.apiSummary)?a.apiSummary:[]).slice(0,80).filter(x=>apis.includes(x?.api)).map(x=>({api:x.api,stage:pick(x.stage,stages),recovery:x.recovery===true,...nums(x,['calls','resolved','rejected','timeouts','lateResolved','lateRejected','totalMs','maxMs','firstMs','lastMs'])}));
    return out;
  }
  function report({version:ver,at,entries=[],busy=false,stalled=false,pending=false,storageReadable=true}={}){
    const aliases=new Map();
    return {format:'orion-switch-error-log',formatVersion:1,extensionVersion:version(ver),generatedAt:number(at)||0,privacy:'No account names, identifiers, URLs, Cookie contents, credentials or raw browser errors. No automatic upload.',websiteLoginVerified:false,storageReadable:storageReadable===true,operation:{busy:busy===true,stalled:stalled===true,pending:pending===true},attempts:entries.filter(e=>e&&typeof e==='object').slice(-20).sort((a,b)=>(number(a.report?.startedAt)||0)-(number(b.report?.startedAt)||0)).map(entry=>{const key=entry.profileKey;if(!aliases.has(key))aliases.set(key,'account-'+(aliases.size+1));return {...attempt(entry.report),account:aliases.get(key)};})};
  }
  const api={attempt,report,apis,stages};root.AccountErrorLog=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(globalThis);
