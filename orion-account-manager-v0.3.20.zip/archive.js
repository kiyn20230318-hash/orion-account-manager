(function(root,factory){
  'use strict';
  const api=factory(typeof module==='object'&&module.exports?require('./vendor/fflate.js'):root.fflate,()=>root.AccountWorkbook);
  if(typeof module==='object'&&module.exports)module.exports=api;
  root.AccountArchive=api;
})(globalThis,function(zip,workbook){
  'use strict';
  const MAX_FILE=4*1024*1024,MAX_TOTAL=12*1024*1024,MAX_FILES=100;
  function read(bytes){
    if(!zip)throw new Error('ZIP 讀取功能尚未載入，請重新開啟管理器。');
    const input=new Uint8Array(bytes);
    if(input.length>MAX_FILE)throw new Error('ZIP 超過 4 MB，請分批匯出。');
    let total=0,count=0,ignored=0,files;
    try{files=zip.unzipSync(input,{filter:entry=>{
      const name=entry.name.replace(/\\/g,'/');
      if(name.endsWith('/'))return false;
      if(name.split('/').some(p=>p==='..')||name.startsWith('/')||/^[A-Za-z]:/.test(name))throw new Error('path');
      if(name.split('/').some(p=>p==='__MACOSX'||p.startsWith('.'))||! /\.(json|txt|cookies|xlsx)$/i.test(name)){ignored++;return false;}
      if(!Number.isSafeInteger(entry.originalSize)||entry.originalSize<0||entry.originalSize>MAX_FILE)throw new Error('size');
      total+=entry.originalSize;
      if(total>MAX_TOTAL||++count>MAX_FILES)throw new Error('size');
      return true;
    }});}catch(_){throw new Error('ZIP 無法讀取、已加密或資料過大。請使用未加密 ZIP；最多 100 個資料檔、每檔 4 MB、解壓合計 12 MB。');}
    const sources=[];let blankRows=0;
    for(const [name,data] of Object.entries(files)){
      if(data.length>MAX_FILE)throw new Error('ZIP 內單一檔案超過 4 MB。');
      try{
        if(/\.xlsx$/i.test(name)){
          const result=workbook().read(data);blankRows+=result.blankRows;sources.push({name,text:result.text});
        }else{
          const encoding=data[0]===255&&data[1]===254?'utf-16le':data[0]===254&&data[1]===255?'utf-16be':'utf-8';
          sources.push({name,text:new TextDecoder(encoding,{fatal:true}).decode(data)});
        }
      }catch(_){sources.push({name,text:'',error:'ZIP 內檔案格式無法讀取。'});}
    }
    if(!sources.length)throw new Error('ZIP 找不到 JSON、TXT、Cookies 或 XLSX 資料檔。巢狀 ZIP 請先解壓一層。');
    return {sources,ignored,blankRows};
  }
  return Object.freeze({read});
});
