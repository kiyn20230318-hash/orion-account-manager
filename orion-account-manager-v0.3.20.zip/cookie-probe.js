(function(root) {
  'use strict';
  const SAME_SITE = new Set(['unspecified','no_restriction','lax','strict']);
  const own = (value,key) => Object.prototype.hasOwnProperty.call(value,key);
  const bool = (value,key) => !own(value,key) ? 'missing' : typeof value[key] === 'boolean' ? value[key] : 'invalid';
  const sameSite = value => {
    if (!own(value,'sameSite')) return 'missing';
    if (typeof value.sameSite !== 'string') return 'invalid';
    const normalized = value.sameSite.toLowerCase() === 'none' ? 'no_restriction' : value.sameSite.toLowerCase();
    return SAME_SITE.has(normalized) ? normalized : 'invalid';
  };
  const canonical = value => typeof value === 'string' ? value.replace(/^\./,'').toLowerCase() : '';
  const syntheticScope = (cookie,hostname) => canonical(cookie?.domain) === hostname;
  const nowDefault = () => Date.now();
  function fixtures(hostname,token,at) {
    const seed = {domain:hostname,path:'/',hostOnly:true,secure:true,httpOnly:true,sameSite:'lax',session:false,expirationDate:Math.floor(at/1000)+300};
    return [
      ['host_only','僅限目前主機',{}],
      ['domain','共用網域',{hostOnly:false}],
      ['secure_false','Secure 關閉（省略預設欄位）',{secure:false}],
      ['http_only_false','HttpOnly 關閉（省略預設欄位）',{httpOnly:false}],
      ['explicit_false','明確傳入兩個 false',{secure:false,httpOnly:false},true],
      ['strict','SameSite Strict',{sameSite:'strict'}],
      ['none','SameSite None',{sameSite:'no_restriction'}],
      ['default','未指定 SameSite',{sameSite:'unspecified'}],
      ['session','工作階段 Cookie',{session:true}],
      ['path','指定路徑',{path:'/probe/'}]
    ].map(([id,label,override,explicit]) => {
      const expected = {...seed,...override,name:'probe_'+token+'_'+id,value:'synthetic_'+token+'_'+id};
      if (expected.session) delete expected.expirationDate;
      const details = {url:(expected.secure?'https://':'http://')+hostname+expected.path,name:expected.name,value:expected.value,path:expected.path};
      if (expected.secure || explicit) details.secure=expected.secure;
      if (expected.httpOnly || explicit) details.httpOnly=expected.httpOnly;
      if (expected.sameSite !== 'unspecified') details.sameSite=expected.sameSite;
      if (!expected.hostOnly) details.domain='.'+hostname;
      if (!expected.session) details.expirationDate=expected.expirationDate;
      return {id,label,expected,details};
    });
  }
  function inspect(expected,actual,childVisible) {
    const checks=[];
    const add=(field,wanted,received,observed=false)=>checks.push({field,expected:wanted,actual:received,status:observed?'observed':wanted===received?'passed':'failed'});
    add('name','matches',actual.name===expected.name?'matches':'changed');
    add('value','matches',actual.value===expected.value?'matches':'changed');
    add('domain','matches',canonical(actual.domain)===expected.domain?'matches':'changed');
    add('path','matches',actual.path===expected.path?'matches':'changed');
    for (const field of ['hostOnly','secure','httpOnly','session']) add(field,expected[field],bool(actual,field));
    const readSame= sameSite(actual);
    add('sameSite',expected.sameSite,readSame,expected.sameSite==='unspecified'&&SAME_SITE.has(readSame)&&readSame!=='unspecified');
    const provided=['expirationDate','expires','expiry'].filter(field=>own(actual,field));
    let expiry='missing';
    if (provided.length) {
      const values=provided.map(field=>actual[field]);
      expiry=values.every(value=>typeof value==='number'&&Number.isFinite(value)) ? values.every(value=>Math.abs(value-expected.expirationDate)<=2)?'matches':'changed' : 'invalid';
    }
    add('expirationDate',expected.session?'missing':'matches',expiry);
    if (childVisible !== undefined) add('subdomainVisible',!expected.hostOnly,childVisible);
    return checks;
  }
  async function run({call,available=()=>true,now=nowDefault,randomId=()=>root.crypto.randomUUID()}) {
    const report={version:1,checkedAt:now(),cases:[],summary:{passed:0,failed:0,unsupported:0,cleanup:'not_needed'}};
    const finish=()=>{
      for (const status of ['passed','failed','unsupported']) report.summary[status]=report.cases.filter(item=>item.status===status).length;
      return report;
    };
    if (!['cookies.getAll','cookies.set','cookies.remove'].every(available)) {report.errorCode='api_unavailable';return finish();}
    let token;
    try {token=randomId().replace(/-/g,'').toLowerCase();if(!/^[a-f0-9]{32}$/.test(token))throw new Error();}
    catch (_) {report.errorCode='identity_unavailable';return finish();}
    const hostname=token+'.orion-cookie-check.invalid';
    const samples=fixtures(hostname,token,report.checkedAt);
    const knownNames=new Set(samples.map(item=>item.expected.name));
    let changed=false,uncertain=false,storeMismatch=false,storeId;
    const getAll=async details=>{
      const result=await call('cookies.getAll',details||{});
      if(!Array.isArray(result))throw new Error('invalid_read');
      return result;
    };
    const markError=error=>{if(error?.mutationUncertain)uncertain=true;return error?.apiTimeout?'api_timeout':'api_failed';};
    try {
      const initial=await getAll();
      // A random namespace plus a checked empty scope avoids touching existing data.
      if(initial.some(cookie=>syntheticScope(cookie,hostname)||knownNames.has(cookie?.name))){report.errorCode='scope_occupied';return finish();}
      const stores=[...new Set(initial.map(cookie=>cookie?.storeId).filter(value=>value!==undefined))];
      if(stores.length>1){report.errorCode='multiple_stores';return finish();}
      storeId=stores[0];
      for(const sample of samples) {
        if(uncertain)break;
        const entry={id:sample.id,label:sample.label,status:'unsupported',checks:[]};report.cases.push(entry);
        changed=true;
        try {
          const result=await call('cookies.set',{...sample.details,...(storeId!==undefined?{storeId}:{})});
          if(result&&typeof result==='object'&&result.storeId!==undefined) {
            if(storeId!==undefined&&result.storeId!==storeId){storeMismatch=true;entry.errorCode='store_mismatch';report.errorCode='store_mismatch';break;}
            storeId=result.storeId;
          }
        } catch(error) {entry.errorCode=markError(error);}
      }
      if(!uncertain) {
        const all=await getAll(storeId===undefined?{}:{storeId});
        let child;
        try {child=await getAll({url:'https://child.'+hostname+'/probe/',...(storeId!==undefined?{storeId}:{})});}catch(_){/* Core field checks remain useful when URL filtering is unsupported. */}
        for(const entry of report.cases) {
          const sample=samples.find(item=>item.id===entry.id);
          const matched=all.filter(cookie=>cookie?.name===sample.expected.name);
          if(matched.length!==1) {entry.status='failed';entry.errorCode=matched.length?'duplicate_readback':'missing_readback';continue;}
          entry.checks=inspect(sample.expected,matched[0],child?child.some(cookie=>cookie?.name===sample.expected.name):undefined);
          entry.status=entry.errorCode||entry.checks.some(check=>check.status==='failed')?'failed':entry.checks.some(check=>check.status==='observed')?'unsupported':'passed';
        }
      }
    } catch(error) {report.errorCode=markError(error);}
    finally {
      if(uncertain) report.summary.cleanup='uncertain';
      else if(changed) {
        report.summary.cleanup='failed';
        try {
          // Remove only cookies in the new, initially empty synthetic host.
          // Never broaden deletion to an unexpected domain returned by a broken API.
          let foreign=false;
          for(let pass=0;pass<2;pass++) {
            const all=await getAll(storeId===undefined?{}:{storeId});
            foreign=all.some(cookie=>knownNames.has(cookie?.name)&&!syntheticScope(cookie,hostname));
            const owned=all.filter(cookie=>syntheticScope(cookie,hostname));
            if(!owned.length){report.summary.cleanup=foreign?'failed':'cleared';break;}
            for(const cookie of owned) {
              if(typeof cookie.name!=='string'||typeof cookie.path!=='string'||!cookie.path.startsWith('/'))continue;
              let url;
              try {url=new URL('https://'+hostname+cookie.path);if(url.hostname!==hostname||url.pathname!==cookie.path||url.search||url.hash)continue;}catch(_){continue;}
              try {await call('cookies.remove',{url:url.href,name:cookie.name,...(storeId!==undefined?{storeId}:{})});}
              catch(error){markError(error);if(uncertain)break;}
            }
            if(uncertain)break;
          }
          if(!uncertain) {
            const remaining=await getAll(storeId===undefined?{}:{storeId});
            report.summary.cleanup=remaining.some(cookie=>syntheticScope(cookie,hostname)||knownNames.has(cookie?.name))?'failed':'cleared';
          }
        } catch(error){markError(error);}
        if(uncertain)report.summary.cleanup='uncertain';
      }
    }
    // An unexpected store may still contain the test cookie. Do not broaden
    // deletion into it, or mistake an empty original store for full cleanup.
    if(storeMismatch&&report.summary.cleanup==='cleared')report.summary.cleanup='failed';
    return finish();
  }
  const exported=Object.freeze({run});
  root.AccountCookieProbe=exported;
  if(typeof module!=='undefined'&&module.exports)module.exports=exported;
})(globalThis);
