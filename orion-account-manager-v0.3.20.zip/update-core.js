(function (root, factory) {
  'use strict';
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.AccountUpdate = api;
})(globalThis, function () {
  'use strict';
  const APP = 'orion-account-manager';
  const REPOSITORY_URL = 'https://github.com/kiyn20230318-hash/orion-account-manager';
  const RELEASE_URL = REPOSITORY_URL + '/releases/latest';
  const LATEST_URL = RELEASE_URL + '/download/latest.json';
  const MAX_BYTES = 64 * 1024;
  const TIMEOUT_MS = 10000;

  function object(value, keys, label) {
    if (!value || typeof value !== 'object' || Array.isArray(value) ||
        Object.keys(value).length !== keys.length || keys.some(key => !Object.prototype.hasOwnProperty.call(value, key))) {
      throw new Error('更新資料格式不正確：' + label + '。請改從版本頁查看。');
    }
  }

  function parseVersion(version) {
    if (typeof version !== 'string' || !/^(0|[1-9]\d{0,4})\.(0|[1-9]\d{0,4})\.(0|[1-9]\d{0,4})$/.test(version)) {
      throw new Error('版本號格式不正確。');
    }
    const parts = version.split('.').map(Number);
    if (parts.some(part => part > 65535)) throw new Error('版本號超出支援範圍。');
    return parts;
  }

  function compareVersions(left, right) {
    const a = parseVersion(left), b = parseVersion(right);
    for (let i = 0; i < 3; i++) {
      if (a[i] > b[i]) return 1;
      if (a[i] < b[i]) return -1;
    }
    return 0;
  }

  function validateDownload(download, kind, version) {
    object(download, ['url', 'sha256'], kind);
    if (typeof download.url !== 'string' || download.url.length > 2048 ||
        typeof download.sha256 !== 'string' || !/^[a-f\d]{64}$/i.test(download.sha256)) {
      throw new Error('下載連結或檔案校驗碼格式不正確。');
    }
    const expected = REPOSITORY_URL + '/releases/download/v' + version + '/' + APP + '-v' + version + '.' + kind;
    let parsed;
    try { parsed = new URL(download.url); } catch (_) { throw new Error('下載連結無效。'); }
    if (download.url !== expected || parsed.href !== expected || parsed.protocol !== 'https:' ||
        parsed.username || parsed.password || parsed.search || parsed.hash) {
      throw new Error('下載連結不屬於指定的官方版本頁。');
    }
    return { url: expected, sha256: download.sha256.toLowerCase() };
  }

  function validateMetadata(data) {
    object(data, ['app', 'version', 'publishedAt', 'notes', 'downloads'], '版本資訊');
    if (data.app !== APP) throw new Error('這份更新資料不屬於 Orion 帳號管理器。');
    parseVersion(data.version);
    if (typeof data.publishedAt !== 'string' || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z$/.test(data.publishedAt)) {
      throw new Error('更新日期格式不正確。');
    }
    const date = new Date(data.publishedAt);
    if (!Number.isFinite(date.getTime()) || date.toISOString().replace('.000Z', 'Z') !== data.publishedAt.replace('.000Z', 'Z')) {
      throw new Error('更新日期格式不正確。');
    }
    if (!Array.isArray(data.notes) || data.notes.length > 12 ||
        data.notes.some(note => typeof note !== 'string' || !note.trim() || note.length > 500 || /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(note))) {
      throw new Error('版本說明格式不正確。');
    }
    object(data.downloads, ['xpi', 'zip'], '下載項目');
    return {
      app: APP, version: data.version, publishedAt: data.publishedAt,
      notes: data.notes.map(note => note.trim()),
      downloads: {
        xpi: validateDownload(data.downloads.xpi, 'xpi', data.version),
        zip: validateDownload(data.downloads.zip, 'zip', data.version)
      }
    };
  }

  async function checkForUpdate(currentVersion, options = {}) {
    parseVersion(currentVersion);
    const fetcher = options.fetch || globalThis.fetch;
    if (typeof fetcher !== 'function' || typeof AbortController !== 'function' || typeof TextDecoder !== 'function') {
      throw new Error('此瀏覽器暫不支援線上檢查，請直接開啟版本頁。');
    }
    const timeout = Number.isFinite(options.timeoutMs) && options.timeoutMs > 0 ? Math.min(options.timeoutMs, 30000) : TIMEOUT_MS;
    const controller = new AbortController();
    let timer, reader;
    const tooLarge = () => new Error('更新資料超過 64 KB，已停止讀取。請改從版本頁查看。');
    const task = async () => {
      const response = await fetcher(LATEST_URL, {
        method: 'GET', credentials: 'omit', referrerPolicy: 'no-referrer',
        cache: 'no-store', signal: controller.signal
      });
      if (!response || !response.ok) throw new Error('目前無法取得更新資料。請稍後再試或開啟版本頁。');
      const contentLength = response.headers && response.headers.get('content-length');
      if (contentLength !== null && contentLength !== undefined && /^\d+$/.test(contentLength) && Number(contentLength) > MAX_BYTES) throw tooLarge();
      let text;
      if (response.body && typeof response.body.getReader === 'function') {
        reader = response.body.getReader();
        const chunks = [];
        let length = 0;
        while (true) {
          const part = await reader.read();
          if (part.done) break;
          if (!(part.value instanceof Uint8Array)) throw new Error('更新資料格式不正確。');
          length += part.value.byteLength;
          if (length > MAX_BYTES) throw tooLarge();
          chunks.push(part.value);
        }
        const bytes = new Uint8Array(length);
        let offset = 0;
        for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
        text = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
      } else if (typeof response.arrayBuffer === 'function') {
        const bytes = new Uint8Array(await response.arrayBuffer());
        if (bytes.byteLength > MAX_BYTES) throw tooLarge();
        text = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
      } else {
        // Older WebKit may expose text() without a readable stream.
        if (typeof response.text !== 'function') throw new Error('此瀏覽器無法讀取版本資料，請直接開啟版本頁。');
        text = await response.text();
        if (typeof text !== 'string' || new TextEncoder().encode(text).byteLength > MAX_BYTES) throw tooLarge();
      }
      let raw;
      try { raw = JSON.parse(text); }
      catch (_) { throw new Error('版本伺服器回傳的不是有效更新資料。請改從版本頁查看。'); }
      const metadata = validateMetadata(raw);
      const comparison = compareVersions(metadata.version, currentVersion);
      return { status: comparison > 0 ? 'available' : comparison === 0 ? 'current' : 'ahead', currentVersion, metadata };
    };
    try {
      return await Promise.race([
        task(),
        new Promise((_, reject) => {
          timer = setTimeout(() => {
            controller.abort();
            reject(new Error('檢查更新超過 10 秒，已停止等待。請稍後重試或開啟版本頁。'));
          }, timeout);
        })
      ]);
    } catch (error) {
      controller.abort();
      if (error && error.name === 'TypeError') throw new Error('連線失敗或更新資料無法讀取。請檢查網路，或開啟版本頁。');
      throw error;
    } finally {
      clearTimeout(timer);
      if (reader) { try { Promise.resolve(reader.cancel()).catch(() => {}); } catch (_) { /* Cancellation must not block the manager. */ } }
    }
  }

  return Object.freeze({ APP, REPOSITORY_URL, RELEASE_URL, LATEST_URL, MAX_BYTES, TIMEOUT_MS, parseVersion, compareVersions, validateMetadata, checkForUpdate });
});
