(function (root, factory) {
  'use strict';
  const core = typeof module === 'object' && module.exports ? require('./core.js') : root.AccountCore;
  const api = factory(core);
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.AccountBulk = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (C) {
  'use strict';

  const LIMITS = Object.freeze({ maxSources: 100, maxAccounts: 100, maxFileBytes: 4 * 1024 * 1024, maxTotalBytes: 12 * 1024 * 1024 });
  const OWN = (object, key) => Object.prototype.hasOwnProperty.call(object, key);
  const object = value => value && typeof value === 'object' && !Array.isArray(value);
  const wrapper = value => object(value) && (OWN(value, 'cookies') || OWN(value, 'cookie'));

  function nameKey(name) {
    return typeof name === 'string' ? name.normalize('NFC').trim().toLocaleLowerCase('en-US') : '';
  }

  // Count UTF-8 bytes without allocating a second copy of a potentially large export.
  function byteLength(text) {
    let bytes = 0;
    for (let i = 0; i < text.length; i++) {
      const code = text.charCodeAt(i);
      if (code < 0x80) bytes++;
      else if (code < 0x800) bytes += 2;
      else if (code >= 0xd800 && code <= 0xdbff && i + 1 < text.length && text.charCodeAt(i + 1) >= 0xdc00 && text.charCodeAt(i + 1) <= 0xdfff) { bytes += 4; i++; }
      else bytes += 3;
    }
    return bytes;
  }

  function baseRow(key, source, name, startUrl, rawText, importError, duplicatePolicy) {
    return { key, source, name, startUrl, rawText, duplicatePolicy: duplicatePolicy === undefined ? 'reject' : duplicatePolicy, importError: importError || null, domains: [], warnings: [], error: null, errorType: null, errorCode: null, conflicts: null, selected: true };
  }

  function rejected(message, source) {
    return validateRows([baseRow('batch-error', source || '批量匯入', '', '', '', message)]);
  }

  function countRows(rows) {
    return {
      total: rows.length,
      valid: rows.filter(row => !row.error).length,
      invalid: rows.filter(row => !!row.error).length,
      selected: rows.filter(row => !row.error && row.selected).length,
      warnings: rows.filter(row => row.warnings.length > 0).length
    };
  }

  function validateRows(input, options) {
    if (!Array.isArray(input)) return rejected('批量預覽資料格式無效，請重新選擇檔案。');
    if (input.length > LIMITS.maxAccounts) return rejected('每批最多可匯入 100 個帳號，請分批選擇檔案或拆分帳號清單。');
    const opts = options || {};
    const existing = new Set((Array.isArray(opts.existingNames) ? opts.existingNames : []).map(nameKey).filter(Boolean));
    const seen = new Set();
    const rows = input.map((inputRow, index) => {
      const source = object(inputRow) ? inputRow : baseRow('invalid-' + index, '第 ' + (index + 1) + ' 筆', '', '', '', '帳號預覽資料格式無效，請重新匯入。');
      const row = { ...source, duplicatePolicy: source.duplicatePolicy === undefined ? 'reject' : source.duplicatePolicy, domains: [], warnings: [], error: null, errorType: null, errorCode: null, conflicts: null, selected: source.selected !== false };
      delete row.cookies;
      const mark = (message, type) => { row.error = message; row.errorType = type; row.selected = false; };
      if (source.importError) { mark(source.importError, 'source'); return row; }
      const key = nameKey(source.name);
      const duplicate = existing.has(key) || seen.has(key);
      // Reserve every nonempty name in source order, even if its Cookie/URL needs repair.
      if (key) seen.add(key);
      if (typeof source.name !== 'string' || !key || source.name.trim().length > 100 || /[\u0000-\u001f\u007f]/.test(source.name)) {
        mark('請輸入 1–100 字的帳號名稱，且不可含控制字元。', 'name');
        return row;
      }
      row.name = source.name.normalize('NFC').trim();
      if (duplicate) {
        mark(existing.has(key) ? '此名稱與已儲存帳號重複；請重新命名後再勾選。' : '此名稱與本批前面的帳號重複；請重新命名後再勾選。', 'name');
        return row;
      }
      try { row.startUrl = C.validateUrl(source.startUrl); }
      catch (error) { mark(error.message, 'url'); return row; }
      try {
        if (typeof source.rawText !== 'string') throw new Error('原始 Cookie 資料遺失，請重新選擇檔案。');
        if (byteLength(source.rawText) > LIMITS.maxFileBytes) throw new Error('單一帳號資料超過 4 MiB，請縮小匯出資料後重試。');
        const parsed = C.parseImport(source.rawText, { fallbackUrl: row.startUrl, duplicatePolicy: row.duplicatePolicy });
        row.cookies = parsed.cookies;
        row.domains = C.profileDomains(parsed.cookies, row.startUrl);
        row.warnings = parsed.warnings;
        row.conflicts = parsed.conflicts;
      } catch (error) {
        mark(error.message, 'cookies');
        row.errorCode = typeof error.code === 'string' ? error.code : null;
        row.conflicts = error.code === 'CONFLICTING_DUPLICATE' ? error.conflicts : null;
      }
      return row;
    });
    return { rows, counts: countRows(rows) };
  }

  function decodedJson(text) {
    let value = text;
    for (let depth = 0; depth <= 6 && typeof value === 'string'; depth++) {
      const trimmed = value.replace(/^\uFEFF/, '').trim();
      if (!/^[\[{\"]/.test(trimmed)) break;
      try { value = JSON.parse(trimmed); } catch (_) { break; }
    }
    return value;
  }

  function parseSources(sources, options) {
    const opts = options || {};
    if (!Array.isArray(sources) || !sources.length) return rejected('請選擇至少一個 Cookie 檔案，或貼上帳號清單。');
    if (sources.length > LIMITS.maxSources) return rejected('每批最多可選擇 100 個檔案，請分批匯入。');
    let totalBytes = 0;
    const sizes = sources.map(source => {
      const size = object(source) && typeof source.text === 'string' ? byteLength(source.text) : 0;
      totalBytes += size;
      return size;
    });
    if (totalBytes > LIMITS.maxTotalBytes) return rejected('這批檔案合計超過 12 MiB，請減少檔案數量後分批匯入。');
    const rows = [];
    for (let sourceIndex = 0; sourceIndex < sources.length; sourceIndex++) {
      const source = sources[sourceIndex];
      const sourceName = object(source) && typeof source.name === 'string' && source.name.trim() ? source.name.slice(0, 240) : '檔案 ' + (sourceIndex + 1);
      const fileName = sourceName.split(/[\\/]/).pop();
      const defaultName = fileName.replace(/\.[^.]+$/, '') || fileName;
      const fallbackUrl = typeof opts.defaultUrl === 'string' ? opts.defaultUrl : '';
      const addError = message => rows.push(baseRow(sourceIndex + ':0', sourceName, defaultName, fallbackUrl, '', message));
      if (!object(source) || typeof source.text !== 'string') { addError('檔案讀取失敗，請重新選擇文字格式的 Cookie 檔案。'); continue; }
      if (source.error) {
        addError(source.error === '檔案超過 4 MB，請拆成較小的檔案。' ? '此檔案超過 4 MiB，請縮小匯出資料或拆分帳號清單後重試。' : '檔案讀取失敗，請重新選擇文字格式的 Cookie 檔案。');
        continue;
      }
      if (sizes[sourceIndex] > LIMITS.maxFileBytes) { addError('此檔案超過 4 MiB，請縮小匯出資料或拆分帳號清單後重試。'); continue; }
      const decoded = decodedJson(source.text);
      let entries = null;
      let bundleUrl = fallbackUrl;
      if (object(decoded) && OWN(decoded, 'accounts')) {
        if (!Array.isArray(decoded.accounts) || !decoded.accounts.length || wrapper(decoded)) {
          addError('帳號清單須包含非空的 accounts 陣列，且不可同時含有 cookies 或 cookie 欄位。');
          continue;
        }
        entries = decoded.accounts;
        if (OWN(decoded, 'startUrl')) bundleUrl = typeof decoded.startUrl === 'string' ? decoded.startUrl : '';
      } else if (Array.isArray(decoded) && decoded.length && decoded.every(wrapper)) entries = decoded;
      if (entries) {
        if (rows.length + entries.length > LIMITS.maxAccounts) return rejected('每批最多可匯入 100 個帳號，請拆分帳號清單或減少選擇的檔案。', sourceName);
        entries.forEach((entry, entryIndex) => {
          const label = sourceName + ' · 第 ' + (entryIndex + 1) + ' 個帳號';
          const name = object(entry) && OWN(entry, 'name') ? (typeof entry.name === 'string' ? entry.name : '') : defaultName + ' ' + (entryIndex + 1);
          const startUrl = object(entry) && OWN(entry, 'startUrl') ? (typeof entry.startUrl === 'string' ? entry.startUrl : '') : bundleUrl;
          const rawText = wrapper(entry) ? JSON.stringify(entry) : '';
          const error = wrapper(entry) ? null : '此帳號須是含有 cookies 或 cookie 欄位的物件，請修正原始清單後重新匯入。';
          rows.push(baseRow(sourceIndex + ':' + entryIndex, label, name, startUrl, rawText, error, source.duplicatePolicy));
        });
      } else {
        const metadata = wrapper(decoded) ? decoded : null;
        const name = metadata && OWN(metadata, 'name') ? (typeof metadata.name === 'string' ? metadata.name : '') : defaultName;
        const startUrl = metadata && OWN(metadata, 'startUrl') ? (typeof metadata.startUrl === 'string' ? metadata.startUrl : '') : fallbackUrl;
        rows.push(baseRow(sourceIndex + ':0', sourceName, name, startUrl, source.text, null, source.duplicatePolicy));
      }
      if (rows.length > LIMITS.maxAccounts) return rejected('每批最多可匯入 100 個帳號，請分批選擇檔案或拆分帳號清單。', sourceName);
    }
    return validateRows(rows, opts);
  }

  return Object.freeze({ LIMITS, nameKey, parseSources, validateRows });
});
