(() => {
  'use strict';
  const button = document.getElementById('open-manager');
  const error = document.getElementById('popup-error');
  button.addEventListener('click', async () => {
    button.disabled = true;
    error.hidden = true;
    let timer;
    try {
      const runtime = (globalThis.browser || globalThis.chrome || {}).runtime;
      if (!runtime || typeof runtime.getURL !== 'function' || !globalThis.AccountAPI) throw new Error('擴充套件功能尚未就緒，請確認 Orion 已啟用此套件。');
      await Promise.race([
        globalThis.AccountAPI.call('tabs.create', { url:runtime.getURL('manager.html') }),
        new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('開啟管理器的回覆逾時，請先查看是否已新增管理分頁。若沒有，請完全關閉 Orion 再開啟後重試。')), 15000); })
      ]);
      window.close();
    } catch (failure) {
      error.textContent = String(failure && failure.message ? failure.message : '無法開啟管理器，請稍後再試。').slice(0, 300);
      error.hidden = false;
    } finally { clearTimeout(timer); button.disabled = false; }
  });
})();
