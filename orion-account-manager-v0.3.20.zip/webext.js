(function (root) {
  'use strict';
  const native = root.browser || root.chrome;
  const promiseAPI = Boolean(root.browser);
  function resolve(path) {
    const parts = path.split('.');
    let owner = native;
    for (const part of parts.slice(0, -1)) owner = owner && owner[part];
    return { owner, fn: owner && owner[parts[parts.length - 1]] };
  }
  function available(path) { return typeof resolve(path).fn === 'function'; }
  function call(path, ...args) {
    const { owner, fn } = resolve(path);
    if (typeof fn !== 'function') return Promise.reject(new Error('此瀏覽器未提供必要功能：' + path));
    if (promiseAPI) {
      try { return Promise.resolve(fn.apply(owner, args)); }
      catch (error) { return Promise.reject(error); }
    }
    return new Promise((resolvePromise, reject) => {
      try {
        fn.apply(owner, [...args, result => {
          const error = native.runtime && native.runtime.lastError;
          if (error) reject(new Error(error.message || '瀏覽器操作失敗'));
          else resolvePromise(result);
        }]);
      } catch (error) { reject(error); }
    });
  }
  root.AccountAPI = { call, available, native, getURL: path => native.runtime.getURL(path) };
})(globalThis);
