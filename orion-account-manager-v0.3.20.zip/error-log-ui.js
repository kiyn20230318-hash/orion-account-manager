(() => {
  'use strict';
  const $=id=>document.getElementById(id),button=$('error-log-download'),status=$('error-log-status'),text=$('error-log-text'),link=$('error-log-link');
  let objectUrl=null;
  button.addEventListener('click',async()=>{
    button.disabled=true;status.textContent='正在整理本機紀錄…';
    link.hidden=true;$('error-log-preview').hidden=true;$('error-log-copy').disabled=true;text.value='';
    if(objectUrl){URL.revokeObjectURL(objectUrl);objectUrl=null;}
    let timer;
    try{
      const response=await Promise.race([AccountAPI.call('runtime.sendMessage',{type:'errorLog'}),new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error()),15000);})]);
      if(!response?.ok||response.data?.format!=='orion-switch-error-log')throw new Error();
      // Defense in depth: rebuild the response, even if a native bridge returns extra fields.
      const data=response.data;
      const report=AccountErrorLog.report({version:data.extensionVersion,at:data.generatedAt,entries:(Array.isArray(data.attempts)?data.attempts:[]).map(a=>({profileKey:a.account,report:a})),...data.operation,storageReadable:data.storageReadable});
      text.value=JSON.stringify(report,null,2);
      objectUrl=URL.createObjectURL(new Blob([text.value],{type:'text/plain;charset=utf-8'}));
      link.href=objectUrl;link.download='orion-error-log-'+new Date().toISOString().replace(/[:.]/g,'-')+'.txt';link.hidden=false;
      $('error-log-preview').hidden=false;$('error-log-copy').disabled=false;
      status.textContent=(report.storageReadable?'已整理 '+report.attempts.length+' 次切換紀錄。':'本機儲存未回覆，目前只取得背景暫存紀錄。')+' 已提出下載；若未出現檔案，請按「再次下載」或複製紀錄回傳。';
      link.click();
    }catch(_){status.textContent='無法取得背景紀錄，未產生檔案。請保留目前畫面，稍後再試。';}
    finally{clearTimeout(timer);button.disabled=false;}
  });
  $('error-log-copy').addEventListener('click',async()=>{
    try{await navigator.clipboard.writeText(text.value);status.textContent='已複製錯誤紀錄，可以貼上回傳。';}
    catch(_){$('error-log-preview').open=true;text.focus();text.select();status.textContent='已選取紀錄，請使用手機的「複製」功能。';}
  });
  addEventListener('pagehide',()=>{if(objectUrl)URL.revokeObjectURL(objectUrl);});
})();
