(function(root){
  'use strict';
  const MAX_XML=24*1024*1024, MAX_ROWS=100;
  const fail=message=>{throw new Error(message);};
  function read(bytes){
    if(!root.fflate||!root.DOMParser)fail('Excel 讀取功能尚未載入，請重新開啟管理器。');
    let total=0, files;
    try{files=root.fflate.unzipSync(new Uint8Array(bytes),{filter:file=>{
      if(!/^xl\/(sharedStrings\.xml|worksheets\/sheet[^/]+\.xml)$/.test(file.name))return false;
      total+=file.originalSize;
      if(!Number.isSafeInteger(file.originalSize)||total>MAX_XML)fail('Excel 解壓後資料過大，請分批匯出。');
      return true;
    }});}catch(_){fail('無法讀取 Excel，請使用未加密的 .xlsx 檔案，或縮小匯出範圍。');}
    function xml(data){
      if(data.length>MAX_XML)fail('Excel 資料過大。');
      const text=new TextDecoder('utf-8',{fatal:true}).decode(data);
      if(/<!DOCTYPE|<!ENTITY/i.test(text))fail('不支援此 Excel XML 格式。');
      const doc=new DOMParser().parseFromString(text,'application/xml');
      if(doc.getElementsByTagName('parsererror').length)fail('Excel 欄位格式損壞，請重新匯出。');
      return doc;
    }
    const elements=(node,name)=>Array.from(node.getElementsByTagNameNS('*',name));
    const strings=files['xl/sharedStrings.xml']?elements(xml(files['xl/sharedStrings.xml']),'si').map(si=>elements(si,'t').map(t=>t.textContent).join('')):[];
    function value(cell){
      // Never evaluate formulas or follow workbook links.
      if(elements(cell,'f').length)fail('名稱與 Cookie 欄須為匯出的原始文字，不支援公式。');
      const type=cell.getAttribute('t'), raw=elements(cell,'v')[0]?.textContent||'';
      if(type==='s'){
        if(!/^\d+$/.test(raw)||Number(raw)>=strings.length)fail('Excel 文字索引損壞。');
        return strings[Number(raw)];
      }
      if(type==='inlineStr')return elements(cell,'t').map(t=>t.textContent).join('');
      return raw;
    }
    function column(cell){return (cell.getAttribute('r')||'').replace(/\d+$/,'').toUpperCase();}
    const accounts=[];let blankRows=0, sheets=0;
    for(const [name,data] of Object.entries(files)){
      if(!name.startsWith('xl/worksheets/'))continue;
      const rows=elements(xml(data),'row');let cookieColumn=null, header=-1;
      for(let i=0;i<Math.min(rows.length,10);i++){
        const candidates=elements(rows[i],'c').filter(c=>!elements(c,'f').length&&/^cookies?$/i.test(value(c).trim()));
        if(candidates.length>1)fail('Excel 有多個 Cookie 欄，請保留一個後再匯入。');
        if(candidates.length){cookieColumn=column(candidates[0]);header=i;break;}
      }
      if(!cookieColumn)continue;
      if(cookieColumn==='A')fail('第一欄須為帳號名稱，Cookie 請放在獨立欄位。');
      sheets++;
      for(const row of rows.slice(header+1)){
        const cells=elements(row,'c');
        const nameCell=cells.find(c=>column(c)==='A'), cookieCell=cells.find(c=>column(c)===cookieColumn);
        const cookies=cookieCell?value(cookieCell):'';
        if(!cookies.trim()){blankRows++;continue;}
        const accountName=nameCell?value(nameCell):'';
        accounts.push({name:accountName,cookies});
        if(accounts.length>MAX_ROWS)fail('每批最多 100 個帳號，請分批匯出。');
      }
    }
    if(!sheets)fail('Excel 找不到 Cookie 欄。請保留第一欄名稱及標題為 Cookie 的欄位。');
    if(!accounts.length)fail('Excel 的 Cookie 欄都是空白，沒有可匯入的帳號。');
    const text=JSON.stringify({accounts});
    if(new TextEncoder().encode(text).length>4*1024*1024)fail('Excel 帳號資料超過 4 MB，請分批匯入。');
    return {text,count:accounts.length,blankRows,sheets};
  }
  root.AccountWorkbook=Object.freeze({read});
})(globalThis);
