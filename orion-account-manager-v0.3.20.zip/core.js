(function (root, factory) {
  'use strict';
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.AccountCore = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const MAX_EXPIRY = 253402300799; // End of year 9999, in seconds.
  const COOKIE_NAME = /^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/;
  const OWN = (object, key) => Object.prototype.hasOwnProperty.call(object, key);

  function fail(message, code) {
    const error = new Error(message);
    if (code) error.code = code;
    throw error;
  }

  function validateUrl(input) {
    if (typeof input !== 'string' || !input.trim()) fail('請輸入完整的 http:// 或 https:// 網址。');
    const value = input.trim();
    if (/[\u0000-\u0020\u007f\\]/.test(value)) fail('網址含有不允許的空白、控制字元或反斜線。');
    if (!/^https?:\/\//i.test(value)) fail('網址僅支援 http:// 與 https://。');
    let url;
    try { url = new URL(value); } catch (_) { fail('網址格式無效。'); }
    if (url.protocol !== 'https:' && url.protocol !== 'http:') fail('網址僅支援 http:// 與 https://。');
    const authority = value.slice(value.indexOf('://') + 3).split(/[/?#]/)[0];
    if (!url.hostname || url.username || url.password || authority.includes('@')) fail('網址不得包含帳號或密碼。');
    canonicalDomain(url.hostname);
    return url.href;
  }

  function canonicalDomain(input) {
    if (typeof input !== 'string' || !input) fail('Cookie 缺少有效的網域。');
    let host = input;
    if (host[0] === '.') host = host.slice(1);
    if (!host || host[0] === '.' || /[\s/@?#%\\\u0000-\u001f\u007f]/.test(host)) fail('Cookie 網域格式無效。');
    if (host.endsWith('.')) fail('Cookie 網域不可使用結尾句點。');
    const isIPv6 = host.startsWith('[') && host.endsWith(']');
    if (!isIPv6 && /[:\[\]]/.test(host)) fail('Cookie 網域不可包含通訊埠。');
    let url;
    try { url = new URL('http://' + host + '/'); } catch (_) { fail('Cookie 網域格式無效。'); }
    const normalized = url.hostname.toLowerCase();
    if (!normalized || url.port || url.username || url.password || url.pathname !== '/') fail('Cookie 網域格式無效。');
    if (!isIPv6) {
      if (normalized.length > 253 || normalized.split('.').some(part => !part || part.length > 63 || !/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test(part))) {
        fail('Cookie 網域格式無效。');
      }
      // URL parsers rewrite shorthand/hex/octal IP addresses; imports must name the exact host.
      if (/^\d+\.\d+\.\d+\.\d+$/.test(normalized) && normalized !== host.toLowerCase()) fail('Cookie 的 IP 網域須使用完整的十進位位址。');
    }
    return normalized;
  }

  function domainMatches(host, domain) {
    const normalizedHost = canonicalDomain(host);
    const normalizedDomain = canonicalDomain(domain);
    return normalizedHost === normalizedDomain || normalizedHost.endsWith('.' + normalizedDomain);
  }

  function booleanAttribute(raw, key, fallback) {
    if (!OWN(raw, key) || raw[key] === undefined) return fallback;
    if (typeof raw[key] !== 'boolean') fail('Cookie 的 ' + key + ' 必須是 true 或 false。');
    return raw[key];
  }

  function expirationValue(value, warnings, field) {
    if (value === null || value === undefined) return undefined;
    let expiry = value;
    if (typeof expiry === 'string') {
      if (/^-?\d+(?:\.\d+)?$/.test(expiry)) {
        expiry = Number(expiry);
        warnings.push('已將 ' + field + ' 的數字字串轉成時間戳記。');
      } else if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.test(expiry)) {
        const parts = expiry.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})/).slice(1).map(Number);
        const [year, month, day, hour, minute, second] = parts;
        const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
        const monthDays = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        if (month < 1 || month > 12 || day < 1 || day > monthDays[month - 1] || hour > 23 || minute > 59 || second > 59) fail('Cookie 的 ISO 日期不是有效的日期或時間。');
        expiry = Date.parse(expiry) / 1000;
        warnings.push('已將 ' + field + ' 的 ISO 日期轉成秒數。');
      } else {
        fail('Cookie 的 ' + field + ' 必須是時間戳記或含時區的 ISO 日期。');
      }
    }
    if (typeof expiry !== 'number' || !Number.isFinite(expiry)) fail('Cookie 的有效期限無效。');
    if (expiry === -1) return undefined;
    if (expiry < 0) fail('Cookie 的有效期限不可為負數（工作階段值 -1 除外）。');
    if (expiry >= 1e12) {
      expiry /= 1000;
      warnings.push('已將 ' + field + ' 的毫秒時間戳記轉成秒數。');
    }
    if (expiry > MAX_EXPIRY) fail('Cookie 的有效期限超出支援範圍。');
    return expiry;
  }

  function portablePath(input, domain) {
    const path = input === undefined ? '/' : input;
    if (typeof path !== 'string' || !path.startsWith('/') || /[;\u0000-\u001f\u007f]/.test(path)) fail('Cookie 路徑必須以 / 開頭，且不可含分號或控制字元。');
    const url = new URL('https://' + domain + path);
    if (url.pathname !== path || url.search || url.hash) fail('此 Cookie 路徑無法透過瀏覽器網址完整清除；不可含未編碼的特殊字元或相對路徑片段。', 'UNSUPPORTED_COOKIE_PATH');
    return path;
  }

  function normalizeInternal(raw, options) {
    const opts = options || {};
    const warnings = [];
    let adjusted = false;
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) fail('每筆 Cookie 必須是物件。');
    if ((OWN(raw, 'partitionKey') && raw.partitionKey != null) || raw.partitioned === true || (OWN(raw, 'firstPartyDomain') && raw.firstPartyDomain != null && raw.firstPartyDomain !== '')) {
      fail('此 Cookie 使用分割儲存或第一方隔離，無法安全移植到 Orion。', 'UNSUPPORTED_PARTITION');
    }
    if (OWN(raw, 'partitioned') && raw.partitioned != null && typeof raw.partitioned !== 'boolean') fail('Cookie 的 partitioned 必須是 true 或 false。');
    // WebExtensions cookies.set supports an explicit empty name. Keep that
    // identity intact so native cookies can be backed up and removed correctly.
    if (typeof raw.name !== 'string' || (raw.name !== '' && !COOKIE_NAME.test(raw.name))) fail('Cookie 名稱必須是文字，且不可含不允許的字元。');
    if (typeof raw.value !== 'string' || /[;\u0000-\u001f\u007f]/.test(raw.value)) fail('Cookie 值必須是文字，且不可含分號或控制字元。');

    let inputDomain = raw.domain;
    if (inputDomain == null || inputDomain === '') {
      const sourceUrl = raw.url || opts.fallbackUrl;
      if (!sourceUrl) fail('Cookie 缺少網域；請提供匯入網址。');
      inputDomain = new URL(validateUrl(sourceUrl)).hostname;
      warnings.push('缺少網域的 Cookie 已使用所提供網址的主機名稱。');
    }
    const domain = canonicalDomain(inputDomain);
    const hostOnly = booleanAttribute(raw, 'hostOnly', !inputDomain.startsWith('.'));
    const path = portablePath(raw.path, domain);
    const secure = booleanAttribute(raw, 'secure', false);
    const httpOnly = booleanAttribute(raw, 'httpOnly', false);
    const explicitSession = booleanAttribute(raw, 'session', undefined);
    let sameSite = raw.sameSite == null ? 'unspecified' : raw.sameSite;
    if (typeof sameSite !== 'string') fail('Cookie 的 sameSite 格式無效。');
    sameSite = sameSite.toLowerCase();
    if (sameSite === 'none') sameSite = 'no_restriction';
    if (!['unspecified', 'no_restriction', 'lax', 'strict'].includes(sameSite)) fail('Cookie 的 sameSite 僅支援 unspecified、None、Lax 或 Strict。');
    if (sameSite === 'no_restriction' && !secure && opts.nativeAttributeReadback !== true) fail('SameSite=None 的 Cookie 必須原本就有 Secure 屬性；請重新匯出正確資料。');

    let expirationDate;
    let sawExpiry = false;
    for (const field of ['expirationDate', 'expires', 'expiry']) {
      if (!OWN(raw, field) || raw[field] == null) continue;
      let candidate = expirationValue(raw[field], warnings, field);
      // Some exports put numeric zero beside an explicit session flag. This is an
      // import-only placeholder rule; an ISO epoch date remains an expired date.
      const numericZero = raw[field] === 0 || (typeof raw[field] === 'string' && /^-?\d+(?:\.\d+)?$/.test(raw[field]) && Number(raw[field]) === 0);
      if (opts.importCompatibility && explicitSession === true && numericZero) {
        candidate = undefined;
        adjusted = true;
        warnings.push('相容處理：session=true 且 ' + field + '=0，已視為工作階段 Cookie，不設定到期日。');
      }
      if (sawExpiry && expirationDate !== candidate) fail('Cookie 含有互相矛盾的有效期限。');
      expirationDate = candidate;
      sawExpiry = true;
    }
    const session = expirationDate === undefined;
    if (explicitSession !== undefined && explicitSession !== session) {
      if (!opts.importCompatibility) fail('Cookie 的 session 屬性與有效期限互相矛盾。', 'SESSION_EXPIRY_CONFLICT');
      adjusted = true;
      warnings.push(session
        ? '相容處理：session=false 但沒有有效到期日，已改為工作階段 Cookie；未自行新增期限。'
        : '相容處理：session=true 但有明確到期日，已保留原期限並校正 session=false；未延長期限。');
    }
    if (raw.name.startsWith('__Secure-') && !secure) fail('__Secure- Cookie 必須具有 Secure 屬性。');
    if (raw.name.startsWith('__Host-') && (!secure || !hostOnly || path !== '/')) fail('__Host- Cookie 必須具有 Secure、僅限主機，且路徑為 /。');
    const now = opts.now === undefined ? Date.now() : opts.now;
    if (typeof now !== 'number' || !Number.isFinite(now) || now < 0) fail('目前時間必須是有效的毫秒時間戳記。');
    if (!session && expirationDate <= now / 1000 && !opts.allowExpired) fail('Cookie 已過期。', 'COOKIE_EXPIRED');

    const cookie = { name: raw.name, value: raw.value, domain, path, hostOnly, secure, httpOnly, sameSite, session };
    if (!session) cookie.expirationDate = expirationDate;
    return { cookie, warnings, adjusted };
  }

  function normalizeCookie(raw, options) {
    // Importer or native-only options cannot weaken ordinary normalization.
    return normalizeInternal(raw, {...options, importCompatibility:false,nativeAttributeReadback:false}).cookie;
  }

  function normalizeNativeCookie(raw, options) {
    // Preserve the observed flags in explicitly limited native readback. This
    // exception does not affect type, identity, partition or lifetime checks.
    return normalizeInternal(raw, {...options,importCompatibility:false,nativeAttributeReadback:true}).cookie;
  }

  function cookieKey(cookie) {
    return JSON.stringify([canonicalDomain(cookie.domain), !!cookie.hostOnly, cookie.path || '/', cookie.name]);
  }

  function cookieUrl(cookie) {
    const domain = canonicalDomain(cookie.domain);
    const path = portablePath(cookie.path, domain);
    return (cookie.secure ? 'https://' : 'http://') + domain + path;
  }

  function toSetDetails(cookie) {
    const normalized = normalizeCookie(cookie, { allowExpired: true });
    const details = { url: cookieUrl(normalized), name: normalized.name, value: normalized.value, path: normalized.path };
    // These API defaults preserve false/unspecified without relying on a bridge
    // accepting the optional field or treating its mere presence as true.
    if (normalized.secure) details.secure = true;
    if (normalized.httpOnly) details.httpOnly = true;
    if (normalized.sameSite !== 'unspecified') details.sameSite = normalized.sameSite;
    // Foundation/WebKit distinguishes a domain cookie by its leading dot.
    // Preserve the normalized scope across engines; IP literals cannot use it.
    if (!normalized.hostOnly) details.domain = normalized.domain.startsWith('[') || /^\d+\.\d+\.\d+\.\d+$/.test(normalized.domain)
      ? normalized.domain : '.' + normalized.domain;
    if (!normalized.session) details.expirationDate = normalized.expirationDate;
    return details;
  }

  function parseNetscape(text) {
    const rows = [];
    const lines = text.replace(/^\uFEFF/, '').split(/\r?\n/);
    for (let i = 0; i < lines.length; i++) {
      let line = lines[i];
      if (!line.trim()) continue;
      const httpOnly = line.startsWith('#HttpOnly_');
      if (httpOnly) line = line.slice('#HttpOnly_'.length);
      else if (line.startsWith('#')) continue;
      const fields = line.split('\t');
      if (fields.length !== 7) fail('Netscape Cookie 第 ' + (i + 1) + ' 行須有 7 個以 Tab 分隔的欄位。');
      const [domain, subdomains, path, secure, expires, name, value] = fields;
      if (!/^(TRUE|FALSE)$/i.test(subdomains) || !/^(TRUE|FALSE)$/i.test(secure)) fail('Netscape Cookie 第 ' + (i + 1) + ' 行的旗標無效。');
      if (!/^\d+$/.test(expires)) fail('Netscape Cookie 第 ' + (i + 1) + ' 行的期限無效。');
      const row = { name, value, domain, path, hostOnly: subdomains.toUpperCase() === 'FALSE', secure: secure.toUpperCase() === 'TRUE', httpOnly };
      if (Number(expires) === 0) row.session = true;
      else row.expirationDate = Number(expires);
      rows.push(row);
    }
    return rows;
  }

  function unwrapImport(input, depth) {
    if (depth > 6) fail('Cookie 資料的編碼層數過多。');
    if (Array.isArray(input)) return input;
    if (typeof input === 'string') {
      const source = input.replace(/^\uFEFF/, '');
      const text = source.trim();
      if (!text) fail('請先貼上 Cookie 資料或選擇檔案。');
      if (/^[\[{\"]/.test(text)) {
        let decoded;
        try { decoded = JSON.parse(text); } catch (_) { fail('Cookie JSON 格式無效，請確認已完整複製或匯出。'); }
        return unwrapImport(decoded, depth + 1);
      }
      if (text.includes('\t') || /^#(?: Netscape HTTP Cookie File|HttpOnly_)/m.test(text)) return parseNetscape(source);
      fail('無法辨識 Cookie 格式；請使用 JSON 陣列或 Netscape Cookie 檔案。');
    }
    if (input && typeof input === 'object') {
      const wrappers = ['cookies', 'cookie'].filter(key => OWN(input, key));
      if (wrappers.length !== 1) fail('Cookie 物件須包含唯一的 cookies 或 cookie 欄位。');
      return unwrapImport(input[wrappers[0]], depth + 1);
    }
    fail('無法辨識 Cookie 格式；請使用 JSON 陣列或 Netscape Cookie 檔案。');
  }

  function parseImport(text, options) {
    if (typeof text !== 'string') fail('請以文字匯入 Cookie 資料。');
    const opts = {...options, importCompatibility:options?.importCompatibility !== false,nativeAttributeReadback:false};
    const duplicatePolicy = opts.duplicatePolicy === undefined ? 'reject' : opts.duplicatePolicy;
    if (!['reject', 'first', 'last'].includes(duplicatePolicy)) fail('請選擇重複 Cookie 的處理方式。', 'INVALID_DUPLICATE_POLICY');
    if (opts.fallbackUrl) validateUrl(opts.fallbackUrl);
    const rows = unwrapImport(text, 0);
    if (!rows.length) fail('匯入資料沒有 Cookie。');
    const seen = new Map();
    const warningSet = new Set();
    let expired = 0;
    let duplicate = 0;
    let adjusted = 0;
    let firstConflictIndex = null;
    rows.forEach((row, index) => {
      let result;
      try { result = normalizeInternal(row, opts); } catch (error) {
        if (error.code === 'COOKIE_EXPIRED') { expired++; return; }
        error.message = '第 ' + (index + 1) + ' 筆 Cookie：' + error.message;
        throw error;
      }
      if (result.adjusted) adjusted++;
      result.warnings.forEach(message => warningSet.add(message.startsWith('相容處理：') ? '第 ' + (index + 1) + ' 筆 Cookie：' + message : message));
      const key = cookieKey(result.cookie);
      const signature = JSON.stringify(result.cookie);
      let group = seen.get(key);
      if (!group) {
        group = { first: result.cookie, last: result.cookie, indices: [], signatures: new Set() };
        seen.set(key, group);
      }
      if (group.signatures.has(signature)) duplicate++;
      else if (group.signatures.size && firstConflictIndex === null) firstConflictIndex = index + 1;
      group.signatures.add(signature);
      group.indices.push(index + 1);
      group.last = result.cookie;
    });
    // Only normalized, live records participate. Export-only metadata never makes
    // a conflict; malformed/partitioned records still fail before any resolution.
    // No cookie names, domains or values are exposed in diagnostic metadata.
    const conflictGroups = Array.from(seen.values()).filter(group => group.signatures.size > 1);
    const conflicts = conflictGroups.length ? {
      groupCount: conflictGroups.length,
      recordCount: conflictGroups.reduce((count, group) => count + group.indices.length, 0),
      groups: conflictGroups.map(group => ({ indices: group.indices.slice(), variantCount: group.signatures.size }))
    } : null;
    if (conflicts && duplicatePolicy === 'reject') {
      const error = new Error('此帳號資料內第 ' + firstConflictIndex + ' 個 Cookie 與較前面的同名、同網域及同路徑 Cookie 內容不同。一個帳號可包含多個 Cookie；共 ' + conflicts.groupCount + ' 組衝突（' + conflicts.recordCount + ' 個 Cookie）。請在預覽選擇保留檔案中第一筆或最後一筆，無須手動尋找；檔案順序不代表資料新舊。');
      error.code = 'CONFLICTING_DUPLICATE';
      error.conflicts = conflicts;
      throw error;
    }
    const cookies = Array.from(seen.values(), group => duplicatePolicy === 'last' ? group.last : group.first);
    if (!cookies.length) fail('全部 ' + expired + ' 筆 Cookie 都已過期，請重新匯出登入資料。', 'ALL_COOKIES_EXPIRED');
    if (expired) warningSet.add('已略過 ' + expired + ' 筆過期 Cookie。');
    if (duplicate) warningSet.add('已合併 ' + duplicate + ' 筆完全相同的 Cookie。');
    if (conflicts) warningSet.add('依你的選擇，' + conflicts.groupCount + ' 組衝突 Cookie 各保留檔案中' + (duplicatePolicy === 'first' ? '第一筆' : '最後一筆') + '未過期資料；檔案順序不代表資料新舊。僅處理此份帳號資料，請確認來源未混入其他帳號。');
    return { cookies, domains: profileDomains(cookies), warnings: Array.from(warningSet), conflicts,
      stats:{total:rows.length,imported:cookies.length,expired,duplicate,adjusted} };
  }

  function profileDomains(cookies, startUrl) {
    const domains = new Set(cookies.map(cookie => canonicalDomain(cookie.domain)));
    if (startUrl) domains.add(new URL(validateUrl(startUrl)).hostname.toLowerCase());
    return Array.from(domains).sort();
  }

  return Object.freeze({ parseImport, normalizeCookie, normalizeNativeCookie, cookieKey, cookieUrl, toSetDetails, domainMatches, validateUrl, profileDomains });
});
