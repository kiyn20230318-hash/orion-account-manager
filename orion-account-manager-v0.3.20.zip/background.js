(function () {
  'use strict';
  const engine = AccountEngine.create(AccountAPI);
  const base = AccountAPI.getURL(''), bridge = AccountAPI.getURL('quick-switch.html'), busyTabs = new Set();
  function webUrl(url) { try { const u=new URL(url);return /^https?:$/.test(u.protocol)?u:null; } catch (_) {return null;} }
  function publicState(state) {return {profiles:state.profiles.map(p=>({id:p.id,name:p.name})),activeId:state.activeId,busy:state.operation?.busy===true,stalled:state.operation?.stalled===true};}
  async function quick(message,sender) {
    if(sender.frameId!==0 || !Number.isInteger(sender.tab?.id) || sender.tab.incognito!==false) throw new Error();
    const ownBridge=sender.url?.split('#')[0]===bridge, site=webUrl(sender.url);
    if(!ownBridge&&!site)throw new Error();
    const state=await engine.handle({type:'state'});
    const supported=ownBridge||state.profiles.some(p=>webUrl(p.startUrl)?.hostname===site.hostname);
    if(message.type==='quickState')return supported?{...publicState(state),enabled:true}:{enabled:false};
    if(!supported||!state.profiles.some(p=>p.id===message.id))throw new Error();
    if(message.type==='quickApply'&&ownBridge) {
      const result=await engine.handle({type:'switch',id:message.id,allowNativeAttributeMismatch:true,allowMissingNativeExpiry:true,replacePending:true},{tab:sender.tab,reuseDestinationTab:true});
      return {completed:true,message:result.lastAttempt?.status==='failed'?'帳號已套用，但網址未能開啟，請回帳號管理器重試。':'已套用並開啟。'};
    }
    if(message.type!=='quickStart'||ownBridge||state.operation?.busy||state.operation?.stalled||busyTabs.has(sender.tab.id))throw new Error();
    busyTabs.add(sender.tab.id);
    try {
      const live=await AccountAPI.call('tabs.get',sender.tab.id);
      if(live.incognito!==false||live.url!==sender.url)throw new Error();
      await AccountAPI.call('tabs.update',sender.tab.id,{url:bridge+'#'+new URLSearchParams({id:message.id,request:crypto.randomUUID()}),active:true});
      return {started:true};
    } finally {busyTabs.delete(sender.tab.id);}
  }
  AccountAPI.native.runtime.onMessage.addListener((message,sender,sendResponse)=>{
    if(!sender||sender.id!==AccountAPI.native.runtime.id||sender.tab?.incognito){sendResponse({ok:false,error:'請在一般瀏覽模式操作。'});return false;}
    const isQuick=['quickState','quickStart','quickApply'].includes(message?.type);
    if(!isQuick&&!sender.url?.startsWith(base)){sendResponse({ok:false,error:'不支援的操作。'});return false;}
    const work=isQuick?quick(message,sender):engine.handle(message,{tab:sender.tab});
    work.then(data=>sendResponse({ok:true,data}),error=>sendResponse({ok:false,error:error.safeMessage||'操作未完成，請重新開啟切換選單後再試。'}));
    return true;
  });
})();
