(function () {
  'use strict';
  const versionNode = document.getElementById('update-version');
  const button = document.getElementById('update-check');
  const resultNode = document.getElementById('update-result');
  const releaseLink = document.getElementById('update-release-link');
  const Update = globalThis.AccountUpdate;
  if (!versionNode || !button || !resultNode || !releaseLink || !Update) return;

  releaseLink.href = Update.RELEASE_URL;
  releaseLink.target = '_blank';
  releaseLink.rel = 'noopener noreferrer';
  let currentVersion;
  try {
    const native = globalThis.browser || globalThis.chrome;
    currentVersion = native.runtime.getManifest().version;
    Update.parseVersion(currentVersion);
    versionNode.textContent = '目前版本 v' + currentVersion;
  } catch (_) {
    versionNode.textContent = '無法讀取目前版本';
    button.disabled = true;
    resultNode.textContent = '請從版本頁查看最新安裝檔。帳號功能不受影響。';
    return;
  }

  function element(tag, text, className) {
    const node = document.createElement(tag);
    if (text !== undefined) node.textContent = text;
    if (className) node.className = className;
    return node;
  }

  function render(result) {
    resultNode.replaceChildren();
    const metadata = result.metadata;
    const status = result.status === 'available' ? '有新版本 v' + metadata.version :
      result.status === 'current' ? '目前已是最新版本 v' + metadata.version :
        '目前安裝版本比發布頁更新，保留目前版本即可。';
    resultNode.append(element('p', status, 'update-status'));
    if (result.status !== 'available') return;
    if (metadata.notes.length) {
      const list = element('ul', undefined, 'update-notes');
      for (const note of metadata.notes) list.append(element('li', note));
      resultNode.append(list);
    }
    const links = element('div', undefined, 'update-downloads');
    for (const kind of ['xpi', 'zip']) {
      const link = element('a', '下載 ' + kind.toUpperCase(), 'button button-outline');
      link.href = metadata.downloads[kind].url;
      link.target = '_blank'; link.rel = 'noopener noreferrer';
      links.append(link);
    }
    resultNode.append(links);
    resultNode.append(element('p', '下載後需在 Orion 手動安裝更新。更新前保留原始 Cookie 匯出檔，勿先解除安裝舊版。', 'field-help'));
    const details = element('details', undefined, 'update-hashes');
    details.append(element('summary', '檔案校驗碼 SHA-256'));
    for (const kind of ['xpi', 'zip']) {
      const row = element('p', kind.toUpperCase() + '：');
      row.append(element('code', metadata.downloads[kind].sha256));
      details.append(row);
    }
    resultNode.append(details);
  }

  button.addEventListener('click', async () => {
    if (button.disabled) return;
    button.disabled = true;
    button.textContent = '檢查中…';
    resultNode.textContent = '正在讀取公開版本資訊，最長等待 10 秒。';
    resultNode.setAttribute('aria-busy', 'true');
    try { render(await Update.checkForUpdate(currentVersion)); }
    catch (error) {
      resultNode.replaceChildren(element('p', error && error.message ? error.message : '目前無法檢查更新，請開啟版本頁。'));
      resultNode.append(element('p', '帳號資料不會上傳，現有帳號功能可繼續使用。', 'field-help'));
    } finally {
      button.disabled = false;
      button.textContent = '檢查更新';
      resultNode.removeAttribute('aria-busy');
    }
  });
})();
