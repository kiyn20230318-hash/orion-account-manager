(function (root) {
  'use strict';
  // BitBrowser (比特瀏覽器) local API, used only from the background page and only
  // for the manager. Reads window names and the Cookie data each window has
  // stored; never writes to BitBrowser. Only id/seq/name/remark/group and the
  // Cookie text are kept: passwords, proxy settings and every other field the
  // API returns are dropped right here and never stored or logged.
  const KEY = 'bitBrowserV1';
  const DEFAULT_BASE = 'http://127.0.0.1:54345';
  const PAGE_SIZE = 100;
  const MAX_PAGES = 60;
  const INDEX_FROM = 8; // From this many names, list every window once instead of one search per name.
  const PARALLEL = 4;
  const MAX_NAMES = 100;
  const clean = (value, max = 100) => (typeof value === 'string' || typeof value === 'number') ? String(value).replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max) : '';
  const fail = message => Object.assign(new Error(message), {safeMessage: message});
  const nameKey = name => typeof name === 'string' ? name.normalize('NFC').trim().toLocaleLowerCase('en-US') : '';
  const validId = value => typeof value === 'string' && /^[A-Za-z0-9_-]{1,64}$/.test(value);

  // Accepts "192.168.1.5:54345", "http://192.168.1.5:54345/", etc. Keeps only
  // scheme + host + port so a pasted path can never redirect the requests.
  function normalizeBase(input) {
    let text = typeof input === 'string' ? input.trim() : '';
    if (!text) return DEFAULT_BASE;
    if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(text)) text = 'http://' + text;
    let url;
    try { url = new URL(text); } catch (_) { throw fail('比特瀏覽器位址格式不正確，例如 http://192.168.1.5:54345'); }
    if (url.protocol !== 'http:' || !url.hostname || url.username || url.password) throw fail('比特瀏覽器位址只能是 http:// 加上電腦 IP 與埠號，例如 http://192.168.1.5:54345');
    return url.origin;
  }
  // "#12" (or "＃12") picks a window by its sequence number; anything else is a name.
  function parseEntry(line) {
    const text = clean(line, 100);
    if (!text) return null;
    const seq = text.match(/^[#＃]\s*(\d{1,9})$/);
    return seq ? {input: text, seq: Number(seq[1])} : {input: text, name: text.normalize('NFC')};
  }
  function parseEntries(text) {
    const seen = new Set(), entries = [];
    for (const line of String(text || '').split(/[\r\n,，]+/)) {
      const entry = parseEntry(line);
      if (!entry) continue;
      const key = entry.seq !== undefined ? '#' + entry.seq : nameKey(entry.name);
      if (seen.has(key)) continue;
      seen.add(key);entries.push(entry);
    }
    return entries;
  }
  function windowInfo(item) {
    return {id: clean(item?.id, 64), seq: Number.isSafeInteger(item?.seq) ? item.seq : null, name: clean(item?.name, 100),
      remark: clean(item?.remark, 80), group: clean(item?.groupName, 60)};
  }

  // BitBrowser refuses more than 10 requests per second ("请求太过频繁"):
  // requests start at least GAP_MS apart, and a refusal waits and retries.
  const GAP_MS = 130;
  const RETRIES = 3;
  const busyReply = message => /频繁|頻繁|too many requests|rate limit/i.test(message || '');
  const authReply = message => /token|api[\s_-]*key|鉴权|鑑權|认证|認證|授权|授權|unauthori[sz]ed|forbidden/i.test(message || '');
  const validToken = value => typeof value === 'string' && /^[\x21-\x7e]{1,200}$/.test(value);
  function cleanToken(input) {
    if (typeof input !== 'string') throw fail('Token 格式不正確。');
    const token = input.trim();
    if (token && !validToken(token)) throw fail('Token 格式不正確（只能是英數與符號，不可含空白，最長 200 字）。');
    return token;
  }

  function create({fetch, get, set, timeoutMs = 15000, now = () => Date.now(), sleep = ms => new Promise(resolve => setTimeout(resolve, ms))}) {
    let nextSlot = 0;
    async function pace() {
      const wait = nextSlot - now();
      nextSlot = Math.max(now(), nextSlot) + GAP_MS;
      if (wait > 0) await sleep(wait);
    }
    async function load() {
      const result = await get(KEY);
      const saved = result && typeof result === 'object' ? result[KEY] : null;
      return saved && typeof saved === 'object' && !Array.isArray(saved) ? saved : {};
    }
    // The BitBrowser "Local API Token" (sent as X-API-KEY) is stored here on its
    // own; it is never returned to a page, only whether one is saved and its
    // last four characters.
    async function settings() {
      const saved = await load();
      let baseUrl = DEFAULT_BASE;
      try { baseUrl = normalizeBase(saved.baseUrl); } catch (_) { /* Fall back to the default. */ }
      const hasToken = validToken(saved.token);
      return {baseUrl, isDefault: baseUrl === DEFAULT_BASE, hasToken, tokenHint: hasToken ? '••••' + saved.token.slice(-4) : ''};
    }
    // token: undefined keeps the saved one, '' removes it.
    async function saveSettings(input = {}) {
      const saved = await load();
      if (input.baseUrl !== undefined) saved.baseUrl = normalizeBase(input.baseUrl);
      if (input.token !== undefined) {
        const token = cleanToken(input.token);
        if (!token) delete saved.token; else saved.token = token;
      }
      await set({[KEY]: saved});
      return settings();
    }
    // Address and token for one action: typed values win over the saved ones.
    async function connection(input = {}) {
      const saved = await load();
      const typed = input.baseUrl !== undefined && input.baseUrl !== null && String(input.baseUrl).trim();
      const token = input.token !== undefined && input.token !== null && String(input.token).trim() ? cleanToken(input.token) : (validToken(saved.token) ? saved.token : '');
      return {baseUrl: typed ? normalizeBase(input.baseUrl) : (await settings()).baseUrl, token};
    }
    async function request(conn, path, body) {
      for (let attempt = 0; ; attempt++) {
        await pace();
        try { return await requestOnce(conn, path, body); }
        catch (error) {
          if (!error.rateLimited || attempt >= RETRIES) throw error;
          await sleep(1000 * (attempt + 1));
        }
      }
    }
    function authError(conn) {
      return fail(conn.token ? '比特瀏覽器拒絕這個 Token：請到比特瀏覽器「設定 → Local API Token」複製目前的 Token，重新填入後再試。'
        : '比特瀏覽器已開啟 API 鑑權：請在「Local API Token」欄位填入比特瀏覽器「設定 → Local API Token」中的 Token。');
    }
    async function requestOnce(conn, path, body) {
      const baseUrl = conn.baseUrl;
      const controller = typeof AbortController === 'function' ? new AbortController() : null;
      const timer = setTimeout(() => controller?.abort(), timeoutMs);
      const headers = {'Content-Type': 'application/json'};
      if (conn.token) headers['X-API-KEY'] = conn.token;
      let response;
      try {
        response = await fetch(baseUrl + path, {method: 'POST', headers, body: JSON.stringify(body),
          credentials: 'omit', cache: 'no-store', ...(controller ? {signal: controller.signal} : {})});
      } catch (error) {
        if (error?.name === 'AbortError') throw fail('連線逾時（' + baseUrl + '）。請確認比特瀏覽器已開啟，手機與電腦在同一個 Wi‑Fi。');
        throw fail('無法連線到比特瀏覽器（' + baseUrl + '）。請確認：1. 比特瀏覽器已開啟；2. 位址是電腦的區網 IP（手機不能用 127.0.0.1）；3. 手機與電腦在同一個 Wi‑Fi；4. 電腦防火牆允許此埠。');
      } finally { clearTimeout(timer); }
      let reply = null;
      try { reply = await response.json(); } catch (_) { /* Handled below. */ }
      if (response.status === 401 || response.status === 403) throw authError(conn);
      if (!reply || typeof reply !== 'object' || typeof reply.success !== 'boolean') throw fail('此位址的回覆不是比特瀏覽器本地 API（HTTP ' + response.status + '），請檢查埠號。');
      if (!reply.success) {
        const msg = clean(reply.msg, 160);
        if (authReply(msg)) throw Object.assign(authError(conn), {detail: msg});
        throw Object.assign(fail('比特瀏覽器回覆：' + (msg || '操作未完成。')), {rateLimited: busyReply(msg)});
      }
      return reply.data;
    }
    async function listPage(conn, filter, page) {
      const data = await request(conn, '/browser/list', {page, pageSize: PAGE_SIZE, ...filter});
      const list = Array.isArray(data?.list) ? data.list : null;
      if (!list) throw fail('比特瀏覽器窗口清單格式無法辨識。');
      const total = Number.isSafeInteger(data.totalNum) ? data.totalNum : list.length;
      return {total, items: list.map(windowInfo).filter(item => validId(item.id))};
    }
    // Every page of a filtered listing (bounded), so exact matches past the
    // first 100 fuzzy hits are still found.
    async function listAll(conn, filter) {
      const items = [];
      for (let page = 0; page < MAX_PAGES; page++) {
        const result = await listPage(conn, filter, page);
        items.push(...result.items);
        if (result.items.length < PAGE_SIZE || items.length >= result.total) return items;
      }
      return items;
    }
    // Browse: one page of windows, optionally filtered by (fuzzy) name.
    async function listWindows(input = {}) {
      const conn = await connection(input);
      const query = clean(input.query, 100);
      const page = Number.isSafeInteger(input.page) && input.page >= 0 && input.page < 1000 ? input.page : 0;
      const result = await listPage(conn, query ? {name: query} : {}, page);
      return {baseUrl: conn.baseUrl, page, pageSize: PAGE_SIZE, total: result.total, items: result.items};
    }
    // `index` (every window, listed once) when many names are asked for;
    // otherwise one filtered search per name.
    async function resolve(conn, entry, index) {
      if (entry.seq !== undefined) {
        const hits = (index || await listAll(conn, {seq: entry.seq})).filter(item => item.seq === entry.seq);
        if (!hits.length) return {input: entry.input, status: 'missing', error: '找不到序號 #' + entry.seq + ' 的窗口。'};
        return {input: entry.input, status: 'found', window: hits[0]};
      }
      const key = nameKey(entry.name);
      const hits = (index || await listAll(conn, {name: entry.name})).filter(item => nameKey(item.name) === key);
      if (!hits.length) return {input: entry.input, status: 'missing', error: '找不到名稱完全相同的窗口「' + entry.input + '」。'};
      if (hits.length > 1) {
        const seqs = hits.map(item => item.seq).filter(seq => seq !== null);
        return {input: entry.input, status: 'ambiguous', error: '有 ' + hits.length + ' 個窗口都叫「' + entry.input + '」' + (seqs.length ? '（序號 ' + seqs.map(s => '#' + s).join('、') + '）' : '') + '，請改輸入 #序號 指定其中一個。'};
      }
      return {input: entry.input, status: 'found', window: hits[0]};
    }
    // The stored Cookie of one window, kept as the original JSON text. An empty
    // or unreadable store is reported, never guessed or merged with another window.
    async function cookieText(conn, id) {
      const data = await request(conn, '/browser/detail', {id});
      const raw = data?.cookie;
      if (raw === undefined || raw === null || (typeof raw === 'string' && !raw.trim())) return {error: '此窗口沒有儲存 Cookie（請先在比特瀏覽器開啟並登入一次）。'};
      let cookies = raw;
      if (typeof raw === 'string') { try { cookies = JSON.parse(raw); } catch (_) { return {error: '此窗口的 Cookie 格式無法辨識。'}; } }
      if (!Array.isArray(cookies)) return {error: '此窗口的 Cookie 格式無法辨識。'};
      if (!cookies.length) return {error: '此窗口沒有儲存 Cookie（請先在比特瀏覽器開啟並登入一次）。'};
      return {cookies};
    }
    // Names (or #seq) → one result per entry: the window it matched and its own
    // Cookie, or why it could not be read. Each window stays a separate account.
    async function fetchByNames(input = {}) {
      const conn = await connection(input);
      const entries = Array.isArray(input.entries) ? input.entries.map(parseEntry).filter(Boolean) : parseEntries(input.text);
      if (!entries.length) throw fail('請輸入至少一個比特瀏覽器窗口名稱。');
      if (entries.length > MAX_NAMES) throw fail('每批最多 ' + MAX_NAMES + ' 個窗口，請分批讀取。');
      // A first request on its own: a wrong address fails once, clearly, instead of per name.
      const first = await listPage(conn, {}, 0);
      const index = entries.length >= INDEX_FROM ? (first.items.length >= first.total ? first.items : await listAll(conn, {})) : null;
      const results = [], usedIds = new Set();
      for (const entry of entries) {
        let result;
        try { result = await resolve(conn, entry, index); }
        catch (error) { result = {input: entry.input, status: 'error', error: error.safeMessage || '讀取失敗。'}; }
        if (result.status === 'found') {
          if (usedIds.has(result.window.id)) { results.push({input: entry.input, status: 'duplicate', error: '與前面輸入的是同一個窗口，已略過。'}); continue; }
          usedIds.add(result.window.id);
        }
        results.push(result);
      }
      // Each window's own Cookie, a few at a time; results stay in input order.
      const pending = results.filter(r => r.status === 'found');
      let next = 0;
      async function worker() {
        while (next < pending.length) {
          const result = pending[next++];
          try {
            const stored = await cookieText(conn, result.window.id);
            if (stored.error) Object.assign(result, {status: 'empty', error: stored.error});
            else Object.assign(result, {cookies: stored.cookies, cookieCount: stored.cookies.length});
          } catch (error) { Object.assign(result, {status: 'error', error: error.safeMessage || '讀取 Cookie 失敗。'}); }
        }
      }
      await Promise.all(Array.from({length: Math.min(PARALLEL, pending.length)}, worker));
      return {baseUrl: conn.baseUrl, results, found: results.filter(r => r.status === 'found').length};
    }
    return {settings, saveSettings, listWindows, fetchByNames};
  }
  const exported = {create, normalizeBase, parseEntries, KEY, DEFAULT_BASE, PAGE_SIZE, MAX_NAMES};
  root.AccountBit = exported;
  if (typeof module !== 'undefined' && module.exports) module.exports = exported;
})(globalThis);
