(function (root) {
  'use strict';
  const C = root.AccountCore || (typeof require === 'function' ? require('./core.js') : null);
  const B = root.AccountBulk || (typeof require === 'function' ? require('./bulk.js') : null);
  const KEY = 'accountManagerV1';
  const REQUIRED = ['storage.local.get', 'storage.local.set', 'cookies.getAll', 'cookies.set', 'cookies.remove', 'tabs.query', 'tabs.remove', 'tabs.create', 'tabs.update'];
  const RECOVERY_REQUIRED = REQUIRED.filter(name => !['tabs.create','tabs.update'].includes(name));
  const empty = () => ({version: 1, profiles: [], activeId: null, activeScope: [], pending: null, lastResult: null});
  const copy = value => JSON.parse(JSON.stringify(value));
  const SAFE_ERROR=Symbol('engineSafeError');
  const NATIVE_SESSION_ONLY=Symbol('nativeSessionOnly');
  const fail = message => Object.assign(new Error(message), {safeMessage: message,[SAFE_ERROR]:true});
  const safeErrorText=(error,fallback)=>error?.[SAFE_ERROR]===true?error.safeMessage:fallback;
  const host = value => String(value).replace(/^\./, '').toLowerCase();
  const unique = values => [...new Set(values.map(host))];
  const byteSize = value => new TextEncoder().encode(JSON.stringify(value)).length;
  // Only messages emitted by our own validator may become diagnostics. Never
  // forward a browser error or a cookie field to the UI.
  const COOKIE_REASONS = new Map([
    ['每筆 Cookie 必須是物件。', 'Cookie 項目格式不是物件。'],
    ['此 Cookie 使用分割儲存或第一方隔離，無法安全移植到 Orion。', '含分割儲存或第一方隔離屬性，無法安全移轉。'],
    ['Cookie 的 partitioned 必須是 true 或 false。', 'partitioned 欄位不是布林值。'],
    ['Cookie 名稱必須是文字，且不可含不允許的字元。', 'Cookie 名稱格式不相容。'],
    ['Cookie 值必須是文字，且不可含分號或控制字元。', 'Cookie 值的格式不相容。'],
    ...['Cookie 缺少有效的網域。','Cookie 網域格式無效。','Cookie 網域不可使用結尾句點。','Cookie 網域不可包含通訊埠。','Cookie 的 IP 網域須使用完整的十進位位址。','Cookie 缺少網域；請提供匯入網址。'].map(message=>[message,'Cookie 網域格式不相容。']),
    ['Cookie 路徑必須以 / 開頭，且不可含分號或控制字元。','Cookie 路徑格式不相容。'],
    ['此 Cookie 路徑無法透過瀏覽器網址完整清除；不可含未編碼的特殊字元或相對路徑片段。','Cookie 路徑無法透過瀏覽器網址完整清除。'],
    ...['hostOnly','secure','httpOnly','session'].map(field=>['Cookie 的 '+field+' 必須是 true 或 false。',field+' 欄位不是布林值。']),
    ...['Cookie 的 sameSite 格式無效。','Cookie 的 sameSite 僅支援 unspecified、None、Lax 或 Strict。'].map(message=>[message,'sameSite 欄位格式不相容。']),
    ['SameSite=None 的 Cookie 必須原本就有 Secure 屬性；請重新匯出正確資料。','SameSite=None 缺少 Secure 屬性。'],
    ...['Cookie 的 ISO 日期不是有效的日期或時間。','Cookie 的有效期限無效。','Cookie 的有效期限不可為負數（工作階段值 -1 除外）。','Cookie 的有效期限超出支援範圍。',...['expirationDate','expires','expiry'].map(field=>'Cookie 的 '+field+' 必須是時間戳記或含時區的 ISO 日期。')].map(message=>[message,'有效期限欄位格式不相容。']),
    ['Cookie 含有互相矛盾的有效期限。','多個有效期限欄位互相矛盾。'],
    ['Cookie 的 session 屬性與有效期限互相矛盾。','session 屬性與有效期限互相矛盾。'],
    ['__Secure- Cookie 必須具有 Secure 屬性。','受限制名稱的 Cookie 缺少 Secure 屬性。'],
    ['__Host- Cookie 必須具有 Secure、僅限主機，且路徑為 /。','受限制名稱的 Cookie 屬性不完整。'],
    ['Cookie 已過期。','Cookie 已過期。']
  ]);
  const reason = error => COOKIE_REASONS.get(error?.message) || 'Cookie 屬性格式不相容，無法安全移轉。';
  const owns = (value,key) => Object.prototype.hasOwnProperty.call(value,key);
  const EXPIRY_FIELDS = ['expirationDate','expires','expiry'];
  const hasMissingNativeExpiry = cookie => Boolean(cookie && typeof cookie==='object' && !Array.isArray(cookie) && cookie.session===false && EXPIRY_FIELDS.every(field=>!owns(cookie,field)));
  const unknownExpiryCount = cookies => cookies.filter(cookie=>cookie.nativeExpiryUnknown===true).length;
  const EXPIRY_WARNING = 'Orion 未回傳部分 Cookie 的到期日；已核對名稱、值及其他屬性，但無法核對這些 Cookie 的期限與工作階段狀態。';
  const BACKUP_WARNING = '部分切換前 Cookie 的原始期限未知；若需復原，只能暫時以工作階段 Cookie 還原，不能保證原期限。';
  const SAVED_WARNING = '已保留離開帳號原先儲存的 Cookie，未用期限未知或僅工作階段的讀回資料覆寫。';
  const TEMP_RESTORE_WARNING = '期限未知的備份已暫時以工作階段 Cookie 復原；原始期限無法還原，瀏覽器結束工作階段後可能需要重新登入。';
  const SESSION_WARNING = '瀏覽器把有期限的 Cookie 回報為工作階段 Cookie；內容與其他屬性已核對，但不能確認原期限，關閉瀏覽器後可能需要再次套用。';
  const ATTRIBUTE_WARNING = '本次使用屬性相容套用：已核對 Cookie 名稱、值、網域與路徑，但無法確認 HttpOnly、Secure、僅限主機、SameSite 及期限是否維持原設定。這不代表已登入，請在網站確認實際帳號。';
  const ATTRIBUTE_SAVED_WARNING = '已保留離開帳號原先儲存的 Cookie，未用屬性無法確認的瀏覽器讀回資料覆寫。';
  const ATTRIBUTE_RESTORE_WARNING = '已有限復原切換前的 Cookie 內容；原安全屬性及期限無法完整確認，請在網站確認實際帳號。';
  const SAME_SITE_RESTORE_WARNING = '備份中瀏覽器回報的 SameSite 與 Secure 不相容，復原時採瀏覽器預設 SameSite；不是完整屬性還原。';
  const EXPIRED_SKIPPED_WARNING = '已略過本次已過期的 Cookie，未延長期限；原匯入資料仍保留，網站可能要求重新登入。';
  const TAB_WARNING = '未能確認舊分頁已停止；已繼續套用並核對 Cookie。各分頁共用目前帳號，舊頁可能仍顯示先前畫面。';
  const warningList = values => [...new Set((Array.isArray(values)?values:[]).filter(value=>[EXPIRY_WARNING,BACKUP_WARNING,SAVED_WARNING,TEMP_RESTORE_WARNING,SESSION_WARNING,ATTRIBUTE_WARNING,ATTRIBUTE_SAVED_WARNING,ATTRIBUTE_RESTORE_WARNING,SAME_SITE_RESTORE_WARNING,EXPIRED_SKIPPED_WARNING,TAB_WARNING].includes(value)))];
  const lifetimeLimited=warnings=>warningList(warnings).some(value=>[EXPIRY_WARNING,TEMP_RESTORE_WARNING,SESSION_WARNING].includes(value));
  const withWarnings = (message,warnings) => message+(warnings.length?' '+warnings.join(' '):'');
  const BOOLEAN_FIELDS=['secure','httpOnly','hostOnly','session'];
  const SAME_SITE_VALUES=['unspecified','no_restriction','lax','strict'];
  const contentKey=cookie=>JSON.stringify([cookie.name,host(cookie.domain),cookie.path]);
  const uniqueContent=cookies=>new Set(cookies.map(contentKey)).size===cookies.length;
  // Orion can repeat the same content with inconsistent native attributes.
  // Collapse only equal values; distinct values must never be guessed away.
  function mergeNativeDuplicates(cookies, compatible) {
    if(!compatible)return cookies;
    const groups=new Map();
    for(const cookie of cookies){
      const key=contentKey(cookie), prior=groups.get(key);
      if(!prior){groups.set(key,cookie);continue;}
      if(prior.value!==cookie.value)return cookies;
    }
    return [...groups.values()];
  }
  function splitConflictingSnapshot(cookies) {
    const values=new Map();
    for(const cookie of cookies){const key=contentKey(cookie);if(!values.has(key))values.set(key,new Set());values.get(key).add(cookie.value);}
    const conflicted=cookie=>values.get(contentKey(cookie)).size>1;
    return {restorable:mergeNativeDuplicates(cookies.filter(cookie=>!conflicted(cookie)),true),omitted:cookies.filter(conflicted)};
  }
  const PROBE_CASE_IDS=['host_only','domain','secure_false','http_only_false','explicit_false','strict','none','default','session','path'];
  const PROBE_FIELDS=['name','value','domain','path','hostOnly','secure','httpOnly','session','sameSite','expirationDate'];
  // Only a complete, cleaned synthetic round trip is capability evidence. A
  // partial/uncertain rerun cannot silently clear an earlier confirmed issue.
  function completeCookieProbe(report) {
    if(!report||report.version!==1||!Number.isFinite(report.checkedAt)||report.checkedAt<=0||report.errorCode||report.summary?.cleanup!=='cleared'||!Array.isArray(report.cases)||report.cases.length!==PROBE_CASE_IDS.length)return null;
    const ids=new Set();
    for(const item of report.cases) {
      if(!item||!PROBE_CASE_IDS.includes(item.id)||ids.has(item.id)||item.errorCode||!['passed','failed','unsupported'].includes(item.status)||!Array.isArray(item.checks))return null;
      ids.add(item.id);
      const fields=new Set();
      for(const check of item.checks) {
        if(!check||![...PROBE_FIELDS,'subdomainVisible'].includes(check.field)||fields.has(check.field))return null;
        fields.add(check.field);
        let expected,values;
        if(['name','value','domain','path'].includes(check.field)){expected='matches';values=['matches','changed'];}
        else if(check.field==='sameSite'){expected=item.id==='strict'?'strict':item.id==='none'?'no_restriction':item.id==='default'?'unspecified':'lax';values=[...SAME_SITE_VALUES,'missing','invalid'];}
        else if(check.field==='expirationDate'){expected=item.id==='session'?'missing':'matches';values=['matches','missing','changed','invalid'];}
        else {
          expected=check.field==='hostOnly'?item.id!=='domain':check.field==='secure'?!['secure_false','explicit_false'].includes(item.id):check.field==='httpOnly'?!['http_only_false','explicit_false'].includes(item.id):check.field==='session'?item.id==='session':item.id==='domain';
          values=check.field==='subdomainVisible'?[true,false]:[true,false,'missing','invalid'];
        }
        const status=check.field==='sameSite'&&expected==='unspecified'&&SAME_SITE_VALUES.includes(check.actual)&&check.actual!==expected?'observed':check.actual===expected?'passed':'failed';
        if(check.expected!==expected||!values.includes(check.actual)||check.status!==status)return null;
      }
      if(PROBE_FIELDS.some(field=>!fields.has(field)))return null;
      const status=item.checks.some(check=>check.status==='failed')?'failed':item.checks.some(check=>check.status==='observed')?'unsupported':'passed';
      if(item.status!==status)return null;
    }
    if(['passed','failed','unsupported'].some(status=>report.summary[status]!==report.cases.filter(item=>item.status===status).length))return null;
    return report;
  }
  function probeSwitchBlocker(report) {
    if(!completeCookieProbe(report))return null;
    const fields=['httpOnly','hostOnly'].filter(field=>report.cases.some(item=>item.id!=='explicit_false'&&item.checks.some(check=>check.field===field&&typeof check.expected==='boolean'&&typeof check.actual==='boolean'&&check.expected!==check.actual)));
    if(!fields.length)return null;
    const labels=fields.map(field=>field==='httpOnly'?'HttpOnly':'僅限主機（hostOnly）').join('、');
    return {code:'critical_probe_mismatch',checkedAt:report.checkedAt,extensionVersion:typeof report.extensionVersion==='string'&&/^\d+(\.\d+){1,3}$/.test(report.extensionVersion)?report.extensionVersion:null,fields,
      message:'上次完整裝置測試中，'+labels+' 屬性寫入後讀回不一致；已在修改 Cookie 前停止切換，期限相容處理無法修正這些差異。請更新 Orion 或處理擴充套件相容性後重新執行裝置測試。這項結果不代表網站本身無法登入。'};
  }
  const enumValue=(cookie,field)=>field==='sameSite'?(SAME_SITE_VALUES.includes(cookie?.sameSite)?cookie.sameSite:undefined):(typeof cookie?.[field]==='boolean'?cookie[field]:undefined);
  function transitionCounts(pairs) {
    const counts=new Map();
    for(const [expected,actual] of pairs)for(const field of [...BOOLEAN_FIELDS,'sameSite']) {
      const from=enumValue(expected,field),to=field==='session'&&actual?.nativeExpiryUnknown===true?false:enumValue(actual,field);
      if(from!==undefined&&to!==undefined&&from!==to){const key=JSON.stringify([field,from,to]);counts.set(key,(counts.get(key)||0)+1);}
    }
    return [...counts].map(([key,count])=>{const [field,from,to]=JSON.parse(key);return{field,from,to,count};});
  }
  function identityDiagnostics(expected,actual) {
    const expectedKeys=new Set(expected.map(C.cookieKey)),actualKeys=new Set(actual.map(C.cookieKey));
    let remainingExpected=expected.filter(cookie=>!actualKeys.has(C.cookieKey(cookie)));
    let remainingActual=actual.filter(cookie=>!expectedKeys.has(C.cookieKey(cookie)));
    const pairs=[],ambiguousExpected=new Set(),ambiguousActual=new Set();
    const pass=keyFor=>{
      const group=rows=>{const map=new Map();for(const cookie of rows){const key=keyFor(cookie);if(!map.has(key))map.set(key,[]);map.get(key).push(cookie);}return map;};
      const left=group(remainingExpected),right=group(remainingActual),usedLeft=new Set(),usedRight=new Set();
      for(const [key,from] of left) {
        const to=right.get(key)||[];if(!to.length)continue;
        if(from.length===1&&to.length===1){pairs.push([from[0],to[0]]);usedLeft.add(from[0]);usedRight.add(to[0]);}
        else {from.forEach(cookie=>ambiguousExpected.add(cookie));to.forEach(cookie=>ambiguousActual.add(cookie));}
      }
      remainingExpected=remainingExpected.filter(cookie=>!usedLeft.has(cookie));remainingActual=remainingActual.filter(cookie=>!usedRight.has(cookie));
    };
    // These weaker pairings explain strict missing/unexpected counts only.
    // They are never used to accept a cookie or to waive any attribute check.
    pass(cookie=>JSON.stringify([cookie.name,host(cookie.domain),cookie.path]));
    pass(cookie=>JSON.stringify([cookie.name,cookie.path]));
    return {pairs,summary:{hostOnlyCount:pairs.filter(([a,b])=>a.hostOnly!==b.hostOnly).length,domainCount:pairs.filter(([a,b])=>host(a.domain)!==host(b.domain)).length,
      ambiguousExpectedCount:remainingExpected.filter(cookie=>ambiguousExpected.has(cookie)).length,ambiguousActualCount:remainingActual.filter(cookie=>ambiguousActual.has(cookie)).length,
      unpairedExpectedCount:remainingExpected.length,unpairedActualCount:remainingActual.length}};
  }
  const shape = (value,key) => !owns(value,key) ? '缺少' : value[key] === null ? 'null' : Array.isArray(value[key]) ? 'array' : typeof value[key];
  function cookieAudit(cookies, now, allowExpired) {
    const counts = new Map(), shapes = new Map();
    let invalid = 0;
    const fields = ['partitionKey','partitioned','firstPartyDomain','hostOnly','secure','httpOnly','session','expirationDate','expires','expiry','sameSite','path'];
    for (const cookie of cookies) {
      const problems = new Set();
      const check = input => { try { C.normalizeCookie(input,{now,allowExpired}); } catch(error) { problems.add(reason(error)); } };
      check(cookie);
      if (cookie && typeof cookie === 'object' && !Array.isArray(cookie)) {
        for (const field of fields) {
          const key = field+': '+shape(cookie,field);
          shapes.set(key,(shapes.get(key)||0)+1);
        }
        // Independent probes reveal more than the first failing attribute. A
        // synthetic seed prevents diagnostics from changing any actual cookie.
        const seed = {name:'diagnostic',value:'',domain:'example.test',path:'/',secure:false};
        for (const group of [['partitionKey','partitioned','firstPartyDomain'],['name','secure','hostOnly','path'],['value'],['domain','url'],['path'],['hostOnly'],['secure'],['httpOnly'],['sameSite','secure'],['session','expirationDate','expires','expiry']]) {
          const probe = {...seed};
          for (const field of group) if (owns(cookie,field)) probe[field]=cookie[field];
          check(probe);
        }
      }
      if (problems.size) invalid++;
      for (const problem of problems) counts.set(problem,(counts.get(problem)||0)+1);
    }
    return {invalid,counts,shapes};
  }
  function boundedRead(promise) {
    let timer;
    return Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('Read timeout')),5000);})]).finally(()=>clearTimeout(timer));
  }
  function inScope(cookie, scopes) {
    const domain = host(cookie.domain);
    return scopes.some(scope => C.domainMatches(domain, scope) || (!cookie.hostOnly && C.domainMatches(scope, domain)));
  }
  function appliesToTarget(cookie,targetHost) {
    return cookie.hostOnly ? host(cookie.domain) === targetHost : C.domainMatches(targetHost,cookie.domain);
  }
  function auditChecks(prefix, audit, includeShapes) {
    const checks = [{label:prefix+'相容性',status:audit.invalid?'failed':'passed',detail:audit.invalid ? audit.invalid+' 筆 Cookie 有不相容屬性；同一筆可能含多個原因。' : '已逐筆檢查，沒有發現不相容屬性。'}];
    for (const [detail,count] of audit.counts) checks.push({label:prefix+'原因',status:'failed',detail:count+' 筆：'+detail});
    if (includeShapes) checks.push({label:prefix+'欄位形狀',status:'passed',detail:audit.shapes.size ? [...audit.shapes].map(([key,count])=>key+' '+count+' 筆').join('；') : '沒有可統計的原生欄位。'});
    return checks;
  }
  function tabInScope(tab, scopes) {
    if (tab.incognito) return false;
    return [tab.url, tab.pendingUrl].filter(Boolean).some(value => {
      try {
        const url = new URL(value);
        return ['http:', 'https:'].includes(url.protocol) && scopes.some(scope => C.domainMatches(url.hostname, scope));
      } catch (_) { return false; }
    });
  }
  function profileHealth(db) {
    const valid = [], invalid = [], ids = new Set();
    for (const p of db.profiles) {
      try {
        if (!p || typeof p.id !== 'string' || !p.id || ids.has(p.id) || typeof p.name !== 'string' || !p.name.trim() || !Array.isArray(p.cookies)) throw new Error();
        C.validateUrl(p.startUrl);
        p.cookies.forEach(cookie => C.normalizeCookie(cookie,{allowExpired:true}));
        ids.add(p.id); valid.push(p);
      } catch (_) { invalid.push(p); }
    }
    return {valid, invalid};
  }
  function baseMetadata(db) {
    const health = profileHealth(db);
    return {
      profiles: health.valid.map(p => ({id: p.id, name: p.name, startUrl: p.startUrl,
        cookieCount: p.cookies.length, domains: C.profileDomains(p.cookies,p.startUrl), updatedAt: p.updatedAt,
        needsApply: p.id !== db.activeId || p.cookieRevision !== db.activeCookieRevision})),
      activeId: db.activeId, pending: Boolean(db.pending), lastResult: db.pending ? {status:'pending',message:db.lastAttempt?.message || '上次套用未完成。可重新套用所選帳號，或展開復原選項。',at:db.pending.startedAt} : db.lastResult,
      activeWarnings:warningList(db.activeWarnings),
      activeAttributeLimited:db.activeAttributeLimited===true,
      lastAttempt:db.lastAttempt||null,lastMutatedAttempt:db.lastMutatedAttempt||null,
      lastCookieProbe:db.lastCookieProbe||null,
      invalidProfileCount: health.invalid.length
    };
  }
  function create(api, {now = () => Date.now(), id = () => {
    if (typeof root.crypto?.randomUUID !== 'function') throw fail('此 Orion 版本無法產生帳號識別碼，請更新 Orion 後再新增帳號。');
    return root.crypto.randomUUID();
  }, apiTimeoutMs = 10000, sleep = ms => new Promise(resolve => setTimeout(resolve, ms))} = {}) {
    let busy = false;
    let currentStoreId;
    const parkedTabIds = new Set();
    let tabStopUnconfirmed = false;
    // Evidence only: this can offer a per-request choice, never grant consent.
    let observedMissingNativeExpiry = false;
    let currentAttempt=null, latestAttempt=null, latestMutatedAttempt=null, latestCookieProbe=null, attemptSequence=0;
    let latestCompleteCookieProbe=null;
    const probeEvidence=db=>latestCompleteCookieProbe||completeCookieProbe(db.lastCookieProbe)||completeCookieProbe(db.lastCompleteCookieProbe);
    const currentSwitchBlocker=db=>probeSwitchBlocker(probeEvidence(db));
    const canRecoverAttributes=db=>{try{if(!db.pending)return false;const recovery=validateRecovery(db.pending);return db.pending.allowConflictingSnapshot===true||uniqueContent(recovery.snapshot);}catch(_){return false;}};
    const metadata=db=>({...baseMetadata(db),switchBlocker:currentSwitchBlocker(db),canUseNativeAttributeCompatibility:!db.pending&&profileHealth(db).valid.length>0,canUseNativeAttributeRecovery:canRecoverAttributes(db)});
    const extensionVersion=()=>{try{const value=api.native?.runtime?.getManifest?.().version;return typeof value==='string'&&/^\d+(\.\d+){1,3}$/.test(value)?value:null;}catch(_){return null;}};
    const stalled = new Set();
    const operationStatus = () => ({busy, stalled:stalled.size > 0,
      message:stalled.size ? '瀏覽器操作逾時，仍未確認結束。請稍後重新整理；若持續沒有回覆，請完整關閉 Orion 再開啟管理器，並依提示復原。' : busy ? '背景仍在處理操作，請稍後重新整理。' : null});
    function call(path, ...args) {
      if(currentAttempt&&['cookies.set','cookies.remove'].includes(path)) currentAttempt.mutated=true;
      const mutation = ['storage.local.set','cookies.set','cookies.remove','tabs.remove','tabs.create','tabs.update'].includes(path);
      const token = {};
      return new Promise((resolve,reject) => {
        const timer = setTimeout(() => {
          if (mutation) stalled.add(token);
          const error = fail(mutation ? '瀏覽器操作逾時，結果尚未確認。已暫停後續變更；請稍後重新整理，持續無回覆時完整關閉 Orion 再開啟並依提示復原。' : '瀏覽器讀取逾時，已停止本次操作。請重新整理後再試。');
          error.apiTimeout = true;
          error.mutationUncertain = mutation;
          reject(error);
        }, apiTimeoutMs);
        // A timeout cannot cancel a native write. Quarantine mutations until its actual settlement.
        Promise.resolve().then(() => api.call(path,...args)).then(value => {
          clearTimeout(timer); stalled.delete(token); resolve(value);
        }, error => { clearTimeout(timer); stalled.delete(token); reject(error); });
      });
    }
    async function read() {
      const result = await call('storage.local.get', KEY);
      if (!result || typeof result !== 'object' || Array.isArray(result)) throw fail('瀏覽器沒有確認帳號庫讀取結果，請重新整理或更新 Orion；尚未覆寫資料。');
      if (!Object.prototype.hasOwnProperty.call(result,KEY)) return empty();
      const db = result[KEY];
      if (!db || db.version !== 1 || !Array.isArray(db.profiles)) throw fail('儲存的資料格式無法辨識；已停止操作。');
      return db;
    }
    const quota = api.native?.storage?.local?.QUOTA_BYTES;
    const storageBudget = Math.min(5 * 1024 * 1024, Number.isFinite(quota) && quota > 0 ? quota : Infinity);
    async function write(db) {
      if (stalled.size) throw fail(operationStatus().message);
      if (byteSize({[KEY]: db}) > storageBudget) throw fail('資料超過本版的本機儲存預算，請減少匯入數量或 Cookie 資料。切換還需要保留復原紀錄的空間。');
      try { await call('storage.local.set', {[KEY]: db}); }
      catch (error) {
        if (error.apiTimeout) throw error;
        // A rejected acknowledgement can still follow a successful commit.
        try { if (JSON.stringify(await read()) === JSON.stringify(db)) return; } catch (_) { /* Keep the original safe storage failure. */ }
        throw fail('本機儲存未能確認成功，可能是空間不足。請重新整理查看結果；匯入可按原內容重試，避免重複新增。');
      }
    }
    function rememberAttempt(db,attempt) {
      attempt.at=now();
      latestAttempt=copy(attempt);db.lastAttempt=copy(attempt);
      if(attempt.mutated) {latestMutatedAttempt=copy(attempt);db.lastMutatedAttempt=copy(attempt);}
    }
    function captureFailure(attempt,error) {
      attempt.status='failed';attempt.at=now();
      attempt.message=safeErrorText(error,'瀏覽器操作未完成，原始錯誤可能含私密資料，未直接顯示。');
      if(error?.[SAFE_ERROR]&&error.attemptDetails) {
        if(error.attemptDetails.verification)attempt.verification=copy(error.attemptDetails.verification);
        if(error.attemptDetails.cookieWrite)attempt.cookieWrite=copy(error.attemptDetails.cookieWrite);
      }
      if(attempt.mutated&&attempt.recovery.status==='not_needed')attempt.recovery={status:'pending',message:'尚未確認復原結果。'};
      latestAttempt=copy(attempt);if(attempt.mutated)latestMutatedAttempt=copy(attempt);
    }
    async function persistAttempt(attempt) {
      if(stalled.size)return;
      try {const saved=await read();rememberAttempt(saved,attempt);if(saved.pending&&attempt.status==='failed')saved.lastResult={status:'pending',message:attempt.message,at:now()};await write(saved);}catch(_){/* Keep the in-memory cause without bypassing quarantine. */}
    }
    async function abandonPending(db) {
      const pending=db.pending;
      if(!pending)throw fail('目前沒有需要停止的復原。');
      if(!Array.isArray(pending.domains)||pending.domains.some(domain=>typeof domain!=='string'||!domain)||
          (pending.previousActiveScope!==undefined&&(!Array.isArray(pending.previousActiveScope)||pending.previousActiveScope.some(domain=>typeof domain!=='string'||!domain))))throw fail('復原紀錄的網站範圍損壞，請保留原始匯出檔與錯誤訊息。');
      db.lastAbandonedRecovery=copy(pending); // Preserve the old journal locally; never send its contents to the UI.
      db.activeId=null;db.activeCookieRevision=null;
      db.activeScope=unique([...(db.activeScope||[]),...(pending.previousActiveScope||[]),...pending.domains]);
      db.activeStoreId=pending.storeId??pending.previousStoreId??db.activeStoreId;
      db.pending=false; // Use an explicit Boolean across native bridges, not a nullable field.
      db.lastResult={status:'abandoned',message:'已停止復原並保留目前 Cookie。可重新套用帳號；下次會先清理相關舊 Cookie。',at:now()};
      await write(db);
      if((await read()).pending)throw fail('瀏覽器尚未確認解除待復原狀態，請重新整理後再試。');
    }
    function recoverAttempt(db,status,message) {
      if(!db.lastAttempt)return;
      const attempt=copy(db.lastAttempt);
      if(attempt.status==='running') {attempt.status='failed';attempt.message='上次切換中斷；原始錯誤未能完成儲存。';}
      attempt.recovery={status,message};rememberAttempt(db,attempt);
    }
    async function runSwitch(db,message,context) {
      const version=extensionVersion()||'unknown';
      const attempt={attemptId:'attempt-'+now()+'-'+(++attemptSequence),profileId:message.id,version,startedAt:now(),at:now(),status:'running',stage:'preflight',message:'切換前檢查進行中。',compatibilityUsed:message.allowMissingNativeExpiry===true||message.allowNativeAttributeMismatch===true,attributeCompatibilityUsed:message.allowNativeAttributeMismatch===true,mutated:false,recovery:{status:'not_needed',message:'尚未修改 Cookie，無需復原。'}};
      currentAttempt=attempt;
      try {
        const attributeCompatibility=requestAttributeCompatibility(message),compatibility=requestCompatibility(message)||attributeCompatibility,blocker=currentSwitchBlocker(db);
        const target=db.profiles.find(profile=>profile?.id===message.id);
        const reopenOnly=db.activeAttributeLimited===true&&db.activeId===message.id&&target&&target.cookieRevision===db.activeCookieRevision;
        if(blocker&&!attributeCompatibility&&!reopenOnly)throw fail(blocker.message);
        return await switchProfile(db,message.id,context,compatibility,attempt,attributeCompatibility);
      }
      catch(error) {if(attempt.status!=='failed')captureFailure(attempt,error);await persistAttempt(attempt);throw error;}
      finally {currentAttempt=null;}
    }
    function normalizeProfile(input, existing) {
      if (!input || typeof input.name !== 'string' || !input.name.trim() || input.name.trim().length > 100 || /[\u0000-\u001f\u007f]/.test(input.name)) throw fail('請輸入 1–100 字的帳號名稱，且不可含控制字元。');
      let startUrl, parsed;
      try {
        startUrl = C.validateUrl(input.startUrl);
        parsed = input.cookies === undefined && existing ? {cookies: existing.cookies} : C.parseImport(JSON.stringify(input.cookies), {fallbackUrl: startUrl, now: now()});
      } catch (_) { throw fail('網址或 Cookie 資料無效，請檢查匯入預覽。'); }
      return {id: existing ? existing.id : id(), name: input.name.trim().normalize('NFC'), startUrl,
        cookies: parsed.cookies, domains: C.profileDomains(parsed.cookies, startUrl), updatedAt: now(),
        cookieRevision: input.cookies === undefined && existing ? existing.cookieRevision : id()};
    }
    function checkName(profile, profiles) {
      if (profiles.some(p => p?.id !== profile.id && typeof p?.name === 'string' && B.nameKey(p.name) === B.nameKey(profile.name))) {
        throw fail('帳號名稱已存在，請修改名稱後再儲存；不會自動覆蓋既有帳號。');
      }
    }
    async function bulkSave(db, message) {
      if (typeof message.requestId !== 'string' || !/^[A-Za-z0-9_-]{8,100}$/.test(message.requestId)) throw fail('批次識別碼無效，請重新建立匯入預覽。');
      if (!Array.isArray(message.profiles) || !message.profiles.length || message.profiles.length > 100) throw fail('每批請選取 1–100 個帳號。');
      if (byteSize(message.profiles) > 12 * 1024 * 1024) throw fail('這批資料過大，請分批匯入。');
      const bytes = new TextEncoder().encode(JSON.stringify(message.profiles));
      let digest;
      try { digest = Array.from(new Uint8Array(await boundedRead(root.crypto.subtle.digest('SHA-256', bytes))), b => b.toString(16).padStart(2, '0')).join(''); }
      catch (_) { throw fail('此裝置無法完成批次資料核對，請使用單筆匯入或更新 Orion。'); }
      const receipt = (db.bulkReceipts || []).find(r => r.requestId === message.requestId);
      if (receipt) {
        if (receipt.digest !== digest) throw fail('這個批次識別碼已用於不同內容，請重新預覽再匯入。');
        return {...metadata(db), importedCount: receipt.count, replayed: true};
      }
      const candidates = [];
      for (let index = 0; index < message.profiles.length; index++) {
        const input = message.profiles[index];
        if (input?.id !== undefined) throw fail('批量匯入只新增帳號，不接受覆蓋既有帳號的編號。');
        try {
          const profile = normalizeProfile(input);
          checkName(profile, [...db.profiles, ...candidates]);
          candidates.push(profile);
        } catch (error) { throw fail('第 ' + (index + 1) + ' 個選取帳號：' + safeErrorText(error,'資料無效。') + ' 本批尚未儲存。'); }
      }
      db.profiles.push(...candidates);
      db.bulkReceipts = [...(db.bulkReceipts || []), {requestId: message.requestId, digest, count: candidates.length, at: now()}].slice(-20);
      db.lastResult = {status:'imported', message:'已批量新增 ' + candidates.length + ' 個帳號，尚未切換瀏覽器 Cookie。', at:now()};
      await write(db); // One account-library write, including the receipt; never partial per-profile commits.
      return {...metadata(db), importedCount:candidates.length, replayed:false};
    }
    async function saveProfile(db, message) {
      let digest;
      if (message.requestId !== undefined) {
        if (typeof message.requestId !== 'string' || !/^[A-Za-z0-9_-]{8,100}$/.test(message.requestId)) throw fail('儲存識別碼無效，請重新開啟編輯畫面。');
        try { digest = Array.from(new Uint8Array(await boundedRead(root.crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(message.profile))))),b=>b.toString(16).padStart(2,'0')).join(''); }
        catch (_) { throw fail('此裝置無法核對儲存資料，請更新 Orion 後再試。'); }
        const receipt = (db.saveReceipts || []).find(r=>r.requestId===message.requestId);
        if (receipt) {
          if (receipt.digest !== digest) throw fail('這個儲存識別碼已用於不同內容，請重新預覽後再儲存。');
          return {...metadata(db),savedProfileId:receipt.profileId,replayed:true};
        }
      }
      const input = message.profile;
      const existing = input?.id && db.profiles.find(p=>p?.id===input.id);
      if (input?.id && !existing) throw fail('找不到要編輯的帳號。');
      const profile = normalizeProfile(input,existing);
      checkName(profile,db.profiles);
      if (existing) db.profiles[db.profiles.indexOf(existing)] = profile;
      else db.profiles.push(profile);
      if (digest) db.saveReceipts = [...(db.saveReceipts || []),{requestId:message.requestId,digest,profileId:profile.id,at:now()}].slice(-20);
      await write(db);
      return {...metadata(db),savedProfileId:profile.id,replayed:false};
    }
    async function inspectSwitch(db, profileId) {
      const switchBlocker=currentSwitchBlocker(db);
      const target = profileHealth(db).valid.find(profile=>profile.id===profileId);
      if (!target) throw fail('找不到可檢查的帳號，請重新整理帳號清單。');
      const targetHost = new URL(C.validateUrl(target.startUrl)).hostname;
      const targetCookies = target.cookies.filter(cookie=>appliesToTarget(cookie,targetHost));
      const imported = cookieAudit(target.cookies,now(),true);
      const importedTarget = cookieAudit(targetCookies,now(),false);
      const domains = C.profileDomains(target.cookies,target.startUrl);
      const scopes = unique([...(db.activeScope || []),...C.profileDomains(unexpired(target.cookies),target.startUrl),...(Array.isArray(db.pending?.domains)?db.pending.domains:[])]);
      const summary = {profileCookieCount:target.cookies.length,profileDomainCount:domains.length,targetHost,
        targetCookieCount:targetCookies.length,otherCookieCount:target.cookies.length-targetCookies.length,
        nativeCookieCount:0,nativeIssueCount:0,importedIssueCount:imported.invalid,
        missingNativeExpiryCount:0,canUseMissingExpiryCompatibility:false,compatibilityAction:db.pending?'recover':'switch',
        canUseNativeAttributeCompatibility:!db.pending,
        expiredCookieCount:target.cookies.length-unexpired(target.cookies).length,
        canUseNativeAttributeRecovery:canRecoverAttributes(db),
        canCreateSiteCopy:!db.pending&&targetCookies.length>0&&targetCookies.length<target.cookies.length&&importedTarget.invalid===0};
      const checks = [{label:'匯入帳號範圍',status:targetCookies.length?'passed':'warning',detail:target.cookies.length+' 筆 Cookie、'+domains.length+' 個網域；其中 '+targetCookies.length+' 筆適用於指定網站，'+summary.otherCookieCount+' 筆屬於其他網域。'}];
      checks.push(...auditChecks('匯入帳號／',imported,false));
      if(summary.expiredCookieCount)checks.push({label:'匯入帳號／有效期限',status:'warning',detail:summary.expiredCookieCount+' 筆 Cookie 已過期，將直接略過，不阻擋相容開啟。若沒有有效項目，會清理相關舊 Cookie 後開啟網站，不標示為已套用帳號。'});
      if(switchBlocker)checks.push({label:'上次完整裝置測試',status:'failed',detail:switchBlocker.message});
      if (db.pending) checks.push({label:'待復原的切換',status:'failed',detail:'上次切換尚未完成。本次僅供檢查；請先復原，或明確選擇停止復原並保留目前 Cookie。此狀態不能建立副本或再次切換。'});
      if (summary.otherCookieCount) checks.push({label:'建立指定網站副本',status:'warning',detail:'可另外建立僅含指定網站 Cookie 的帳號；原帳號保留。副本不包含其他網域的跨站登入狀態，建立副本也不會套用 Cookie。'});
      if (db.activeScope?.length) checks.push({label:'先前已套用帳號範圍',status:'warning',detail:'切換仍需一起檢查及清理先前套用的網站範圍；建立網站副本不會解除這項責任，也不會清除目前 Cookie。'});
      if (!targetCookies.length) checks.push({label:'指定網站 Cookie',status:'warning',detail:'此帳號沒有適用於指定網站的 Cookie，無法建立網站副本；請檢查起始網址及匯出來源。'});
      try {
        requireAPIs(['cookies.getAll']);
        // A diagnostic timeout ends the lock before a slow native read settles.
        // Keep its store binding local so that a late reply cannot affect the
        // next switch's currentStoreId.
        const inspectionStoreId=db.pending?.storeId ?? ((db.activeId || db.activeScope?.length) ? db.activeStoreId : undefined);
        const all = await boundedRead(call('cookies.getAll',inspectionStoreId===undefined ? {} : {storeId:inspectionStoreId}));
        if (!Array.isArray(all)) throw new Error('Invalid cookie list');
        const stores=[...new Set(all.map(cookie=>cookie?.storeId).filter(store=>store!==undefined))];
        if (stores.length>1 || (inspectionStoreId!==undefined&&stores.some(store=>store!==inspectionStoreId))) throw new Error('Inconsistent cookie store');
        let unknownScope=0;
        const selected=all.filter(cookie=>{
          try { return nativeInScope(cookie,scopes); } catch (_) { unknownScope++; return true; }
        });
        const native = cookieAudit(selected,now(),true);
        summary.nativeCookieCount=selected.length;
        summary.nativeIssueCount=native.invalid;
        summary.missingNativeExpiryCount=selected.filter(hasMissingNativeExpiry).length;
        checks.push({label:'瀏覽器目前 Cookie／讀取',status:'passed',detail:'已讀取相關切換範圍內 '+selected.length+' 筆 Cookie；未顯示名稱、值、路徑或網域。'});
        checks.push(...auditChecks('瀏覽器目前 Cookie／',native,true));
        if (unknownScope) checks.push({label:'瀏覽器目前 Cookie／範圍',status:'failed',detail:unknownScope+' 筆無法判定所屬範圍，已納入檢查，切換會停止。'});
        if (!unknownScope) {
          try {
            assertRemovable(all,scopes);
            checks.push({label:'瀏覽器目前 Cookie／清除範圍',status:'passed',detail:'未發現會影響其他範圍的同名清除衝突。'});
            const compatible=selected.every(cookie=>{try {portable(cookie,'preflight',true);return true;}catch(_){return false;}});
            let ready=imported.invalid===0&&summary.expiredCookieCount===0;
            if(db.pending) { try { validateRecovery(db.pending); ready=true; } catch(_){ready=false;} }
            summary.canUseMissingExpiryCompatibility=(!switchBlocker||Boolean(db.pending))&&(summary.missingNativeExpiryCount>0||db.pending?.allowMissingNativeExpiry===true||db.nativeExpiryLimitationObserved===true||observedMissingNativeExpiry)&&compatible&&ready;
          }
          catch (_) { checks.push({label:'瀏覽器目前 Cookie／清除範圍',status:'failed',detail:'無法確認能完整且僅清除相關範圍；未修改任何 Cookie。'}); }
        }
        if(summary.canUseMissingExpiryCompatibility||summary.missingNativeExpiryCount||db.pending?.allowMissingNativeExpiry===true) checks.push({label:'原生到期日缺漏相容處理',status:'warning',detail:(summary.missingNativeExpiryCount?summary.missingNativeExpiryCount+' 筆原生 Cookie 回報 session=false，但所有到期日欄位都不存在。':'先前曾觀察到原生期限限制；仍需每次明確確認，沒有全域啟用。')+(summary.canUseMissingExpiryCompatibility?'可明確確認後僅對這次'+(db.pending?'復原':'切換')+'啟用相容處理。 ':'目前仍有其他問題，不能以相容處理繼續。 ')+'若使用相容處理，仍會核對 Cookie 內容與其他屬性，但瀏覽器未提供的期限無法核對；僅回報工作階段時，關閉瀏覽器後可能需要再次套用。 '+BACKUP_WARNING});
      } catch (_) { checks.push({label:'瀏覽器目前 Cookie／讀取',status:'failed',detail:'未能在時限內確認相關 Cookie 清單或儲存區；請重新整理後重試，或更新 Orion。'}); }
      return {summary,checks,switchBlocker,lastAttempt:db.lastAttempt||null,lastMutatedAttempt:db.lastMutatedAttempt||null,note:'本次未修改帳號、Cookie 或分頁。檢查通過不代表網站一定接受登入；網站副本不包含其他網域的跨站登入狀態。'};
    }
    async function siteCopy(db,message) {
      if (message.confirm !== true) throw fail('請先確認建立網站副本；副本不包含其他網域的跨站登入狀態。');
      if (typeof message.requestId !== 'string' || !/^[A-Za-z0-9_-]{8,100}$/.test(message.requestId)) throw fail('副本識別碼無效，請重新開啟檢查畫面。');
      const receipt=(db.siteCopyReceipts || []).find(item=>item.requestId===message.requestId);
      if (receipt) {
        if (receipt.sourceId!==message.id) throw fail('這個副本識別碼已用於其他帳號，請重新開啟檢查畫面。');
        if (!db.profiles.some(profile=>profile?.id===receipt.profileId)) throw fail('先前建立的副本已被移除，請重新開啟檢查畫面後再建立。');
        return {...metadata(db),savedProfileId:receipt.profileId,copiedCookieCount:receipt.count,excludedCookieCount:receipt.excludedCount,replayed:true};
      }
      const source=profileHealth(db).valid.find(profile=>profile.id===message.id);
      if (!source) throw fail('找不到可複製的帳號，請重新整理。');
      const targetHost=new URL(C.validateUrl(source.startUrl)).hostname;
      const cookies=source.cookies.filter(cookie=>appliesToTarget(cookie,targetHost));
      if (!cookies.length) throw fail('此帳號沒有適用於指定網站的 Cookie，無法建立空白副本。');
      try { cookies.forEach(cookie=>C.normalizeCookie(cookie,{now:now()})); }
      catch (_) { throw fail('指定網站的 Cookie 已過期或格式不相容，請重新匯入後再建立副本。'); }
      const used=new Set(db.profiles.filter(profile=>typeof profile?.name==='string').map(profile=>B.nameKey(profile.name)));
      let name;
      for (let n=1;n<=1000;n++) {
        const suffix='（指定網站'+(n===1?'':' '+n)+'）';
        const candidate=source.name.slice(0,100-suffix.length)+suffix;
        if (!used.has(B.nameKey(candidate))) { name=candidate; break; }
      }
      if (!name) throw fail('網站副本名稱已使用過多次，請先整理帳號名稱。');
      const profile=normalizeProfile({name,startUrl:source.startUrl,cookies});
      checkName(profile,db.profiles);
      db.profiles.push(profile);
      const excludedCount=source.cookies.length-cookies.length;
      db.siteCopyReceipts=[...(db.siteCopyReceipts || []),{requestId:message.requestId,sourceId:source.id,profileId:profile.id,count:cookies.length,excludedCount,at:now()}].slice(-20);
      db.lastResult={status:'copied',message:'已建立指定網站副本，保留原帳號；尚未套用 Cookie。副本不包含其他網域的跨站登入狀態。',at:now()};
      await write(db);
      return {...metadata(db),savedProfileId:profile.id,copiedCookieCount:cookies.length,excludedCookieCount:excludedCount,replayed:false};
    }
    async function diagnostics() {
      const checks = REQUIRED.map(name => ({name, available:api.available(name), status:api.available(name) ? 'present' : 'failed'}));
      if (busy || stalled.size) return {checks:[...checks,{name:'operationState',available:true,status:'warning',detail:operationStatus().message}],operation:operationStatus(),note:'未修改 Cookie 或帳號資料。'};
      const results = await Promise.allSettled([
        boundedRead(read()), boundedRead(call('cookies.getAll', {})), boundedRead(call('tabs.query', {}))
      ]);
      const dbResult = results[0];
      checks.push({name:'storageReadTest',available:true,status:dbResult.status==='fulfilled'?'passed':'failed',detail:dbResult.status==='fulfilled'?'已實際讀取本機帳號庫。':'無法讀取帳號庫；未嘗試修改資料。'});
      if (dbResult.status === 'fulfilled') {
        const db = dbResult.value;
        let expired = 0, invalid = 0, duplicate = 0;
        const ids = new Set(), names = new Set();
        for (const profile of db.profiles) {
          try {
            if (!profile || typeof profile.name !== 'string' || !profile.name.trim() || typeof profile.id !== 'string' || !profile.id) throw new Error();
            const key = B.nameKey(profile.name);
            if (ids.has(profile.id) || names.has(key)) duplicate++;
            ids.add(profile.id); names.add(key);
            C.validateUrl(profile.startUrl);
            if (!Array.isArray(profile.cookies) || !profile.cookies.length) throw new Error();
            for (const cookie of profile.cookies) {
              try { C.normalizeCookie(cookie,{now:now()}); }
              catch (error) { if(error.code==='COOKIE_EXPIRED') expired++; else throw error; }
            }
          } catch (_) { invalid++; }
        }
        checks.push({name:'profileHealth',available:true,status:invalid||duplicate?'failed':expired?'warning':'passed',detail:db.profiles.length+' 個帳號；'+invalid+' 個格式異常，'+duplicate+' 個識別或名稱重複，'+expired+' 筆已過期 Cookie。'});
        checks.push({name:'recoveryState',available:true,status:db.pending?'warning':'passed',detail:db.pending?'有尚未完成的切換，請先復原。':'沒有待復原的切換。'});
        const activeExists = !db.activeId || db.profiles.some(p=>p?.id===db.activeId);
        checks.push({name:'activeAccountState',available:true,status:activeExists?'passed':'failed',detail:activeExists?'目前帳號參照一致。':'目前帳號參照不存在，請停止切換並檢查資料。'});
        const bytes = byteSize({[KEY]:db});
        checks.push({name:'storageBudget',available:true,status:bytes>storageBudget*0.75?'warning':'passed',detail:'帳號庫約 '+Math.ceil(bytes/1024)+' KB／本版預算 '+Math.floor(storageBudget/1024)+' KB；切換時還需備份空間。'});
      }
      for (const [index,name,label] of [[1,'cookieReadTest','Cookie'],[2,'tabsReadTest','分頁清單']]) {
        const result=results[index]; const passed=result.status==='fulfilled'&&Array.isArray(result.value);
        checks.push({name,available:true,status:passed?'passed':'failed',detail:passed?'已實際讀取'+label+'，不顯示其內容。':'讀取'+label+'失敗；未修改瀏覽器資料。'});
      }
      if (results[1].status==='fulfilled'&&Array.isArray(results[1].value)) {
        const native=cookieAudit(results[1].value,now(),true);
        checks.push({name:'nativeCookieCompatibility',available:true,status:native.invalid?'warning':'passed',detail:results[1].value.length+' 筆原生 Cookie；'+native.invalid+' 筆屬性不相容。'+(native.invalid?'各帳號請再執行「檢查切換」，確認是否位於相關網站範圍。':'未發現不相容屬性。')});
        for (const [detail,count] of native.counts) checks.push({name:'nativeCookieReason',available:true,status:'warning',detail:count+' 筆：'+detail});
      }
      try {
        const result = B.parseSources([{name:'self-check.json',text:JSON.stringify([{name:'check',value:'fixture',domain:'example.test',path:'/',secure:true}])}],{defaultUrl:'https://example.test/'});
        if(result.counts.valid!==1)throw new Error();
        checks.push({name:'bulkParserTest',available:true,status:'passed',detail:'已使用內建假資料驗證批量解析；未儲存帳號。'});
      } catch (_) { checks.push({name:'bulkParserTest',available:true,status:'failed',detail:'批量格式自測未通過。'}); }
      checks.push({name:'identitySupport',available:typeof root.crypto?.randomUUID==='function'&&typeof root.crypto?.subtle?.digest==='function',status:typeof root.crypto?.randomUUID==='function'&&typeof root.crypto?.subtle?.digest==='function'?'passed':'failed',detail:'新增與重試核對需要裝置支援安全識別碼及摘要功能。'});
      return {checks,note:'本次只讀取與檢查，不修改帳號或 Cookie。寫入與還原會在切換時驗證；網站登入、指紋與其他儲存隔離仍不在此檢查範圍。'};
    }
    function requireAPIs(required = REQUIRED) {
      const missing = required.filter(name => !api.available(name));
      if (missing.length) throw fail('這個 Orion 版本缺少必要功能：' + missing.join('、') + '。尚未修改 Cookie。');
    }
    async function allCookies() {
      const result = await call('cookies.getAll', currentStoreId === undefined ? {} : {storeId: currentStoreId});
      if (!Array.isArray(result)) throw fail('瀏覽器沒有傳回有效的 Cookie 清單；已停止操作。');
      const stores = [...new Set(result.map(c => c?.storeId).filter(s => s !== undefined))];
      if (stores.length > 1 || (currentStoreId !== undefined && stores.some(s => s !== currentStoreId))) {
        throw fail('Cookie 儲存區與目前操作環境不一致，已停止切換。');
      }
      if (currentStoreId === undefined && stores.length === 1) currentStoreId = stores[0];
      return result;
    }
    function requestCompatibility(message) {
      if(owns(message,'allowMissingNativeExpiry')&&typeof message.allowMissingNativeExpiry!=='boolean') throw fail('到期日相容處理的確認格式無效，請重新檢查並明確確認。');
      return message.allowMissingNativeExpiry===true;
    }
    function requestAttributeCompatibility(message) {
      if(owns(message,'allowNativeAttributeMismatch')&&typeof message.allowNativeAttributeMismatch!=='boolean')throw fail('屬性相容套用的確認格式無效，請重新選擇相容套用並開啟。');
      return message.allowNativeAttributeMismatch===true;
    }
    function portable(cookie, phase='preflight', allowMissingNativeExpiry=false,allowNativeAttributeMismatch=false) {
      try {
        const missing=hasMissingNativeExpiry(cookie);
        if(missing) observedMissingNativeExpiry=true;
        const unknown=allowMissingNativeExpiry===true&&missing;
        const normalize=allowNativeAttributeMismatch?C.normalizeNativeCookie:C.normalizeCookie;
        let normalized;
        try {normalized=normalize(unknown?{...cookie,session:true}:cookie, {now: now(), allowExpired: true});}
        catch(error) {
          // Attribute compatibility already cannot promise lifetime metadata.
          // A well-typed native session/expiry contradiction must not block
          // every subsequent switch. Validation reaches this code only after
          // all expiry values have parsed and agreed; malformed or mutually
          // conflicting dates still fail. Preserve the live content as a
          // temporary session backup instead of inventing a lifetime.
          if(!allowNativeAttributeMismatch||error?.code!=='SESSION_EXPIRY_CONFLICT')throw error;
          const temporary={...cookie,session:true};for(const field of EXPIRY_FIELDS)delete temporary[field];
          normalized=normalize(temporary,{now:now(),allowExpired:true});normalized.nativeExpiryUnknown=true;
          observedMissingNativeExpiry=true;
        }
        if(unknown) normalized.nativeExpiryUnknown=true;
        if(allowNativeAttributeMismatch&&normalized.sameSite==='no_restriction'&&normalized.secure===false)normalized.nativeSameSiteDefaultUnknown=true;
        return normalized;
      }
      catch (error) {
        const stages={preflight:'瀏覽器目前的 Cookie 在切換前檢查不相容',clearing:'切換清除階段的 Cookie 檢查不相容',verification:'套用後讀回的 Cookie 屬性不相容',restoreClearing:'復原清除階段的 Cookie 檢查不相容',restoreVerification:'復原後讀回的 Cookie 屬性不相容'};
        throw fail((stages[phase] || stages.verification)+'：'+reason(error)+(phase==='preflight'?' 尚未修改 Cookie；請執行帳號的「檢查切換」。':' 已停止目前階段；請依管理頁的復原狀態處理。'));
      }
    }
    function nativeInScope(cookie,scopes,phase='preflight') {
      try {
        if (!cookie || typeof cookie!=='object' || typeof cookie.domain!=='string' || !cookie.domain) throw new Error();
        // A malformed hostOnly value must not make a relevant parent disappear
        // from preflight. Include it conservatively; portable() then rejects it.
        return inScope(typeof cookie.hostOnly!=='boolean' ? {...cookie,hostOnly:false} : cookie,scopes);
      } catch (_) {
        const stage=phase==='preflight'?'切換前':phase==='clearing'?'切換清除階段':phase==='verification'?'套用後讀回':phase==='restoreClearing'?'復原清除階段':'復原後讀回';
        throw fail(stage+'的瀏覽器 Cookie 網域或範圍無法辨識。'+(phase==='preflight'?'尚未修改 Cookie；請執行帳號的「檢查切換」。':'已停止目前階段；請依管理頁的復原狀態處理。'));
      }
    }
    function unexpired(cookies) {
      return cookies.filter(c => c.session || !Number.isFinite(c.expirationDate) || c.expirationDate > now() / 1000);
    }
    async function prepareRelated(scopes, bestEffort = false) {
      try {
        const count = await closeRelated(scopes, bestEffort);
        if(currentAttempt)currentAttempt.tabPreparation={status:tabStopUnconfirmed?'unconfirmed':'confirmed'};
        return count;
      } catch(error) {
        // Tab-list accuracy is not a prerequisite for editing a shared cookie
        // jar. In the requested compatibility mode, rely on the subsequent
        // clear/write/readback transaction, not a desktop-only tab invariant.
        // An unsettled mutation still cannot race a new transaction.
        if(!bestEffort || error.apiTimeout || error.mutationUncertain || stalled.size)throw error;
        tabStopUnconfirmed=true;
        if(currentAttempt)currentAttempt.tabPreparation={status:'unconfirmed'};
        return 0;
      }
    }
    async function closeRelated(scopes, bestEffort = false) {
      const seen = new Set();
      const parking = new Set();
      let verifyIndividual = false;
      async function readTabs() {
        const tabs=await call('tabs.query',{});
        if(!Array.isArray(tabs))throw fail('無法確認已開啟的分頁，已停止切換。');
        if(!verifyIndividual || !api.available('tabs.get'))return tabs;
        const checked=[];
        for(const tab of tabs){
          if(!Number.isInteger(tab.id)||(!tabInScope(tab,scopes)&&!parking.has(tab.id))){checked.push(tab);continue;}
          try {
            const current=await call('tabs.get',tab.id);
            // Undefined or malformed native results are not proof of absence.
            checked.push(current&&current.id===tab.id&&typeof current.url==='string'&&typeof current.incognito==='boolean'?current:tab);
          } catch(error) {
            if(error.apiTimeout)throw error;
            // Only the API's explicit missing-ID response overrides a stale
            // listing. Unsupported APIs, permissions and unknown errors do not.
            if(!/^(?:No tab with id(?::|\s)|Invalid tab ID(?::|\s)|Invalid tab id(?::|\s)|Tab (?:with )?id \d+ (?:not found|does not exist))/i.test(String(error?.message||'')))checked.push(tab);
          }
        }
        return checked;
      }
      async function relatedTabs() {
        const tabs = await readTabs();
        if (!Array.isArray(tabs)) throw fail('無法確認已開啟的分頁，已停止切換。');
        const related = tabs.filter(tab => tabInScope(tab, scopes));
        if (related.some(tab => !Number.isInteger(tab.id))) throw fail('無法辨識相關分頁，已停止切換。');
        related.forEach(tab => seen.add(tab.id));
        return related;
      }
      async function remove(ids) {
        try { await call('tabs.remove', ids); }
        catch (error) {
          // A vanished tab or unsupported batch can reject. Re-query before
          // retrying; an unsettled native mutation must remain quarantined.
          if (error.apiTimeout || error.mutationUncertain) throw error;
        }
      }
      let remaining = await relatedTabs();
      if (!remaining.length) return 0;
      for (let round = 0; round < (bestEffort ? 1 : 3); round++) {
        if (round === 0) await remove(remaining.map(tab => tab.id));
        else {
          for (const tab of remaining) {
            // Never close an ID from an earlier query if it has moved out of
            // scope or become private in the meantime.
            if ((await relatedTabs()).some(current => current.id === tab.id)) await remove(tab.id);
          }
        }
        // Native closure and the tab listing can settle at different times.
        // Bound both retries and waits; do not write cookies while tabs remain.
        for (let poll = 0; poll < 5; poll++) {
          if (poll) await sleep(250);
          remaining = await relatedTabs();
          if (!remaining.length) return seen.size;
        }
      }
      // Some native bridges acknowledge removal without removing the page.
      // Stop that page by navigation instead, and verify completion separately:
      // tabs.update resolving is not evidence that the old document unloaded.
      // A query can retain closed-tab entries. Resolve surviving IDs directly
      // before attempting another navigation or deciding every account is blocked.
      verifyIndividual=true;
      remaining=await relatedTabs();
      if(!remaining.length)return seen.size;
      for (const tab of remaining) {
        if (!(await relatedTabs()).some(current => current.id === tab.id)) continue;
        try {
          await call('tabs.update', tab.id, {url:'about:blank'});
          parking.add(tab.id);
        } catch (error) {
          if (error.apiTimeout || error.mutationUncertain) throw error;
        }
      }
      for (let poll = 0; poll < (bestEffort ? 3 : 15); poll++) {
        if (poll) await sleep(250);
        const tabs = await readTabs();
        if (!Array.isArray(tabs)) throw fail('無法確認已開啟的分頁，已停止切換。');
        const stopped = [...parking].every(id => {
          const tab=tabs.find(item=>item.id===id);
          return !tab || (!tab.incognito && tab.url==='about:blank' && tab.status==='complete' && !tab.pendingUrl);
        });
        if (stopped && !tabs.some(tab=>tabInScope(tab,scopes))) {
          for (const id of parking) if(tabs.some(tab=>tab.id===id)) parkedTabIds.add(id);
          return seen.size-parking.size;
        }
      }
      throw fail('Orion 未能關閉或停止相關網頁，本次尚未套用帳號。請在分頁列表只保留帳號管理器後重試。');
    }
    async function clear(scopes, phase='clearing', allowMissingNativeExpiry=false,allowNativeAttributeMismatch=false,replacements=[]) {
      const summary={initialCount:0,remainingCount:0,removeCalls:0,removeEmptyReplies:0,removeErrors:0,expiryCalls:0,expiryErrors:0,polls:0,reappearedCount:0};
      if(currentAttempt)currentAttempt[phase==='restoreClearing'?'restoreClearingSummary':phase==='repairClearing'?'repairClearingSummary':'clearingSummary']=summary;
      let lastKeys=null;
      async function readRemaining() {
        const all=await allCookies();
        const cookies=all.filter(c=>nativeInScope(c,scopes,phase));
        cookies.forEach(c=>portable(c,phase,allowMissingNativeExpiry,allowNativeAttributeMismatch));
        assertRemovable(all,scopes,phase,allowNativeAttributeMismatch);
        const keys=new Set(cookies.map(contentKey));
        if(lastKeys)for(const key of keys)if(!lastKeys.has(key))summary.reappearedCount++;
        lastKeys=keys;summary.remainingCount=cookies.length;
        return cookies.sort((a,b)=>b.path.length-a.path.length);
      }
      // Native mutations may resolve before getAll reflects the new jar. Poll
      // before retrying a deletion, and require two empty reads to catch a page
      // immediately recreating a cookie. These waits are bounded, not a lock.
      async function settle() {
        let cookies=await readRemaining();
        for(let poll=0;poll<4;poll++) {
          const wasEmpty=!cookies.length;
          await sleep(150);summary.polls++;
          cookies=await readRemaining();
          if(wasEmpty&&!cookies.length)return cookies;
        }
        if(!cookies.length){await sleep(150);summary.polls++;cookies=await readRemaining();}
        return cookies;
      }
      let cookies=await readRemaining();summary.initialCount=cookies.length;
      if(!cookies.length)return;
      for(let pass=0;pass<3&&cookies.length;pass++) {
        const sent=new Set();
        for(const cookie of cookies) {
          const details={url:C.cookieUrl(allowNativeAttributeMismatch?{...cookie,secure:!(pass===2&&cookie.secure===false)}:cookie),name:cookie.name};
          if(cookie.storeId!==undefined)details.storeId=cookie.storeId;
          // Duplicate bridge rows need one request, followed by a fresh read.
          const key=JSON.stringify(details);if(sent.has(key))continue;sent.add(key);
          summary.removeCalls++;
          try {if(!await call('cookies.remove',details))summary.removeEmptyReplies++;}
          catch(error){if(error.apiTimeout||error.mutationUncertain||stalled.size||!allowNativeAttributeMismatch)throw error;summary.removeErrors++;}
        }
        cookies=await settle();
      }
      // Target only observed residual cookies; never clear all browsing data.
      // Expire the exact name/domain/path/store instead of repeating remove().
      // Keep the observed value if a broken bridge ignores expiration entirely.
      if(cookies.length&&allowNativeAttributeMismatch) {
        for(let pass=0;pass<3&&cookies.length;pass++) {
          const sent=new Set();
          for(const raw of cookies) {
            const c=portable(raw,phase,allowMissingNativeExpiry,true);
            const details={url:C.cookieUrl({...c,secure:true}),name:c.name,value:c.value,path:c.path,expirationDate:1};
            if(c.secure)details.secure=true;
            if(c.httpOnly)details.httpOnly=true;
            if(!c.hostOnly||raw.domain.startsWith('.'))details.domain=raw.domain.startsWith('.')?raw.domain:'.'+c.domain;
            // Some native bridges misreport hostOnly. Retry the exact observed
            // domain spelling, then its host-only form; never a parent/sibling.
            if(pass===1&&!c.name.startsWith('__Host-'))details.domain=raw.domain;
            if(pass===2)delete details.domain;
            if(raw.storeId!==undefined)details.storeId=raw.storeId;
            const key=JSON.stringify([details.url,details.name,details.domain,details.path,details.storeId]);
            if(sent.has(key))continue;sent.add(key);summary.expiryCalls++;
            try {await call('cookies.set',details);}
            catch(error){if(error.apiTimeout||error.mutationUncertain||stalled.size)throw error;summary.expiryErrors++;}
          }
          cookies=await settle();
        }
      }
      if(cookies.length) {
        const live=unexpired(replacements),keys=new Set(live.map(contentKey));
        summary.residualIdentityCount=new Set(cookies.map(contentKey)).size;
        summary.replaceableCount=cookies.filter(c=>keys.has(contentKey(c))).length;
        // A failed delete need not block replacing the exact same cookie. Only
        // proceed when EVERY residual has one live target name/domain/path.
        // install() still checks the full jar, including old duplicate values,
        // before committing an account or opening any website.
        if(allowNativeAttributeMismatch&&uniqueContent(live)&&summary.replaceableCount===cookies.length) {
          summary.overwriteDeferredCount=cookies.length;
          return;
        }
        throw fail('舊 Cookie 清除後仍讀到 '+cookies.length+' 筆，其中 '+(cookies.length-summary.replaceableCount)+' 筆無法由所選帳號對應覆寫，已停止套用新帳號。');
      }
    }
    function assertRemovable(all, scopes,phase='preflight',allowNativeAttributeMismatch=false) {
      const selected = all.filter(c => nativeInScope(c, scopes,phase));
      const protectedCookies = all.filter(c => !nativeInScope(c, scopes,phase));
      for (const cookie of selected) {
        const url = new URL(C.cookieUrl(allowNativeAttributeMismatch?{...cookie,secure:true}:cookie));
        const collision = protectedCookies.some(other => other.name === cookie.name &&
          (allowNativeAttributeMismatch || !other.secure || url.protocol === 'https:') &&
          (allowNativeAttributeMismatch ? C.domainMatches(url.hostname,other.domain) : other.hostOnly ? host(other.domain) === url.hostname : C.domainMatches(url.hostname, other.domain)) &&
          (url.pathname === other.path || (url.pathname.startsWith(other.path) && (other.path.endsWith('/') || url.pathname[other.path.length] === '/'))));
        if (collision) throw fail('相關 Cookie 與其他網站範圍有同名衝突，無法安全清除。'+(phase==='preflight'?'尚未修改 Cookie；請執行帳號的「檢查切換」。':'已停止目前清除階段；請依管理頁的復原狀態處理。'));
      }
    }
    function cookieDifferences(expected, actual,allowMissingNativeExpiry=false) {
      const differences=[];
      for (const field of ['value', 'secure', 'httpOnly', 'hostOnly']) {
        if (expected[field] !== actual[field]) differences.push(field);
      }
      if ((expected.sameSite || 'unspecified') !== (actual.sameSite || 'unspecified')) differences.push('sameSite');
      const sessionOnly=expected.session===false&&actual[NATIVE_SESSION_ONLY]===true;
      if(sessionOnly&&!differences.length)observedMissingNativeExpiry=true;
      if(actual.nativeExpiryUnknown!==true&&!(allowMissingNativeExpiry&&sessionOnly)) {
        if(expected.session!==actual.session) differences.push('session');
        if (!expected.session && (!Number.isFinite(actual.expirationDate) || Math.abs(expected.expirationDate - actual.expirationDate) > 2)) differences.push('expirationDate');
      }
      return differences;
    }
    async function verify(expected, scopes, phase='verification', allowMissingNativeExpiry=false,allowNativeAttributeMismatch=false) {
      const readback = mergeNativeDuplicates((await allCookies()).filter(c => nativeInScope(c, scopes,phase)).map(cookie=>{
        const normalized=portable(cookie,phase,allowMissingNativeExpiry,allowNativeAttributeMismatch);
        if(cookie.session===true&&EXPIRY_FIELDS.every(field=>!owns(cookie,field)))normalized[NATIVE_SESSION_ONLY]=true;
        return normalized;
      }),allowNativeAttributeMismatch);
      const live = unexpired(expected);
      const map = new Map(readback.map(c => [C.cookieKey(c), c]));
      const expectedKeys=new Set(live.map(C.cookieKey));
      const counts=new Map();let missingCount=0,temporarySessionCount=0;
      const exactPairs=[];
      for(const cookie of live) {
        const actual=map.get(C.cookieKey(cookie));
        if(!actual){missingCount++;continue;}
        exactPairs.push([cookie,actual]);
        const differences=cookieDifferences(cookie,actual,allowMissingNativeExpiry);
        for(const field of differences)counts.set(field,(counts.get(field)||0)+1);
        if(!differences.length&&cookie.session===false&&actual[NATIVE_SESSION_ONLY]===true)temporarySessionCount++;
      }
      const identity=identityDiagnostics(live,readback);
      const verification={expectedCount:live.length,actualCount:readback.length,missingCount,unexpectedCount:readback.filter(cookie=>!expectedKeys.has(C.cookieKey(cookie))).length,duplicateCount:readback.length-map.size,differences:[...counts].map(([field,count])=>({field,count})),temporarySessionCount,
        fieldTransitions:transitionCounts([...exactPairs,...identity.pairs]),identityMismatches:identity.summary};
      let contentValid=false;
      if(allowNativeAttributeMismatch) {
        const key=contentKey;
        const expectedMap=new Map(live.map(cookie=>[key(cookie),cookie])),actualMap=new Map(readback.map(cookie=>[key(cookie),cookie]));
        const content={expectedCount:live.length,actualCount:readback.length,matchedCount:0,missingCount:0,unexpectedCount:readback.filter(cookie=>!expectedMap.has(key(cookie))).length,duplicateCount:live.length-expectedMap.size+readback.length-actualMap.size,valueMismatchCount:0};
        for(const cookie of live){const actual=actualMap.get(key(cookie));if(!actual)content.missingCount++;else if(actual.value!==cookie.value)content.valueMismatchCount++;else content.matchedCount++;}
        verification.contentVerification=content;verification.attributeLimited=true;
        contentValid=content.expectedCount===content.actualCount&&!content.missingCount&&!content.unexpectedCount&&!content.duplicateCount&&!content.valueMismatchCount;
      }
      if (allowNativeAttributeMismatch?!contentValid:readback.length !== live.length || missingCount || verification.unexpectedCount || verification.duplicateCount || counts.size) {
        const content=verification.contentVerification;
        const error=fail(content?'Cookie 讀回檢查不一致：預期 '+content.expectedCount+' 筆，實際 '+content.actualCount+' 筆；內容相符 '+content.matchedCount+' 筆、缺少 '+content.missingCount+' 筆、多出 '+content.unexpectedCount+' 筆、重複 '+content.duplicateCount+' 筆、內容不同 '+content.valueMismatchCount+' 筆。':'Cookie 讀回檢查不一致：預期 '+live.length+' 筆，實際 '+readback.length+' 筆；缺少 '+missingCount+' 筆、多出 '+verification.unexpectedCount+' 筆、重複 '+verification.duplicateCount+' 筆，'+[...counts.values()].reduce((a,b)=>a+b,0)+' 個屬性差異。');
        error.attemptDetails={verification};throw error;
      }
      return {missingNativeExpiryCount:unknownExpiryCount(readback),temporarySessionCount,attributeLimited:allowNativeAttributeMismatch,verification};
    }
    async function install(cookies, scopes, phase='verification', allowMissingNativeExpiry=false,attempt=null,allowNativeAttributeMismatch=false) {
      const live = unexpired(cookies);
      const replyCounts={differences:new Map(),missingFieldCounts:new Map(),invalidFieldCounts:new Map()},replyTransitions=new Map();
      let receivedCount=0;
      const summarizeReply=(expected,result)=>{
        if(!attempt)return;
        const add=(group,field)=>replyCounts[group].set(field,(replyCounts[group].get(field)||0)+1);
        const actual={};
        if(result&&typeof result==='object'&&!Array.isArray(result)) {
          receivedCount++;
          for(const field of ['name','value','domain','path',...BOOLEAN_FIELDS,'sameSite','expirationDate']) {
            if(field==='expirationDate'&&expected.session)continue;
            if(!owns(result,field)){add('missingFieldCounts',field);continue;}
            let value=result[field],valid=true;
            if(BOOLEAN_FIELDS.includes(field))valid=typeof value==='boolean';
            else if(field==='sameSite') {
              if(typeof value==='string'){value=value.toLowerCase();if(value==='none')value='no_restriction';}
              valid=SAME_SITE_VALUES.includes(value);
            } else if(field==='expirationDate')valid=typeof value==='number'&&Number.isFinite(value);
            else valid=typeof value==='string';
            if(valid&&field==='domain'){try{value=C.normalizeCookie({name:'diagnostic',value:'',domain:value,path:'/'},{allowExpired:true}).domain;}catch(_){valid=false;}}
            if(!valid){add('invalidFieldCounts',field);continue;}
            actual[field]=value;
            if(field==='expirationDate'?Math.abs(value-expected[field])>2:value!==expected[field])add('differences',field);
          }
          for(const transition of transitionCounts([[expected,actual]])) {
            const key=JSON.stringify([transition.field,transition.from,transition.to]);
            const previous=replyTransitions.get(key);replyTransitions.set(key,{...transition,count:(previous?.count||0)+transition.count});
          }
        }
        attempt.writeReadbackSummary={requestedCount:live.length,receivedCount,...Object.fromEntries(Object.entries(replyCounts).map(([key,counts])=>[key,[...counts].map(([field,count])=>({field,count}))])),fieldTransitions:[...replyTransitions.values()]};
      };
      for (let index=0;index<live.length;index++) {
        const cookie=live[index];
        // Only recovery of a marked native snapshot can use the browser's
        // default SameSite for the inconsistent None + Secure=false report.
        // Imported target write intentions are never changed by this branch.
        const restoreDefault=phase==='restoreVerification'&&allowNativeAttributeMismatch&&cookie.nativeSameSiteDefaultUnknown===true;
        const details = C.toSetDetails(restoreDefault?{...cookie,sameSite:'unspecified'}:cookie);
        if (currentStoreId !== undefined) details.storeId = currentStoreId;
        let result;
        const writeFailure=(error,category,resultShape)=>{
          const failure=error?.[SAFE_ERROR]?error:fail('帳號內第 '+(index+1)+' 筆 Cookie 寫入未獲瀏覽器確認；共 '+live.length+' 筆 Cookie。');
          failure.attemptDetails={cookieWrite:{ordinal:index+1,total:live.length,category,...(resultShape?{resultShape}:{})}};return failure;
        };
        try {result=await call('cookies.set',details);}catch(error){throw writeFailure(error,error.apiTimeout?'native_timeout':'native_rejected');}
        summarizeReply(cookie,result);
        const shape={isObject:Boolean(result&&typeof result==='object'&&!Array.isArray(result)),hasName:Boolean(result&&owns(result,'name')),hasValue:Boolean(result&&owns(result,'value')),hasDomain:Boolean(result&&owns(result,'domain')),hasExpirationDate:Boolean(result&&owns(result,'expirationDate'))};
        if (!shape.isObject) throw writeFailure(null,'unconfirmed_result',shape);
        if (currentStoreId !== undefined && result.storeId !== undefined && result.storeId !== currentStoreId) throw writeFailure(fail('Cookie 寫入到不同的儲存區，已停止操作。'),'store_mismatch',shape);
        if (currentStoreId === undefined && result.storeId !== undefined) currentStoreId = result.storeId;
      }
      if(attempt)attempt.stage='verification';
      return await verify(live, scopes,phase,allowMissingNativeExpiry,allowNativeAttributeMismatch);
    }
    function validateRecovery(pending) {
      if (!pending || !['prepared','installing'].includes(pending.phase) || !Array.isArray(pending.snapshot) || !Array.isArray(pending.domains) || !pending.domains.length) throw new Error('Invalid recovery journal');
      if(owns(pending,'allowMissingNativeExpiry')&&typeof pending.allowMissingNativeExpiry!=='boolean') throw new Error('Invalid recovery consent');
      if(owns(pending,'allowNativeAttributeMismatch')&&typeof pending.allowNativeAttributeMismatch!=='boolean')throw new Error('Invalid attribute recovery consent');
      if(owns(pending,'previousAttributeLimited')&&typeof pending.previousAttributeLimited!=='boolean')throw new Error('Invalid previous attribute limitation');
      pending.domains.forEach(domain=>C.normalizeCookie({name:'scope',value:'',domain,path:'/'}));
      if(pending.tabDomains!==undefined) {
        if(!Array.isArray(pending.tabDomains)||!pending.tabDomains.length) throw new Error('Invalid recovery tab scope');
        pending.tabDomains.forEach(domain=>C.normalizeCookie({name:'scope',value:'',domain,path:'/'}));
      }
      const snapshot=pending.snapshot.map(cookie=>{
        const normalize=pending.allowNativeAttributeMismatch===true?C.normalizeNativeCookie:C.normalizeCookie;
        const normalized=normalize(cookie,{now:now(),allowExpired:true});
        if(owns(cookie,'nativeSameSiteDefaultUnknown')) {
          if(cookie.nativeSameSiteDefaultUnknown!==true||pending.allowNativeAttributeMismatch!==true||cookie.sameSite!=='no_restriction'||cookie.secure!==false)throw new Error('Invalid native SameSite marker');
          normalized.nativeSameSiteDefaultUnknown=true;
        } else if(normalized.sameSite==='no_restriction'&&!normalized.secure)throw new Error('Missing native SameSite marker');
        if(owns(cookie,'nativeExpiryUnknown')) {
          if(cookie.nativeExpiryUnknown!==true||pending.allowMissingNativeExpiry!==true||cookie.session!==true||EXPIRY_FIELDS.some(field=>owns(cookie,field))) throw new Error('Invalid unknown-expiry snapshot');
          normalized.nativeExpiryUnknown=true;
        }
        return normalized;
      });
      if(owns(pending,'allowConflictingSnapshot')&&(typeof pending.allowConflictingSnapshot!=='boolean'||pending.allowConflictingSnapshot&&pending.allowNativeAttributeMismatch!==true))throw new Error('Invalid conflict recovery mode');
      if(pending.allowNativeAttributeMismatch===true&&!pending.allowConflictingSnapshot&&!uniqueContent(snapshot))throw new Error('Ambiguous attribute recovery identity');
      if (snapshot.some(cookie=>!inScope(cookie,pending.domains))) throw new Error('Snapshot outside recovery scope');
      const seen = new Set();
      for (const cookie of snapshot) { const key=C.cookieKey(cookie); if(seen.has(key)&&!pending.allowConflictingSnapshot)throw new Error('Duplicate recovery cookie'); seen.add(key); }
      const count=unknownExpiryCount(snapshot);
      if(pending.allowMissingNativeExpiry===true||owns(pending,'snapshotUnknownExpiryCount')) {
        if(!Number.isInteger(pending.snapshotUnknownExpiryCount)||pending.snapshotUnknownExpiryCount<0||pending.snapshotUnknownExpiryCount!==count) throw new Error('Unknown-expiry snapshot count mismatch');
      } else if(count) throw new Error('Missing unknown-expiry consent');
      return {snapshot,unknownCount:count};
    }
    async function restore(db, allowMissingNativeExpiry=false,allowNativeAttributeMismatch=false) {
      const pending = db.pending;
      if (!pending) throw fail('目前沒有需要復原的切換。');
      let recovery;
      try { recovery=validateRecovery(pending); }
      catch (_) { throw fail('復原備份格式異常，尚未修改目前 Cookie。可選擇停止復原、保留現有 Cookie，再重新匯入帳號。'); }
      const attributeCompatibility=allowNativeAttributeMismatch===true||pending.allowNativeAttributeMismatch===true;
      const compatibility=allowMissingNativeExpiry===true||pending.allowMissingNativeExpiry===true||attributeCompatibility;
      if (pending.phase === 'prepared') {
        db.pending = null;
        db.lastResult = {status:'restored',message:'上次切換在寫入 Cookie 前中斷；已解除待復原狀態，保留瀏覽器目前 Cookie。',at:now()};
        recoverAttempt(db,'restored',db.lastResult.message);
        await write(db);
        return metadata(db);
      }
      requireAPIs(RECOVERY_REQUIRED);
      // Validate the entire backup before closing any tab or clearing the current jar.
      const parts=pending.allowConflictingSnapshot?splitConflictingSnapshot(recovery.snapshot):{restorable:recovery.snapshot,omitted:[]};
      const snapshot=parts.restorable;
      if(attributeCompatibility&&!uniqueContent(snapshot))throw fail('復原備份有名稱、網域與路徑相同的多筆 Cookie，無法唯一核對相容復原；尚未修改目前 Cookie。');
      if((compatibility&&pending.allowMissingNativeExpiry!==true)||(attributeCompatibility&&pending.allowNativeAttributeMismatch!==true)) {
        pending.allowMissingNativeExpiry=true;
        pending.allowNativeAttributeMismatch=attributeCompatibility;
        pending.snapshotUnknownExpiryCount=recovery.unknownCount;
        await write(db); // Record this explicit recovery consent before native mutations.
      }
      currentStoreId = pending.storeId;
      await prepareRelated(pending.tabDomains || pending.domains,attributeCompatibility);
      await clear(pending.domains,'restoreClearing',compatibility,attributeCompatibility,snapshot);
      const verified=await install(snapshot, pending.domains,'restoreVerification',compatibility,null,attributeCompatibility);
      db.activeId = pending.previousActiveId;
      db.activeScope = pending.previousActiveScope;
      db.activeStoreId = pending.previousStoreId;
      if (Object.prototype.hasOwnProperty.call(pending,'previousActiveCookieRevision')) db.activeCookieRevision = pending.previousActiveCookieRevision;
      const attributeLimited=attributeCompatibility||pending.previousAttributeLimited===true;
      const restoredDefaultSameSiteCount=unexpired(snapshot).filter(cookie=>cookie.nativeSameSiteDefaultUnknown===true).length;
      const warnings=warningList([...(tabStopUnconfirmed?[TAB_WARNING]:[]),...warningList(pending.previousActiveWarnings),...(recovery.unknownCount?[TEMP_RESTORE_WARNING]:[]),...(!attributeLimited&&verified.missingNativeExpiryCount?[EXPIRY_WARNING]:[]),...(!attributeLimited&&verified.temporarySessionCount?[SESSION_WARNING]:[]),...(attributeLimited?[ATTRIBUTE_RESTORE_WARNING]:[]),...(restoredDefaultSameSiteCount?[SAME_SITE_RESTORE_WARNING]:[])]);
      db.activeWarnings=warnings;
      db.activeAttributeLimited=attributeLimited;
      if(observedMissingNativeExpiry) db.nativeExpiryLimitationObserved=true;
      db.pending = null;
      if(parts.omitted.length)db.lastUnrestoredSnapshot={at:now(),cookies:parts.omitted,domains:pending.domains};
      const limited=attributeLimited||recovery.unknownCount>0||verified.missingNativeExpiryCount>0||verified.temporarySessionCount>0||lifetimeLimited(pending.previousActiveWarnings);
      if(limited) { db.activeId=null; db.activeCookieRevision=null; }
      db.lastResult = {status:limited?'restored_limited':'restored',message:withWarnings(attributeLimited?'已完成有限復原；Cookie 名稱、值、網域與路徑已核對，安全屬性與期限未確認。':limited?'已完成有限復原；Cookie 內容與可核對屬性已通過檢查，無法確認完整期限還原。':'已還原切換前的 Cookie。網站登入狀態仍需自行確認。',warnings),warnings,attributeLimited,restoredDefaultSameSiteCount,missingNativeExpiryCount:verified.missingNativeExpiryCount,temporarySessionCount:verified.temporarySessionCount,at:now()};
      if(parts.omitted.length){
        db.lastResult.recoveryOmittedCookieCount=parts.omitted.length;
        db.lastResult.message='僅復原 '+verified.verification.expectedCount+' 筆可辨識的舊 Cookie；'+parts.omitted.length+' 筆衝突資料保留在本機備份，未寫回瀏覽器。這不是完整復原，原網站可能需要重新登入；可繼續選擇帳號套用。';
      }
      recoverAttempt(db,limited?'restored_limited':'restored',db.lastResult.message);
      await write(db);
      return metadata(db);
    }
    async function openDestination(url, context) {
      // Only the background router grants this to our top-level handoff page.
      if(context.reuseDestinationTab === true && Number.isInteger(context.tab?.id) && api.available('tabs.get')) {
        const tab = await call('tabs.get', context.tab.id);
        const expected = typeof api.getURL === 'function' ? api.getURL('quick-switch.html') : null;
        if(expected && tab?.incognito === false && tab.url?.split('#')[0] === expected &&
            (currentStoreId === undefined || tab.cookieStoreId === undefined || tab.cookieStoreId === currentStoreId)) {
          await call('tabs.update', tab.id, {url,active:true});
          return;
        }
        throw fail('切換分頁已變更，請重新開啟帳號。');
      }
      if (parkedTabIds.size) {
        let tabs=await call('tabs.query',{});
        if(Array.isArray(tabs)&&api.available('tabs.get')) {
          const current=[];
          for(const tab of tabs) {
            if(!parkedTabIds.has(tab.id)){current.push(tab);continue;}
            try {const fresh=await call('tabs.get',tab.id);if(fresh?.id===tab.id)current.push(fresh);}
            catch(error){if(error.apiTimeout)throw error;}
          }
          tabs=current;
        }
        const reusable=Array.isArray(tabs)&&tabs.find(tab=>parkedTabIds.has(tab.id)&&tab.incognito===false&&tab.url==='about:blank'&&tab.status==='complete'&&!tab.pendingUrl&&
          (!Number.isInteger(context.tab?.windowId)||tab.windowId===context.tab.windowId)&&
          (currentStoreId===undefined||tab.cookieStoreId===undefined||tab.cookieStoreId===currentStoreId));
        if(reusable) {
          parkedTabIds.delete(reusable.id);
          await call('tabs.update',reusable.id,{url,active:true});
          return;
        }
      }
      const details = {url: 'about:blank', active: true};
      if (Number.isInteger(context.tab?.windowId)) details.windowId = context.tab.windowId;
      const tab = await call('tabs.create', details);
      if (!tab || !Number.isInteger(tab.id) || tab.incognito !== false ||
          (currentStoreId !== undefined && tab.cookieStoreId !== undefined && tab.cookieStoreId !== currentStoreId)) {
        if (tab && Number.isInteger(tab.id)) await call('tabs.remove', [tab.id]);
        throw new Error('Destination context was not confirmed');
      }
      await call('tabs.update', tab.id, {url, active: true});
    }
    async function switchProfile(db, profileId, context, allowMissingNativeExpiry=false,attempt=null,allowNativeAttributeMismatch=false) {
      const target = profileHealth(db).valid.find(p => p.id === profileId);
      if (!target) throw fail('找不到指定帳號。');
      if (!allowNativeAttributeMismatch && db.activeId === target.id && db.activeCookieRevision === target.cookieRevision) {
        if(attempt)attempt.stage='open';
        requireAPIs(['storage.local.get','storage.local.set','tabs.create','tabs.update']);
        currentStoreId = db.activeStoreId;
        try { await openDestination(C.validateUrl(target.startUrl), context); }
        catch (error) {
          const wrapped=fail(withWarnings(safeErrorText(error,'未能在一般瀏覽環境開啟網址；目前 Cookie 未變更。'),warningList(db.activeWarnings)));
          if(error?.[SAFE_ERROR]){if(error.apiTimeout)wrapped.apiTimeout=true;if(error.mutationUncertain)wrapped.mutationUncertain=true;}
          throw wrapped;
        }
        const warnings=warningList(db.activeWarnings);
        db.lastResult = {status: 'opened', message: withWarnings('已使用目前 Cookie 開啟指定網址。請在網站確認實際帳號；未重新寫入舊 Cookie。',warnings),warnings,attributeLimited:db.activeAttributeLimited===true,at: now()};
        if(attempt){attempt.status='opened';attempt.message=db.lastResult.message;attempt.recovery={status:'not_needed',message:'使用目前 Cookie 開啟，無需復原。'};rememberAttempt(db,attempt);}
        await write(db);
        return metadata(db);
      }
      requireAPIs();
      const original = copy(db);
      const previousSource=profileHealth(db).valid.find(profile=>profile.id===db.activeId&&profile.cookieRevision===db.activeCookieRevision);
      const sessionSnapshotLimited=snapshot=>Boolean(allowMissingNativeExpiry&&previousSource&&snapshot.some(cookie=>cookie.session&&previousSource.cookies.some(saved=>!saved.session&&C.cookieKey(saved)===C.cookieKey(cookie))));
      let cookies;
      const expiredCookieCount=target.cookies.length-unexpired(target.cookies).length;
      try { cookies = allowNativeAttributeMismatch&&expiredCookieCount===target.cookies.length?[]:C.parseImport(JSON.stringify(target.cookies), {fallbackUrl: target.startUrl, now: now()}).cookies; }
      catch (_) { throw fail('這個帳號的 Cookie 已過期或格式不相容，請重新匯入。'); }
      if (cookies.length !== target.cookies.length&&!allowNativeAttributeMismatch) throw fail('這個帳號有 Cookie 已過期，請重新匯入後再切換，或選擇相容開啟以略過已過期項目。');
      if(allowNativeAttributeMismatch&&!uniqueContent(cookies))throw fail('此帳號有名稱、網域與路徑相同但僅限主機屬性不同的 Cookie，無法唯一核對相容套用；尚未修改 Cookie。');
      const targetUrl = C.validateUrl(target.startUrl);
      const targetDomains=C.profileDomains(cookies,targetUrl);
      const scopes = unique([...(db.activeScope || []), ...targetDomains]);
      // An empty jar cannot reveal its store ID. Keep the previously established store binding.
      if ((db.activeId || db.activeScope?.length) && db.activeStoreId !== undefined) currentStoreId = db.activeStoreId;
      const allBefore = await allCookies();
      if (context.tab?.cookieStoreId !== undefined && currentStoreId !== undefined && context.tab.cookieStoreId !== currentStoreId) {
        throw fail('請從一般預設瀏覽環境開啟管理器；目前分頁與 Cookie 儲存區不同。');
      }
      if ((db.activeId || db.activeScope?.length) && db.activeStoreId !== undefined && db.activeStoreId !== currentStoreId) {
        throw fail('目前 Cookie 儲存區與先前帳號不同，已停止切換以避免混用。');
      }
      const before = allBefore.filter(c => nativeInScope(c, scopes));
      before.forEach(cookie=>portable(cookie,'preflight',allowMissingNativeExpiry,allowNativeAttributeMismatch));
      assertRemovable(allBefore, scopes,'preflight',allowNativeAttributeMismatch);
      // Parent cookies affect sibling tabs, but must not widen the cookies we delete.
      let tabScopes = unique([...scopes, ...cookies.map(c => c.domain), ...before.map(c => c.domain)]);
      const snapshot = mergeNativeDuplicates(before.map(cookie=>portable(cookie,'preflight',allowMissingNativeExpiry,allowNativeAttributeMismatch)),allowNativeAttributeMismatch);
      db.pending = {targetId: target.id, previousActiveId: db.activeId,
        previousActiveScope: db.activeScope || [], previousStoreId: db.activeStoreId,previousActiveCookieRevision:db.activeCookieRevision,
        storeId: currentStoreId, domains: scopes, tabDomains: tabScopes, snapshot,
        allowMissingNativeExpiry, snapshotUnknownExpiryCount:unknownExpiryCount(snapshot),previousActiveWarnings:warningList([...warningList(db.activeWarnings),...(sessionSnapshotLimited(snapshot)?[SESSION_WARNING]:[])]),
        allowNativeAttributeMismatch,allowConflictingSnapshot:allowNativeAttributeMismatch,previousAttributeLimited:db.activeAttributeLimited===true||allowNativeAttributeMismatch,
        phase: 'prepared', startedAt: now()};
      db.lastResult={status:'switching',message:'正在套用所選帳號。',at:now()};
      if(attempt){attempt.stage='closing_tabs';rememberAttempt(db,attempt);}
      await write(db); // Durable journal exists before tabs or cookies change.
      let mutated = false;
      let closedTabs = 0;
      try {
        closedTabs += await prepareRelated(tabScopes,allowNativeAttributeMismatch);
        // Capture unload-time cookie changes after old pages have stopped.
        const afterClose = (await allCookies()).filter(c => nativeInScope(c, scopes));
        const expanded = unique([...tabScopes, ...afterClose.map(c => c.domain)]);
        if (expanded.length !== tabScopes.length) closedTabs += await prepareRelated(expanded,allowNativeAttributeMismatch);
        tabScopes = expanded;
        const finalSnapshot = mergeNativeDuplicates((await allCookies()).filter(c => nativeInScope(c, scopes)).map(cookie=>portable(cookie,'preflight',allowMissingNativeExpiry,allowNativeAttributeMismatch)),allowNativeAttributeMismatch);
        db.pending.tabDomains = tabScopes;
        db.pending.snapshot = finalSnapshot;
        db.pending.snapshotUnknownExpiryCount=unknownExpiryCount(finalSnapshot);
        if(sessionSnapshotLimited(finalSnapshot))db.pending.previousActiveWarnings=warningList([...db.pending.previousActiveWarnings,SESSION_WARNING]);
        db.pending.phase = 'installing';
        if(attempt){attempt.stage='clearing';rememberAttempt(db,attempt);}
        await write(db);
        mutated = true;
        await clear(scopes,'clearing',allowMissingNativeExpiry,allowNativeAttributeMismatch,cookies);
        if(attempt)attempt.stage='installing';
        let verified;
        try {
          verified=await install(cookies, scopes,'verification',allowMissingNativeExpiry,attempt,allowNativeAttributeMismatch);
        } catch(error) {
          const first=error?.[SAFE_ERROR]&&error.attemptDetails?.verification;
          const content=first?.contentVerification;
          // A deferred exact overwrite can leave an old native variant next to
          // the new value. One fresh, fully empty scoped jar may now be possible
          // (observed in the phone's compensation pass). Never accept/select a
          // duplicate value: require empty reads, then rewrite and verify all.
          if(!allowNativeAttributeMismatch || !attempt?.clearingSummary?.overwriteDeferredCount ||
              !content?.duplicateCount || content.missingCount || content.unexpectedCount ||
              error.apiTimeout || error.mutationUncertain || stalled.size)throw error;
          attempt.repair={status:'started',initialVerification:copy(content)};
          attempt.stage='repairing';
          try {
            await clear(scopes,'repairClearing',allowMissingNativeExpiry,true);
            attempt.repair.status='cleared';attempt.stage='installing';
            verified=await install(cookies,scopes,'verification',allowMissingNativeExpiry,attempt,true);
            attempt.repair.status='verified';
          } catch(repairError) {
            attempt.repair.status='failed';
            if(!repairError.attemptDetails?.verification)attempt.verification=copy(first);
            throw repairError;
          }
        }
        if(!verified.verification.expectedCount&&!allowNativeAttributeMismatch)throw fail('本次套用期間 Cookie 已全部過期；已停止開啟，請重新匯出有效 Cookie。');
        const skippedExpiredCookieCount=target.cookies.length-verified.verification.expectedCount;
        const unknownSnapshotCount=unknownExpiryCount(finalSnapshot);
        const warnings=warningList([...(tabStopUnconfirmed?[TAB_WARNING]:[]),...(!allowNativeAttributeMismatch&&verified.missingNativeExpiryCount?[EXPIRY_WARNING]:[]),...(unknownSnapshotCount?[BACKUP_WARNING]:[]),...(!allowNativeAttributeMismatch&&verified.temporarySessionCount?[SESSION_WARNING]:[]),...(allowNativeAttributeMismatch?[ATTRIBUTE_WARNING]:[]),...(skippedExpiredCookieCount?[EXPIRED_SKIPPED_WARNING]:[])]);
        // Save the departing account's latest cookies only after the new jar passed verification.
        const source = profileHealth(db).valid.find(p => p.id === original.activeId);
        const preserveSource=allowNativeAttributeMismatch||original.activeAttributeLimited===true||unknownSnapshotCount||lifetimeLimited(original.activeWarnings)||sessionSnapshotLimited(finalSnapshot);
        if (source && source.id !== target.id && source.cookieRevision === original.activeCookieRevision && !preserveSource) {
          source.cookies = unexpired(finalSnapshot.filter(c => inScope(c, original.activeScope || [])));
          source.domains = C.profileDomains(source.cookies, source.startUrl);
          source.updatedAt = now();
        }
        else if(source&&source.id!==target.id&&preserveSource) warnings.push(allowNativeAttributeMismatch||original.activeAttributeLimited===true?ATTRIBUTE_SAVED_WARNING:SAVED_WARNING);
        db.activeId = target.id;
        db.activeScope = targetDomains;
        db.activeStoreId = currentStoreId;
        db.activeCookieRevision = target.cookieRevision;
        db.activeWarnings=warnings;
        db.activeAttributeLimited=allowNativeAttributeMismatch;
        if(observedMissingNativeExpiry) db.nativeExpiryLimitationObserved=true;
        db.pending = null;
        db.lastResult = {status: 'applied', message: withWarnings((allowNativeAttributeMismatch?'已相容套用 Cookie，名稱、值、網域與路徑已核對；安全屬性與期限未確認。':verified.missingNativeExpiryCount||verified.temporarySessionCount?'Cookie 已套用，內容與可核對屬性已通過讀回檢查；請在網站確認登入狀態。':'Cookie 已套用並通過讀回檢查；請在網站確認帳號及登入狀態。')+(skippedExpiredCookieCount?' 本次略過 '+skippedExpiredCookieCount+' 筆已過期 Cookie。':''),warnings),warnings,attributeLimited:allowNativeAttributeMismatch,skippedExpiredCookieCount,missingNativeExpiryCount:verified.missingNativeExpiryCount,temporarySessionCount:verified.temporarySessionCount,
          at: now(), cookieCount: verified.verification.expectedCount, closedTabs};
        if(!verified.verification.expectedCount){
          db.activeId=null;db.activeCookieRevision=null;
          db.lastResult.status='opened_without_cookies';
          db.lastResult.message='已略過全部到期 Cookie，並清理相關舊 Cookie。將開啟指定網站；本次沒有套用登入資料，可在網站重新登入。';
        }
        if(attempt){attempt.stage='commit';attempt.status=verified.verification.expectedCount?'applied':'opened';attempt.message=db.lastResult.message;attempt.verification=verified.verification;attempt.recovery={status:'not_needed',message:verified.verification.expectedCount?'Cookie 已套用，無需復原。':'操作已完成，無需復原。'};rememberAttempt(db,attempt);}
        await write(db);
      } catch (error) {
        if(attempt)captureFailure(attempt,error);
        // Do not issue compensation writes while a timed-out native mutation may still arrive.
        if (stalled.size || error.mutationUncertain) throw error;
        if (!mutated) {
          original.lastResult = {status: 'stopped', message: '切換已停止，尚未修改 Cookie。部分相關分頁可能已關閉。', at: now()};
          if(attempt)rememberAttempt(original,attempt);
          try { await write(original); } catch (_) { /* Existing journal remains recoverable. */ }
          throw fail(safeErrorText(error,'切換前檢查未完成，尚未套用新帳號。請重新整理查看狀態。'));
        }
        // Read the durable journal: the final commit may itself have failed.
        try {
          const saved = await read();
          if (!saved.pending) throw new Error('No durable journal');
          if(observedMissingNativeExpiry)saved.nativeExpiryLimitationObserved=true;
          if(attempt)rememberAttempt(saved,attempt);
          await write(saved);
          const restored=await restore(saved);
          if(attempt) {attempt.recovery={status:restored.lastResult.status,message:restored.lastResult.message};latestAttempt=copy(attempt);if(attempt.mutated)latestMutatedAttempt=copy(attempt);}
          const completed=fail(safeErrorText(error,'Cookie 寫入未完成。')+' '+restored.lastResult.message+' 未開啟目標網站。');
          completed.recoveryCompleted=true;
          throw completed;
        } catch (recoveryError) {
          if (recoveryError.recoveryCompleted) throw recoveryError;
          if(attempt)attempt.recovery={status:'pending',message:safeErrorText(recoveryError,'自動復原未完成，請依管理頁提示處理。')};
          throw fail(safeErrorText(error,'Cookie 套用未完成。')+' 切換未完成，且自動還原未通過檢查。可重新套用所選帳號，或展開復原選項。');
        }
      }
      try {
        if(attempt)attempt.stage='open';
        await openDestination(targetUrl, context);
      }
      catch (error) {
        db.lastResult.message = withWarnings(stalled.size ? 'Cookie 已套用，但開啟分頁逾時。請稍後重新整理確認結果，避免重複開啟。' : 'Cookie 已套用，但瀏覽器未能開啟網址。請手動開啟此帳號的指定網址，再確認登入狀態。',warningList(db.lastResult.warnings));
        if(attempt){captureFailure(attempt,error);attempt.message=db.lastResult.message;attempt.recovery={status:'not_needed',message:'Cookie 已套用，僅開啟網址失敗，不回復 Cookie。'};rememberAttempt(db,attempt);}
        try { await write(db); } catch (_) { /* Jar and active account are already committed. */ }
      }
      if(attempt&&attempt.status!=='failed'){attempt.stage='open';attempt.message=db.lastResult.message;await persistAttempt(attempt);}
      return metadata(db);
    }
    async function handle(message, context = {}) {
      if (!message || typeof message.type !== 'string') throw fail('無效的操作。');
      if (message.type === 'operationStatus') return operationStatus();
      if (message.type === 'diagnostics') return await diagnostics();
      if (message.type === 'state') return {...metadata(await read()),operation:operationStatus()};
      if (stalled.size) throw fail(operationStatus().message);
      if (busy) throw fail('已有操作正在進行，請等待完成。');
      busy = true;
      currentStoreId = undefined;
      parkedTabIds.clear();
      tabStopUnconfirmed=false;
      try {
        const db = await read();
        if(db.pending&&message.type==='switch'&&message.replacePending===true&&requestAttributeCompatibility(message)){
          if(!profileHealth(db).valid.some(profile=>profile.id===message.id))throw fail('找不到可套用的帳號，請重新整理。');
          await abandonPending(db);
        }
        if (db.pending && !['recover','abandonRecovery','inspectSwitch'].includes(message.type)) throw fail('上次切換尚未完成，請先復原，或選擇停止復原並保留目前 Cookie。');
        if (message.type === 'recover') {
          try {return await restore(db,requestCompatibility(message),requestAttributeCompatibility(message));}
          catch(error){recoverAttempt(db,'pending',safeErrorText(error,'復原未完成。'));if(db.lastAttempt&&!stalled.size){try{await write(db);}catch(_){}}throw error;}
        }
        if (message.type === 'abandonRecovery') {
          if (message.confirm !== true) throw fail('請先確認停止復原的影響；這個操作不會還原 Cookie，也不等於登出。');
          await abandonPending(db);
          return metadata(db);
        }
        if (message.type === 'switch') return await runSwitch(db,message,context);
        if (message.type === 'inspectSwitch') return await inspectSwitch(db,message.id);
        if (message.type === 'siteCopy') return await siteCopy(db,message);
        if (message.type === 'runCookieProbe') {
          const probe=root.AccountCookieProbe||(typeof require==='function'?require('./cookie-probe.js'):null);
          if(!probe||typeof probe.run!=='function')throw fail('此版本沒有裝置 Cookie 假資料檢測功能，請更新擴充套件。');
          const report=await probe.run({call,available:path=>api.available(path),now});
          const reportVersion=extensionVersion();if(reportVersion)report.extensionVersion=reportVersion;
          latestCompleteCookieProbe=completeCookieProbe(report)||probeEvidence(db);
          if(latestCompleteCookieProbe)db.lastCompleteCookieProbe=copy(latestCompleteCookieProbe);
          latestCookieProbe=copy(report);
          db.lastCookieProbe=copy(report);
          // A probe can time out with a native mutation still in flight. Keep
          // its anonymous report in memory without violating quarantine.
          if(!stalled.size&&report?.summary?.cleanup!=='uncertain') {
            try{await write(db);}catch(_){/* Report remains available in memory. */}
          }
          return {...metadata(db),cookieProbe:copy(report)};
        }
        if (message.type === 'bulkSave') return await bulkSave(db, message);
        if (message.type === 'save') return await saveProfile(db,message);
        if (message.type === 'discardInvalid') {
          if(message.confirm !== true) throw fail('請先確認移除損壞帳號紀錄；不會修改瀏覽器 Cookie。');
          const health = profileHealth(db);
          db.profiles = health.valid;
          if(db.activeId && !db.profiles.some(p=>p.id===db.activeId)) { db.activeId=null; db.activeCookieRevision=null; }
          db.lastResult={status:'repaired',message:'已移除 '+health.invalid.length+' 筆損壞帳號紀錄；瀏覽器 Cookie 未變更，可重新匯入該帳號。',at:now()};
          await write(db);
          return metadata(db);
        }
        if (message.type === 'delete') {
          if (!db.profiles.some(p => p?.id === message.id)) throw fail('找不到指定帳號。');
          db.profiles = db.profiles.filter(p => p?.id !== message.id);
          // Deleting a saved record is not a logout; retain scope/store for the next switch to clean up.
          if (db.activeId === message.id) { db.activeId = null; db.activeCookieRevision = null; }
          await write(db);
          return metadata(db);
        }
        throw fail('不支援的操作。');
      } finally { busy = false; }
    }
    return {handle:async (message,context) => {
      try {
        const result = await handle(message,context);
        if (message.type === 'operationStatus') return result;
        return {...result,...(latestAttempt?{lastAttempt:copy(latestAttempt)}:{}),...(latestMutatedAttempt?{lastMutatedAttempt:copy(latestMutatedAttempt)}:{}),...(latestCookieProbe?{lastCookieProbe:copy(latestCookieProbe)}:{}),operation:operationStatus()};
      } catch(error) {if(error?.[SAFE_ERROR])throw error;throw fail('操作未完成。請重新整理管理頁查看復原提示。');}
    }};
  }
  const exported = {create, inScope, tabInScope, KEY};
  root.AccountEngine = exported;
  if (typeof module !== 'undefined' && module.exports) module.exports = exported;
})(globalThis);
