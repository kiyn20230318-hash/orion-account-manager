(function () {
  'use strict';
  const params=new URLSearchParams(location.hash.slice(1)),id=params.get('id');
  const status=document.getElementById('status'),retry=document.getElementById('retry'),manager=document.getElementById('manager');
  let busy=false;
  async function apply() {
    if(busy||!id)return;
    busy=true;retry.hidden=true;manager.hidden=true;
    status.textContent='正在清除網站資料，再套用帳號，請保持此分頁開啟…';
    try {
      const state=await AccountAPI.call('runtime.sendMessage',{type:'quickState'});
      if(!state?.ok)throw new Error(state?.error||'無法取得帳號資料。');
      const profile=state.data.profiles.find(p=>p.id===id);
      if(!profile)throw new Error('找不到這個帳號，請回管理器選擇。');
      document.getElementById('heading').textContent='切換至 '+profile.name;
      const response=await AccountAPI.call('runtime.sendMessage',{type:'quickApply',id});
      if(!response?.ok)throw new Error(response?.error||'切換未完成。');
      status.textContent=response.data.message;
    } catch(error) {status.textContent=error.message||'切換未完成，請重試。';}
    finally {busy=false;retry.hidden=false;manager.hidden=false;}
  }
  retry.addEventListener('click',()=>apply());
  const key='quick-consumed:'+params.get('request');
  if(id&&params.get('request')&&!sessionStorage.getItem(key)){sessionStorage.setItem(key,'1');apply();}
  else {status.textContent='選擇重新套用，或返回帳號管理器。';retry.hidden=!id;manager.hidden=false;}
})();
