(function () {
  'use strict';
  if(window.top!==window)return;
  if(globalThis.__orionQuickRefresh){globalThis.__orionQuickRefresh();return;}
  const native=globalThis.browser||globalThis.chrome;
  function send(message) {
    if(globalThis.browser)return native.runtime.sendMessage(message);
    return new Promise((resolve,reject)=>native.runtime.sendMessage(message,result=>native.runtime.lastError?reject(new Error('連線中斷')):resolve(result)));
  }
  // Positions live in extension storage, never in the website's own storage.
  function loadPosition(key){
    try{
      const area=native.storage?.local;if(!area)return Promise.resolve(null);
      if(globalThis.browser)return Promise.resolve(area.get(key)).then(r=>r?.[key]||null,()=>null);
      return new Promise(resolve=>area.get(key,r=>resolve(native.runtime.lastError?null:r?.[key]||null)));
    }catch(_){return Promise.resolve(null);}
  }
  function savePosition(key,value){try{const area=native.storage?.local;if(!area)return;const r=globalThis.browser?area.set({[key]:value}):area.set({[key]:value},()=>void native.runtime.lastError);if(r?.catch)r.catch(()=>{});}catch(_){}}
  let checking=false,timer=null,attempt=0,mounted=[],enabled=false,repairs=0;
  async function refresh(){
    if(checking)return;
    checking=true;
    try {
      const first=await Promise.race([send({type:'quickState'}),new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error()),4000);})]);
      clearTimeout(timer);
      if(!first?.ok)throw new Error();
      attempt=0;
      repairs=0;
      enabled=first.data.enabled===true;
      if(!enabled){mounted.forEach(node=>node.remove());return;}
      if(mounted.length){mounted.forEach(node=>{if(!node.isConnected)document.documentElement.append(node);});return;}
      if(!document.querySelector('orion-account-switcher'))mounted=[mountSwitcher(first),mountTools()];
    }catch(_){if(attempt++<3)setTimeout(refresh,1000*attempt);}
    finally{clearTimeout(timer);checking=false;}
  }
  globalThis.__orionQuickRefresh=refresh;
  window.addEventListener('pageshow',refresh);
  window.addEventListener('focus',refresh);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh();});
  // A site replacing its document children must not permanently remove the entries.
  new MutationObserver(()=>{if(enabled&&mounted.some(node=>!node.isConnected)&&repairs++<3)mounted.forEach(node=>{if(!node.isConnected)document.documentElement.append(node);});}).observe(document.documentElement,{childList:true});
  refresh();

  function createHost(tag,place){
    const host=document.createElement(tag);
    host.style.cssText='all:initial!important;position:fixed!important;'+place+'z-index:2147483647!important;display:block!important;';
    return host;
  }
  // Drag by any of `handles` (8 px threshold, so a tap still taps). The click
  // that ends a drag is swallowed. Position is clamped to the screen and kept
  // as a screen ratio so rotation and other pages reuse it.
  function draggable(host,shadow,handles,key,onMove){
    let drag=null,suppress=false,ratio=null;
    function place(left,top){
      const w=innerWidth,h=innerHeight,r=host.getBoundingClientRect(),bw=r.width||96,bh=r.height||44;
      left=Math.min(Math.max(4,left),Math.max(4,w-bw-4));top=Math.min(Math.max(4,top),Math.max(4,h-bh-4));
      host.style.setProperty('left',left+'px','important');host.style.setProperty('top',top+'px','important');
      host.style.setProperty('right','auto','important');host.style.setProperty('bottom','auto','important');
      ratio={x:w?left/w:0,y:h?top/h:0};onMove?.();
    }
    const reclamp=()=>{const r=host.getBoundingClientRect();if(ratio)place(ratio.x*innerWidth,ratio.y*innerHeight);else if(r.right>innerWidth||r.bottom>innerHeight)place(r.left,r.top);onMove?.();};
    loadPosition(key).then(saved=>{if(saved&&Number.isFinite(saved.x)&&Number.isFinite(saved.y)&&!drag)place(saved.x*innerWidth,saved.y*innerHeight);else onMove?.();});
    addEventListener('resize',reclamp);
    // Movement is followed on the window from the press on, so a fast drag that
    // leaves the button before the threshold is not lost. Pointer capture is
    // taken only once really dragging: capturing on press would retarget a plain
    // tap's click away from the tapped button.
    function move(event){
      if(!drag||event.pointerId!==drag.id)return;
      const dx=event.clientX-drag.x,dy=event.clientY-drag.y;
      if(!drag.moved&&Math.hypot(dx,dy)<8)return;
      if(!drag.moved){try{drag.handle.setPointerCapture(event.pointerId);}catch(_){}}
      drag.moved=true;host.classList.add('dragging');if(event.cancelable)event.preventDefault();
      place(drag.left+dx,drag.top+dy);
    }
    function end(event){
      if(!drag||event.pointerId!==drag.id)return;
      // Swallow only the click this drag itself produces (cleared by the next press).
      if(drag.moved){suppress=true;if(ratio)savePosition(key,ratio);}
      host.classList.remove('dragging');drag=null;
      removeEventListener('pointermove',move,true);removeEventListener('pointerup',end,true);removeEventListener('pointercancel',end,true);
    }
    for(const handle of handles){
      handle.addEventListener('pointerdown',event=>{
        if(!event.isTrusted||(event.button!==undefined&&event.button>0))return;
        suppress=false;
        const r=host.getBoundingClientRect();
        drag={id:event.pointerId,x:event.clientX,y:event.clientY,left:r.left,top:r.top,moved:false,handle};
        addEventListener('pointermove',move,true);addEventListener('pointerup',end,true);addEventListener('pointercancel',end,true);
      });
    }    shadow.addEventListener('click',event=>{if(suppress){suppress=false;event.stopPropagation();event.preventDefault();}},true);
    return {reclamp};
  }
  const BASE_CSS=':host{color-scheme:light}*{box-sizing:border-box}button,input{font:inherit}button{cursor:pointer}button:focus-visible,input:focus-visible{outline:3px solid #8fc2b8;outline-offset:2px}';

  function mountSwitcher(first){
  const host=createHost('orion-account-switcher','right:8px!important;top:38%!important;');
  const shadow=host.attachShadow({mode:'closed'}),style=document.createElement('style');
  style.textContent=BASE_CSS+`.wrap{font:15px/1.5 system-ui,sans-serif;color:#1c2c36;position:relative}.toggle{display:block;border:1px solid #ffffff90;border-radius:20px;padding:8px 12px;min-height:44px;background:#326b62ed;color:white;box-shadow:0 2px 10px #0002;touch-action:none;user-select:none;-webkit-user-select:none;-webkit-touch-callout:none}:host(.dragging) .toggle{opacity:.85;box-shadow:0 6px 18px #0004}.panel{position:absolute;right:0;top:50px;width:min(300px,calc(100vw - 24px));max-height:60vh;overflow:auto;border-radius:18px;background:#f8f8f2;box-shadow:0 6px 30px #0003;padding:14px;border:1px solid #dce1db}.panel.up{top:auto;bottom:50px}.panel[hidden]{display:none}.top{display:flex;align-items:center;justify-content:space-between;gap:8px}.title{font-weight:700}.close{border:0;background:none;font-size:22px;min-width:44px;min-height:44px;color:#53656a}input{width:100%;border:1px solid #d8ded8;border-radius:10px;background:white;padding:10px;margin:8px 0}.row{display:block;width:100%;text-align:left;border:0;border-radius:10px;padding:12px;margin:4px 0;background:white;color:#1c2c36;overflow-wrap:anywhere}.row:disabled{opacity:.55}.current{font-size:12px;color:#326b62;margin-left:8px}.note{margin:8px 0 0;font-size:12px;color:#65736e}.status{font-size:13px;color:#874337;overflow-wrap:anywhere}`;
  const wrap=document.createElement('div');wrap.className='wrap';
  wrap.innerHTML='<button class="toggle" aria-label="快速切換帳號（可拖曳移動）" aria-expanded="false">⇄ 切換</button><section class="panel" aria-label="切換帳號" hidden><div class="top"><span class="title">切換帳號</span><button class="close" aria-label="關閉切換選單">×</button></div><input type="search" placeholder="搜尋帳號" aria-label="搜尋帳號"><div class="status" role="status"></div><div class="list"></div><p class="note">切換會關閉一般網頁並清除一般網站登入與儲存資料；匯入帳號庫保留。</p></section>';
  shadow.append(style,wrap);document.documentElement.append(host);
  const toggle=shadow.querySelector('.toggle'),panel=shadow.querySelector('.panel'),search=shadow.querySelector('input'),list=shadow.querySelector('.list'),status=shadow.querySelector('.status');
  let state=first.data,working=false,opening=0;
  // Keep the open panel fully on screen wherever the entry was dragged.
  function orientPanel(){
    const r=host.getBoundingClientRect(),pw=Math.min(300,innerWidth-24);
    let x=r.left+r.width/2<innerWidth/2?r.left:r.right-pw;
    x=Math.min(Math.max(8,x),Math.max(8,innerWidth-pw-8));
    panel.style.left=(x-r.left)+'px';panel.style.right='auto';
    const up=r.top>innerHeight/2;panel.classList.toggle('up',up);
    panel.style.maxHeight=Math.max(160,up?r.top-16:innerHeight-r.bottom-16)+'px';
  }
  draggable(host,shadow,[toggle],'quickSwitchPosition',orientPanel);
  function render() {
    list.replaceChildren();
    const rows=state.profiles.filter(p=>p.name.toLocaleLowerCase().includes(search.value.trim().toLocaleLowerCase()));
    for(const p of rows) {
      const b=document.createElement('button');b.className='row';b.textContent=p.name;b.disabled=working||state.busy||state.stalled;
      if(p.id===state.activeId){const tag=document.createElement('span');tag.className='current';tag.textContent='目前';b.append(tag);}
      b.addEventListener('click',async event=>{
        if(!event.isTrusted||working||b.disabled)return;
        working=true;render();status.textContent='正在切換…';
        try {const r=await send({type:'quickStart',id:p.id});if(!r?.ok)throw new Error();}
        catch(_){status.textContent='切換未開始，請關閉選單後重試。';working=false;render();}
      });list.append(b);
    }
    if(!rows.length){const empty=document.createElement('p');empty.textContent='沒有符合的帳號';list.append(empty);}
  }
  function close(){opening++;panel.hidden=true;toggle.setAttribute('aria-expanded','false');toggle.focus();}
  toggle.addEventListener('click',async event=>{
    if(!event.isTrusted)return;
    if(!panel.hidden){close();return;}
    orientPanel();
    panel.hidden=false;toggle.setAttribute('aria-expanded','true');status.textContent='讀取帳號…';list.replaceChildren();search.value='';
    const request=++opening;
    try {const r=await send({type:'quickState'});if(request!==opening)return;if(!r?.ok||!r.data.enabled)throw new Error();state=r.data;working=false;status.textContent=state.stalled?'上次操作仍在等待瀏覽器回覆，請稍後再試。':state.busy?'正在切換，請稍候。':'';render();search.focus();}
    catch(_){status.textContent='無法取得帳號，請重新整理網頁。';}
  });
  shadow.querySelector('.close').addEventListener('click',close);
  search.addEventListener('input',render);
  shadow.addEventListener('keydown',event=>{if(event.key==='Escape')close();});
  return host;
  }

  // Separate draggable bar: number / code / IP. Results only; the API key stays
  // in the extension. 40 s without a code: the extension blacklists the number
  // and fetches one new number (see sms-tools.js).
  function mountTools(){
  const host=createHost('orion-account-tools','left:8px!important;top:62%!important;');
  const shadow=host.attachShadow({mode:'closed'}),style=document.createElement('style');
  style.textContent=BASE_CSS+`.bar{font:14px/1.4 system-ui,sans-serif;color:#1c2c36;background:#f8f8f2f2;border:1px solid #dce1db;border-radius:14px;box-shadow:0 2px 12px #0002;padding:6px;width:max-content;max-width:calc(100vw - 16px);touch-action:none;user-select:none;-webkit-user-select:none;-webkit-touch-callout:none}:host(.dragging) .bar{opacity:.85;box-shadow:0 6px 18px #0004}.buttons{display:flex;gap:6px;align-items:center}.grip{color:#9aa69f;font-size:14px;padding:0 2px;letter-spacing:-2px}.tool{min-height:44px;min-width:52px;border:1px solid #d8ded8;border-radius:10px;background:white;color:#1c2c36;padding:6px 10px}.tool.primary{background:#326b62;color:white;border-color:#326b62}.tool:disabled{opacity:.5}.out{margin-top:6px;padding:6px 8px;border-radius:10px;background:white;font-size:13px;max-width:260px;overflow-wrap:anywhere;user-select:text;-webkit-user-select:text}.out[hidden],.line[hidden]{display:none}.line{display:flex;align-items:center;gap:8px;margin:2px 0}.line span{font-size:12px;color:#65736e;min-width:40px}.line b{flex:1;font-size:17px;letter-spacing:.03em}.copy{border:0;background:#e8eee9;border-radius:8px;min-height:36px;padding:4px 10px;color:#1c2c36}.copy:disabled{opacity:.4}.hint{font-size:12px;color:#65736e;margin:2px 0 0}`;
  const bar=document.createElement('div');bar.className='bar';bar.setAttribute('role','group');bar.setAttribute('aria-label','號碼與 IP 工具（可拖曳移動）');
  bar.innerHTML='<div class="buttons"><span class="grip" aria-hidden="true">⋮⋮</span><button class="tool" data-tool="number">取號</button><button class="tool primary" data-tool="code">取碼</button><button class="tool" data-tool="ip">IP</button></div><div class="out sms-out" role="status" hidden><div class="line"><span>號碼</span><b class="phone">—</b><button class="copy" data-copy="phone">複製</button></div><div class="line"><span>驗證碼</span><b class="code">—</b><button class="copy" data-copy="code">複製</button></div><p class="hint sms-status"></p></div><p class="out ip-out" role="status" hidden></p>';
  shadow.append(style,bar);document.documentElement.append(host);
  const drag=draggable(host,shadow,[bar],'quickToolsPosition');
  const tool=name=>shadow.querySelector('[data-tool="'+name+'"]'),ipOut=shadow.querySelector('.ip-out'),smsOut=shadow.querySelector('.sms-out');
  const phoneOut=shadow.querySelector('.phone'),codeOut=shadow.querySelector('.code'),smsStatus=shadow.querySelector('.sms-status');
  const STATUS_TEXT={waiting:'等待簡訊中',received:'已收到簡訊',timeout:'號碼已逾時',released:'號碼已釋放'};
  const WAIT_SECONDS=40;
  let tools={hasKey:false,current:null},toolBusy=false,waiting=null;
  async function ask(type){const r=await send({type});if(!r?.ok)throw new Error(r?.error||'操作未完成。');return r.data;}
  function showSms(current,extra){
    smsOut.hidden=!current&&!extra;
    for(const line of shadow.querySelectorAll('.line'))line.hidden=!current;
    phoneOut.textContent=current?.dialNumber||current?.phoneNumber||'—';codeOut.textContent=current?.code||'—';
    shadow.querySelector('[data-copy="code"]').disabled=!current?.code;shadow.querySelector('[data-copy="phone"]').disabled=!current?.phoneNumber;
    smsStatus.textContent=extra||(current?STATUS_TEXT[current.statusText]||'':'');
    drag.reclamp();
  }
  function lockTools(){
    tool('ip').disabled=toolBusy&&!waiting;
    tool('number').disabled=toolBusy||Boolean(waiting)||!tools.hasKey;
    tool('code').disabled=(toolBusy&&!waiting)||!tools.hasKey||!tools.current;
    tool('code').textContent=waiting?'停止':'取碼';
  }
  async function loadTools(){
    try{tools=await ask('quickSmsState');showSms(tools.current,tools.hasKey?'':'請先在帳號管理器儲存 API Key。');}
    catch(_){/* Tools stay disabled; switching is unaffected. */}
    lockTools();
  }
  async function runTool(task){if(toolBusy)return;toolBusy=true;lockTools();try{await task();}finally{toolBusy=false;lockTools();}}
  tool('ip').addEventListener('click',event=>{if(!event.isTrusted)return;runTool(async()=>{
    ipOut.hidden=false;ipOut.textContent='正在查詢 IP…';drag.reclamp();
    try{const r=await ask('quickIp');ipOut.textContent='目前 IP：'+r.ip+(r.country?'（'+r.country+'）':'');}
    catch(error){ipOut.textContent=error.message||'無法取得 IP。';}
    drag.reclamp();
  });});
  tool('number').addEventListener('click',event=>{
    if(!event.isTrusted)return;
    const c=tools.current;
    if(c&&c.statusText==='waiting'&&!c.code&&!window.confirm('目前號碼 '+(c.dialNumber||c.phoneNumber)+' 尚未收到驗證碼，仍要取得新號碼？（可能重複扣款）'))return;
    runTool(async()=>{
      showSms(tools.current,'正在取得號碼…');
      try{tools.current=await ask('quickSmsNumber');showSms(tools.current,'已取得號碼，可複製到網站。');}
      catch(error){showSms(tools.current,error.message||'取得號碼失敗。');}
    });
  });
  function outcomeText(r){
    if(r.outcome==='received')return '已收到驗證碼';
    if(r.outcome==='cancelled')return '已停止等待。';
    if(r.outcome==='changed')return '號碼已更換，請重新按「取碼」。';
    if(r.outcome==='replaced')return WAIT_SECONDS+' 秒未收到：'+(r.blacklisted?'已拉黑舊號':'舊號拉黑未成功')+'；'+(r.current?'已換新號碼，請改填新號碼並重新發送，再按「取碼」。':'取得新號碼失敗：'+(r.numberError||'原因未知'));
    return '';
  }
  function stopWaiting(message){if(waiting){clearInterval(waiting.timer);waiting=null;}if(message)smsStatus.textContent=message;lockTools();}
  tool('code').addEventListener('click',async event=>{
    if(!event.isTrusted)return;
    if(waiting){stopWaiting('正在停止等待…');ask('quickSmsCancel').catch(()=>{});return;}
    if(!tools.current)return;
    const started=Date.now(),mine=waiting={timer:null};
    const tick=()=>{const left=Math.max(0,WAIT_SECONDS-Math.floor((Date.now()-started)/1000));smsStatus.textContent=left?'等待簡訊中，剩 '+left+' 秒（未收到會自動拉黑並換號）':'正在拉黑並換號…';};
    mine.timer=setInterval(tick,1000);smsOut.hidden=false;tick();lockTools();drag.reclamp();
    try{
      const r=await ask('quickSmsAwait');
      if(r.current)tools.current=r.current;
      showSms(tools.current);
      if(waiting===mine)stopWaiting(outcomeText(r));else smsStatus.textContent=outcomeText(r);
    }catch(error){if(waiting===mine)stopWaiting(error.message||'取得驗證碼失敗。');else smsStatus.textContent=error.message||'取得驗證碼失敗。';}
    drag.reclamp();
  });
  for(const button of shadow.querySelectorAll('.copy'))button.addEventListener('click',async event=>{
    if(!event.isTrusted)return;
    const text=(button.dataset.copy==='phone'?phoneOut:codeOut).textContent;if(!text||text==='—')return;
    try{await navigator.clipboard.writeText(text);button.textContent='已複製';}catch(_){button.textContent='請長按';}
    setTimeout(()=>{button.textContent='複製';},1500);
  });
  lockTools();loadTools();
  // Refresh tool state when returning to the page (number may have changed elsewhere).
  document.addEventListener('visibilitychange',()=>{if(!document.hidden&&!waiting&&!toolBusy)loadTools();});
  return host;
  }
})();
