(function (root) {
  'use strict';
  // SMS-number API (robot-sms.xyz) and public-IP lookup, used only from the
  // background page. The API key stays in extension storage under its own key:
  // it is never part of the account library, error logs or website messages.
  const BASE = 'https://robot-sms.xyz/api/v1';
  const KEY = 'smsToolsV1';
  const DEFAULT_PROJECT_ID = 1115; // 香港子項目
  const DEFAULT_COUNTRY_CODE = '852'; // 香港國碼
  const validCountry = value => typeof value === 'string' && /^\d{1,4}$/.test(value);
  // Display/copy form with the country code. API calls keep the platform's raw
  // number. A number already starting with the code (and longer than a local
  // number) only gets the '+', so it is never doubled.
  function dial(phone, countryCode) {
    if (typeof phone !== 'string' || !phone) return '';
    if (phone.startsWith('+')) return phone;
    const code = validCountry(countryCode) ? countryCode : DEFAULT_COUNTRY_CODE;
    return phone.startsWith(code) && phone.length >= code.length + 8 ? '+' + phone : '+' + code + phone;
  }
  const IP_SOURCES = ['https://ipinfo.io/json', 'https://api.ipify.org?format=json'];
  const STATUS = {0: 'waiting', 1: 'received', 2: 'timeout', 3: 'released'};
  const validKey = value => typeof value === 'string' && /^[^\s\u0000-\u001f\u007f]{1,200}$/.test(value);
  const validProject = value => Number.isSafeInteger(value) && value > 0 && value < 1e9;
  const validPhone = value => typeof value === 'string' && /^\+?\d{4,20}$/.test(value);
  const clean = (value, max = 120) => (typeof value === 'string' || typeof value === 'number') ? String(value).replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max) : '';
  const fail = message => Object.assign(new Error(message), {safeMessage: message});

  function create({fetch, get, set, now = () => Date.now(), timeoutMs = 15000, sleep = ms => new Promise(resolve => setTimeout(resolve, ms)),
    waitMs = 40000, pollMs = 5000}) {
    let numberInFlight = false, waiting = null;
    async function load() {
      const result = await get(KEY);
      const saved = result && typeof result === 'object' ? result[KEY] : null;
      return saved && typeof saved === 'object' && !Array.isArray(saved) ? saved : {};
    }
    const store = saved => set({[KEY]: saved});
    async function request(url, init) {
      const controller = typeof AbortController === 'function' ? new AbortController() : null;
      const timer = setTimeout(() => controller?.abort(), timeoutMs);
      try {
        const response = await fetch(url, {...init, credentials: 'omit', cache: 'no-store', ...(controller ? {signal: controller.signal} : {})});
        let body = null;
        try { body = await response.json(); } catch (_) { /* Non-JSON reply handled below. */ }
        return {status: response.status, body};
      } catch (error) {
        throw fail(error?.name === 'AbortError' ? '連線逾時，請稍後再試。' : '無法連線，請檢查網路後再試。');
      } finally { clearTimeout(timer); }
    }
    function apiData(reply) {
      const body = reply.body;
      if (body && typeof body === 'object' && body.code === 200) return body.data;
      if (reply.status === 401 || reply.status === 403) throw fail('API Key 無效或已過期，請重新輸入。');
      if (body && typeof body === 'object') throw fail('接碼平台回覆：' + (clean(body.msg) || '代碼 ' + clean(body.code, 20)));
      throw fail('接碼平台回覆格式無法辨識（HTTP ' + reply.status + '）。');
    }
    function current(saved) {
      const c = saved.current;
      if (!c || !validPhone(c.phoneNumber) || !validProject(c.projectId)) return null;
      return {phoneNumber: c.phoneNumber, dialNumber: dial(c.phoneNumber, saved.countryCode), projectId: c.projectId, at: Number.isFinite(c.at) ? c.at : 0,
        status: STATUS[c.status] ? c.status : 0, statusText: STATUS[c.status] || 'waiting', code: clean(c.code, 32)};
    }
    async function settings() {
      const saved = await load();
      const hasKey = validKey(saved.apiKey);
      return {hasKey, keyHint: hasKey ? '••••' + saved.apiKey.slice(-4) : '', projectId: validProject(saved.projectId) ? saved.projectId : DEFAULT_PROJECT_ID,
        countryCode: validCountry(saved.countryCode) ? saved.countryCode : DEFAULT_COUNTRY_CODE, current: current(saved)};
    }
    // What a website's in-page panel may see: never the key or its hint.
    async function siteState() { const s = await settings(); return {hasKey: s.hasKey, current: s.current}; }
    async function saveSettings(input = {}) {
      const saved = await load();
      if (input.apiKey !== undefined) {
        if (typeof input.apiKey !== 'string') throw fail('API Key 格式不正確。');
        const key = input.apiKey.trim();
        if (!key) delete saved.apiKey;
        else if (!validKey(key)) throw fail('API Key 格式不正確（不可含空白，最長 200 字）。');
        else saved.apiKey = key;
      }
      if (input.projectId !== undefined) {
        const projectId = Number(input.projectId);
        if (!validProject(projectId)) throw fail('子項目 ID 必須是正整數。');
        saved.projectId = projectId;
      }
      if (input.countryCode !== undefined) {
        const code = String(input.countryCode).trim().replace(/^\+/, '');
        if (!validCountry(code)) throw fail('國碼必須是 1–4 位數字，例如 852。');
        saved.countryCode = code;
      }
      await store(saved);
      return settings();
    }
    async function getNumber() {
      if (numberInFlight) throw fail('正在取得號碼，請稍候。');
      numberInFlight = true;
      try {
        const saved = await load();
        if (!validKey(saved.apiKey)) throw fail('請先在帳號管理器輸入並儲存 API Key。');
        const projectId = validProject(saved.projectId) ? saved.projectId : DEFAULT_PROJECT_ID;
        const data = apiData(await request(BASE + '/core/task/create', {method: 'POST',
          headers: {'Content-Type': 'application/json', Authorization: saved.apiKey},
          body: JSON.stringify({project_id: projectId, merchant_nick_name: '', phone_number: '', is_long_task: false, index: 0})}));
        const phoneNumber = clean(data?.phone_number, 24);
        if (!validPhone(phoneNumber)) throw fail('接碼平台沒有回傳有效號碼。');
        saved.current = {phoneNumber, projectId: validProject(data?.project_id) ? data.project_id : projectId, at: now(), status: 0, code: ''};
        await store(saved);
        return current(saved);
      } finally { numberInFlight = false; }
    }
    async function getCode() {
      const saved = await load();
      if (!validKey(saved.apiKey)) throw fail('請先在帳號管理器輸入並儲存 API Key。');
      const active = current(saved);
      if (!active) throw fail('請先取得號碼。');
      const data = apiData(await request(BASE + '/core/task/get/' + encodeURIComponent(active.phoneNumber) + '/' + encodeURIComponent(active.projectId),
        {method: 'GET', headers: {Authorization: saved.apiKey}}));
      const status = STATUS[data?.status] ? data.status : 0;
      saved.current = {...saved.current, status, code: clean(data?.code, 32)};
      await store(saved);
      return {...current(saved), text: clean(data?.text, 300)};
    }
    async function blacklist(number) {
      const saved = await load();
      if (!validKey(saved.apiKey)) throw fail('請先在帳號管理器輸入並儲存 API Key。');
      if (!number) throw fail('沒有可拉黑的號碼。');
      apiData(await request(BASE + '/core/task/black', {method: 'PUT',
        headers: {'Content-Type': 'application/json', Authorization: saved.apiKey},
        body: JSON.stringify({project_id: number.projectId, phone_number: number.phoneNumber})}));
    }
    // Poll the current number for up to waitMs. No code by then (or the
    // platform reports timeout/released): blacklist that number and fetch ONE
    // new number, then stop so the user can enter it on the website and send
    // a new SMS. Never loops on its own, so it cannot keep buying numbers.
    // One shared wait: the manager and the website panel get the same result.
    function awaitCode() {
      if (waiting) return waiting.promise;
      const control = {cancelled: false};
      const promise = (async () => {
        const started = now();
        const number = (await settings()).current;
        if (!number) throw fail('請先取得號碼。');
        let failures = 0, last = number;
        for (;;) {
          if (control.cancelled) return {outcome: 'cancelled', current: last};
          let reply = null;
          try { reply = await getCode(); failures = 0; }
          catch (error) {
            if (/API Key|先取得號碼/.test(error.safeMessage || '') || ++failures >= 3) throw error;
          }
          if (reply) {
            last = reply;
            if (reply.phoneNumber !== number.phoneNumber) return {outcome: 'changed', current: reply};
            if (reply.code) return {outcome: 'received', current: reply, text: reply.text};
            if (reply.status === 2 || reply.status === 3) break;
          }
          if (control.cancelled) return {outcome: 'cancelled', current: last};
          if (now() - started >= waitMs) break;
          await sleep(pollMs);
        }
        if (control.cancelled) return {outcome: 'cancelled', current: last};
        let blacklisted = false, blacklistError = '';
        try { await blacklist(number); blacklisted = true; }
        catch (error) { blacklistError = error.safeMessage || '拉黑未完成。'; }
        let fresh = null, numberError = '';
        try { fresh = await getNumber(); }
        catch (error) { numberError = error.safeMessage || '取得新號碼失敗。'; }
        return {outcome: 'replaced', previousNumber: number.dialNumber || number.phoneNumber, blacklisted, blacklistError, current: fresh, numberError,
          waitedMs: Math.max(0, now() - started)};
      })();
      waiting = {promise, control};
      promise.then(() => { waiting = null; }, () => { waiting = null; });
      return promise;
    }
    function cancelWait() { if (waiting) waiting.control.cancelled = true; return {cancelled: Boolean(waiting)}; }
    async function lookupIp() {
      for (const url of IP_SOURCES) {
        try {
          const reply = await request(url, {method: 'GET'});
          const ip = clean(reply.body?.ip, 64);
          if (reply.status === 200 && /^[0-9a-fA-F:.]{3,64}$/.test(ip))
            return {ip, country: clean(reply.body.country, 8), region: clean(reply.body.region, 60), city: clean(reply.body.city, 60), org: clean(reply.body.org, 80), source: new URL(url).hostname, at: now()};
        } catch (_) { /* Try the next source. */ }
      }
      throw fail('無法取得目前 IP，請檢查網路後再試。');
    }
    return {settings, siteState, saveSettings, getNumber, getCode, blacklist, awaitCode, cancelWait, lookupIp, waitMs};
  }
  const exported = {create, dial, KEY, DEFAULT_PROJECT_ID, DEFAULT_COUNTRY_CODE, BASE, IP_SOURCES};
  root.AccountSms = exported;
  if (typeof module !== 'undefined' && module.exports) module.exports = exported;
})(globalThis);
