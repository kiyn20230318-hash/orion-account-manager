(function(root){
  'use strict';
  const stages=['preflight','closing_tabs','resetting','clearing','installing','verification','repairing','commit','open'];
  const apis=['storage.local.get','storage.local.set','cookies.getAll','cookies.set','cookies.remove','browsingData.remove','tabs.query','tabs.get','tabs.remove','tabs.update','tabs.create'];
  const fields=['name','value','domain','path','hostOnly','secure','httpOnly','session','sameSite','expirationDate'];
  // Fixed failure reasons emitted by engine.js. Anything else becomes 'unknown'.
  const failureCodes=['native_timeout','native_timeout_mutation','native_timeout_read','native_rejected','unclassified','interrupted',
    'storage_read_unconfirmed','storage_format','storage_budget','storage_write_unconfirmed','stalled','busy','pending_exists','pending_not_cleared',
    'probe_blocker','invalid_option','api_missing','browsing_data_missing','profile_not_found','profile_cookies_invalid','profile_partially_expired',
    'ambiguous_identity','cookie_list_invalid','cookie_store_mismatch','context_store_mismatch','active_store_mismatch','native_cookie_incompatible',
    'native_cookie_scope_unknown','tabs_unreadable','tabs_not_stopped','reset_library_changed','clear_residual','clear_collision','write_rejected',
    'write_unconfirmed','write_store_mismatch','readback_mismatch','readback_unstable','all_expired_during_apply','open_tab_changed','open_context_unconfirmed'];
  const number=v=>typeof v==='number'&&Number.isFinite(v)&&v>=0?Math.min(v,Number.MAX_SAFE_INTEGER):undefined;
  const pick=(v,values)=>values.includes(v)?v:'unknown';
  const version=v=>typeof v==='string'&&/^\d+(\.\d+){1,3}$/.test(v)?v:null;
  function nums(source,keys){const out={};for(const key of keys){const n=number(source?.[key]);if(n!==undefined)out[key]=n;}return out;}
  const counts=['expectedCount','actualCount','matchedCount','missingCount','unexpectedCount','duplicateCount','valueMismatchCount','temporarySessionCount'];
  function verification(v){return {...nums(v,counts),attributeLimited:v?.attributeLimited===true,contentVerification:nums(v?.contentVerification,counts),differences:(Array.isArray(v?.differences)?v.differences:[]).slice(0,20).filter(x=>fields.includes(x?.field)).map(x=>({field:x.field,count:number(x.count)||0}))};}
  // Separates "the extension did not finish" from "finished; the website decides".
  function outcome(a){
    if(a.status==='running')return 'in_progress';
    if(a.status==='failed')return a.stage==='open'?'applied_open_failed':'extension_incomplete';
    if(a.status==='applied'||a.status==='opened')return 'applied_opened';
    return 'unknown';
  }
  // Deliberately reconstruct every exported object. Never spread storage, errors,
  // native arguments/results, account names, identifiers, URLs or Cookie data.
  function attempt(a={}){
    if(!a||typeof a!=='object')a={};
    const out={version:version(a.version),...nums(a,['startedAt','at','backgroundUptimeMs']),status:pick(a.status,['running','failed','applied','opened']),stage:pick(a.stage,stages),mutated:a.mutated===true,compatibilityUsed:a.compatibilityUsed===true,attributeCompatibilityUsed:a.attributeCompatibilityUsed===true,recovery:{status:pick(a.recovery?.status,['not_needed','pending','restored','restored_limited','abandoned'])}};
    out.entry=pick(a.entry,['manager','website']);
    out.replacedPending=a.replacedPending===true;
    out.durationMs=Math.max(0,(out.at||out.startedAt||0)-(out.startedAt||0));
    out.failureCategory=out.status!=='failed'?'none':pick(a.failureCategory,['native_timeout','native_rejected','validation_or_mismatch','interrupted']);
    out.failureCode=out.status!=='failed'?'none':pick(a.failureCode,failureCodes);
    out.outcome=outcome(out);
    out.websiteLoginVerified=false;
    out.stageTimeline=(Array.isArray(a.stageTimeline)?a.stageTimeline:[]).slice(0,24).filter(x=>stages.includes(x?.stage)).map(x=>({stage:x.stage,atMs:number(x.atMs)||0}));
    for(const key of ['clearingSummary','restoreClearingSummary','repairClearingSummary'])out[key]=nums(a[key],['initialCount','remainingCount','removeCalls','removeEmptyReplies','removeErrors','expiryCalls','expiryErrors','expiryHostOnlyCalls','expiryDottedDomainCalls','expiryBareDomainCalls','postExpiryRemoveCalls','polls','reappearedCount','residualIdentityCount','replaceableCount','overwriteDeferredCount','unmatchedTargetSiteCount','unmatchedOtherSiteCount']);
    out.verification=verification(a.verification);
    out.browserReset={status:pick(a.browserReset?.status,['requested','started','returned','cookies_empty','scope_empty','residual_to_clear','residual','library_changed']),...nums(a.browserReset,['remainingCount','inScopeRemainingCount','outOfScopeRemainingCount','reads'])};
    out.verificationSettlement=nums(a.verificationSettlement,['reads','mismatchedReads','consecutiveMatches']);
    out.tabPreparation={status:pick(a.tabPreparation?.status,['confirmed','unconfirmed'])};
    out.writeReadbackSummary=nums(a.writeReadbackSummary,['requestedCount','receivedCount']);
    for(const key of ['missingFieldCounts','invalidFieldCounts','differences'])out.writeReadbackSummary[key]=(Array.isArray(a.writeReadbackSummary?.[key])?a.writeReadbackSummary[key]:[]).slice(0,20).filter(x=>fields.includes(x?.field)).map(x=>({field:x.field,count:number(x.count)||0}));
    out.cookieWrite={...nums(a.cookieWrite,['ordinal','total']),category:pick(a.cookieWrite?.category,['native_rejected','native_timeout','unconfirmed_result','store_mismatch'])};
    out.repair={status:pick(a.repair?.status,['started','cleared','verified','failed']),initialVerification:nums(a.repair?.initialVerification,counts)};
    out.postOpen={status:pick(a.postOpen?.status,['waiting','checked','left_site']),...nums(a.postOpen,['afterMs','expectedCount','keptCount','changedCount','removedCount','addedCount']),
      ...(typeof a.postOpen?.sameHost==='boolean'?{sameHost:a.postOpen.sameHost}:{}),...(typeof a.postOpen?.samePath==='boolean'?{samePath:a.postOpen.samePath}:{})};
    out.apiSummary=(Array.isArray(a.apiSummary)?a.apiSummary:[]).slice(0,80).filter(x=>apis.includes(x?.api)).map(x=>({api:x.api,stage:pick(x.stage,stages),recovery:x.recovery===true,...nums(x,['calls','resolved','rejected','timeouts','lateResolved','lateRejected','totalMs','maxMs','firstMs','lastMs'])}));
    return out;
  }
  function report({version:ver,at,entries=[],busy=false,stalled=false,pending=false,storageReadable=true,backgroundUptimeMs,stalledApis=[],stalledForMs,libraryLocked=false}={}){
    const aliases=new Map();
    return {format:'orion-switch-error-log',formatVersion:2,extensionVersion:version(ver),generatedAt:number(at)||0,privacy:'No account names, identifiers, URLs, Cookie contents, credentials or raw browser errors. No automatic upload.',websiteLoginVerified:false,storageReadable:storageReadable===true,
      operation:{busy:busy===true,stalled:stalled===true,pending:pending===true,libraryLocked:libraryLocked===true,stalledApis:(Array.isArray(stalledApis)?stalledApis:[]).filter(x=>apis.includes(x)),...nums({backgroundUptimeMs,stalledForMs},['backgroundUptimeMs','stalledForMs'])},
      attempts:entries.filter(e=>e&&typeof e==='object').slice(-20).sort((a,b)=>(number(a.report?.startedAt)||0)-(number(b.report?.startedAt)||0)).map(entry=>{const key=entry.profileKey;if(!aliases.has(key))aliases.set(key,'account-'+(aliases.size+1));return {...attempt(entry.report),account:aliases.get(key)};})};
  }
  const api={attempt,report,apis,stages,failureCodes};root.AccountErrorLog=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(globalThis);
