(function () {
  'use strict';
  const engine = AccountEngine.create(AccountAPI);
  AccountAPI.native.runtime.onMessage.addListener((message, sender, sendResponse) => {
    // Only this extension's own manager may request an account operation.
    const base = AccountAPI.getURL('');
    if (!sender || sender.id !== AccountAPI.native.runtime.id ||
        (sender.url && !sender.url.startsWith(base)) || sender.tab?.incognito) {
      sendResponse({ok: false, error: '請在一般瀏覽模式的帳號管理頁操作。'});
      return false;
    }
    engine.handle(message, {tab: sender.tab}).then(data => sendResponse({ok: true, data}), error => {
      // Never return browser error strings that could contain cookie values.
      sendResponse({ok: false, error: error.safeMessage || '操作未完成。請重新整理管理頁查看復原提示。'});
    });
    return true;
  });
})();
